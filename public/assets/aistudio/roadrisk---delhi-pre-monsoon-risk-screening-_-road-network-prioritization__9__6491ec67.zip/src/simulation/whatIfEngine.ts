import { assignTrafficIterative } from "./traffic";
import {
  FLOOD_HOTSPOTS,
  getEffectiveRadius,
  getRoadsInSingleHotspot,
} from "../data/floodHotspots";

export type RainfallLevel = "Moderate" | "Heavy" | "Extreme";

export interface FloodHotspot {
  id?: string;
  name: string;
  aliases: string[];
  lat: number;
  lon: number;
  radiusMeters: number;
  isDemo: boolean;
  source: string;
}

export interface WhatIfScenarioInput {
  graph: any;
  odPairs: any[];
  baselineResult: any;
  osmRoads: any[];
  closedRoadIds: Set<string>;
  selectedHotspotId: string | null;
  rainfallLevel: RainfallLevel;
  activeHotspotIds?: string[];
}

export interface SecondaryGridlockRoad {
  roadId: string;
  name: string;
  highway: string;
  baselineUtilization: number;
  scenarioUtilization: number;
  utilizationSurgePct: number;
  baselineTraffic: number;
  scenarioTraffic: number;
  trafficSurgeVeh: number;
  capacity: number;
  baselineTimeMin: number;
  scenarioTimeMin: number;
  delayIncreaseMin: number;
}

export interface CascadeStep {
  step: number;
  title: string;
  subtitle: string;
  badge: string;
  description: string;
  blockedRoadIds: string[];
  secondaryGridlockRoadIds: string[];
  avgTravelTimeMin: number;
  travelTimeDeltaPct: number;
  disconnectedTrips: number;
  overloadedRoadsCount: number;
  activeHighlights: "none" | "primary_flood" | "secondary_gridlock";
}

export interface WhatIfScenarioResult {
  hasActiveClosures: boolean;
  blockedRoadIds: Set<string>;
  hotspotBlockedRoadIds: Set<string>;
  manuallyClosedRoadIds: Set<string>;
  activeHotspot: FloodHotspot | null;
  floodedHotspots: FloodHotspot[];
  effectiveRadiusMeters: number;
  scenarioTraffic: any;
  tripsDisconnected: number;
  tripsDisconnectedPct: number;
  avgTravelTimeDeltaPct: number;
  roadsPushedOverCapacity: SecondaryGridlockRoad[];
  secondaryGridlockRoads: SecondaryGridlockRoad[];
  summarySentence: string;
  cascadeSteps: CascadeStep[];
}

/**
 * Runs What-If simulation with blocked roads, calculates relative delta vs baseline,
 * identifies secondary gridlock ripple links, and builds 3-step cascade progression.
 */
export function runWhatIfScenario({
  graph,
  odPairs,
  baselineResult,
  osmRoads,
  closedRoadIds = new Set(),
  selectedHotspotId = null,
  rainfallLevel = "Extreme",
  activeHotspotIds = [],
}: WhatIfScenarioInput): WhatIfScenarioResult {
  if (!graph || !odPairs || odPairs.length === 0 || !baselineResult) {
    return {
      hasActiveClosures: false,
      blockedRoadIds: new Set(),
      hotspotBlockedRoadIds: new Set(),
      manuallyClosedRoadIds: new Set(),
      activeHotspot: null,
      floodedHotspots: [],
      effectiveRadiusMeters: 0,
      scenarioTraffic: null,
      tripsDisconnected: 0,
      tripsDisconnectedPct: 0,
      avgTravelTimeDeltaPct: 0,
      roadsPushedOverCapacity: [],
      secondaryGridlockRoads: [],
      summarySentence: "Select a waterlogging hotspot or click any road corridor to simulate flood severance.",
      cascadeSteps: [],
    };
  }

  // 1. Resolve Hotspot Blocked Roads
  let activeHotspot: FloodHotspot | null = null;
  const hotspotBlockedRoadIds = new Set<string>();
  const floodedHotspots: FloodHotspot[] = [];
  let effectiveRadiusMeters = 0;

  if (activeHotspotIds && activeHotspotIds.length > 0) {
    // When live TinyFish conditions are active, ONLY the matched hotspots are flooded!
    for (const hIdentifier of activeHotspotIds) {
      const spot = FLOOD_HOTSPOTS.find(
        (h) => h.id === hIdentifier || h.name.toLowerCase() === hIdentifier.toLowerCase()
      );
      if (spot) {
        floodedHotspots.push(spot);
        const rad = getEffectiveRadius(spot, rainfallLevel);
        effectiveRadiusMeters = Math.max(effectiveRadiusMeters, rad);
        const spotRoads = getRoadsInSingleHotspot(osmRoads, spot, rainfallLevel);
        spotRoads.forEach((id) => hotspotBlockedRoadIds.add(id));
      }
    }
    if (floodedHotspots.length === 1) {
      activeHotspot = floodedHotspots[0];
    }
  } else if (selectedHotspotId) {
    activeHotspot = FLOOD_HOTSPOTS.find((h) => h.id === selectedHotspotId || h.name === selectedHotspotId) || null;
    if (activeHotspot) {
      floodedHotspots.push(activeHotspot);
      effectiveRadiusMeters = getEffectiveRadius(activeHotspot, rainfallLevel);
      const spotRoads = getRoadsInSingleHotspot(osmRoads, activeHotspot, rainfallLevel);
      spotRoads.forEach((id) => hotspotBlockedRoadIds.add(id));
    }
  }

  // Union of manually closed roads + hotspot inundated roads
  // When activeHotspotIds is provided, ONLY those matched hotspots become flooded.
  const totalBlocked = new Set<string>();
  if (activeHotspotIds && activeHotspotIds.length > 0) {
    hotspotBlockedRoadIds.forEach((id) => totalBlocked.add(String(id)));
  } else {
    closedRoadIds.forEach((id) => totalBlocked.add(String(id)));
    hotspotBlockedRoadIds.forEach((id) => totalBlocked.add(String(id)));
  }

  const hasActiveClosures = totalBlocked.size > 0;

  if (!hasActiveClosures) {
    return {
      hasActiveClosures: false,
      blockedRoadIds: new Set(),
      hotspotBlockedRoadIds: new Set(),
      manuallyClosedRoadIds: new Set(closedRoadIds),
      activeHotspot,
      floodedHotspots: [],
      effectiveRadiusMeters,
      scenarioTraffic: baselineResult,
      tripsDisconnected: 0,
      tripsDisconnectedPct: 0,
      avgTravelTimeDeltaPct: 0,
      roadsPushedOverCapacity: [],
      secondaryGridlockRoads: [],
      summarySentence: "Baseline state: All corridors nominal. Click any road or choose a flood hotspot to model rerouting ripple.",
      cascadeSteps: [
        {
          step: 1,
          title: "Step 1: Normal Flow",
          subtitle: "Pre-monsoon baseline network",
          badge: "NORMAL",
          description: "All radial avenues and railway underpasses are dry and open. Traffic follows shortest paths with nominal congestion.",
          blockedRoadIds: [],
          secondaryGridlockRoadIds: [],
          avgTravelTimeMin: baselineResult.averageTravelTimeMinutes,
          travelTimeDeltaPct: 0.0,
          disconnectedTrips: 0,
          overloadedRoadsCount: baselineResult.overloadedRoadsCount,
          activeHighlights: "none",
        },
      ],
    };
  }

  // 2. Re-run Traffic Assignment with Blocked Roads
  const scenarioTraffic = assignTrafficIterative(graph, odPairs, {
    iterations: 4,
    blockedRoads: totalBlocked,
    baseline: baselineResult,
  });

  // 3. Compute trips disconnected
  const tripsDisconnected = Math.max(
    0,
    scenarioTraffic.disconnectedVehicles - (baselineResult.disconnectedVehicles || 0)
  );
  const totalVehicles = baselineResult.totalVehicles || 1;
  const tripsDisconnectedPct = Number(((tripsDisconnected / totalVehicles) * 100).toFixed(1));

  // 4. Compute Average Travel Time relative % change across all OD trips
  // If trips become severed/disconnected, apply a severe detour/stranded penalty
  let baseWeightedTime = 0;
  let scenWeightedTime = 0;
  let totalDemandSum = 0;

  for (let i = 0; i < odPairs.length; i++) {
    const pair = odPairs[i];
    const baseRoute = baselineResult.routeResults?.[i];
    const scenRoute = scenarioTraffic.routeResults?.[i];
    const demand = pair.demand || 50;
    totalDemandSum += demand;

    const baseTime = baseRoute && !baseRoute.disconnected ? baseRoute.travelTimeMinutes : 5.0;
    baseWeightedTime += baseTime * demand;

    let scenTime = baseTime;
    if (scenRoute && !scenRoute.disconnected) {
      scenTime = scenRoute.travelTimeMinutes;
    } else {
      // Severed routes experience heavy detour delay penalty (gridlock/reroute diversion)
      scenTime = Math.max(18.0, baseTime * 3.0);
    }
    scenWeightedTime += scenTime * demand;
  }

  const effectiveBaseAvgTime = totalDemandSum > 0 ? Number((baseWeightedTime / totalDemandSum).toFixed(2)) : 1;
  const effectiveScenAvgTime = totalDemandSum > 0 ? Number((scenWeightedTime / totalDemandSum).toFixed(2)) : 1;
  const rawTravelTimeDeltaPct = ((effectiveScenAvgTime - effectiveBaseAvgTime) / effectiveBaseAvgTime) * 100;
  const avgTravelTimeDeltaPct = Number(rawTravelTimeDeltaPct.toFixed(1));

  // 5. Compute roads pushed over capacity (Secondary Gridlock)
  // Definition: Roads that were <= 100% utilization in baseline, but are now > 100% in scenario!
  const secondaryGridlockRoads: SecondaryGridlockRoad[] = [];
  const baseStats: Record<string, any> = baselineResult.roadStats || {};
  const scenStats: Record<string, any> = scenarioTraffic.roadStats || {};

  for (const roadId of Object.keys(scenStats)) {
    // If the road itself was blocked, it didn't become secondary gridlock - it's severed
    if (totalBlocked.has(String(roadId))) continue;

    const baseRoad = baseStats[roadId];
    const scenRoad = scenStats[roadId];
    if (!scenRoad) continue;

    const baseUtil = baseRoad ? baseRoad.utilization : 0;
    const scenUtil = scenRoad.utilization;

    // Pushed over capacity: baseline was fine (<= 100%), now overloaded (> 100%)
    if (baseUtil <= 100 && scenUtil > 100) {
      secondaryGridlockRoads.push({
        roadId: String(roadId),
        name: scenRoad.name || `Corridor #${roadId}`,
        highway: scenRoad.highway || "road",
        baselineUtilization: baseUtil,
        scenarioUtilization: scenUtil,
        utilizationSurgePct: Number((scenUtil - baseUtil).toFixed(1)),
        baselineTraffic: baseRoad?.traffic || 0,
        scenarioTraffic: scenRoad.traffic,
        trafficSurgeVeh: Math.max(0, scenRoad.traffic - (baseRoad?.traffic || 0)),
        capacity: scenRoad.capacity,
        baselineTimeMin: baseRoad?.congestedMinutes || 0,
        scenarioTimeMin: scenRoad.congestedMinutes,
        delayIncreaseMin: Number(Math.max(0, scenRoad.congestedMinutes - (baseRoad?.congestedMinutes || 0)).toFixed(2)),
      });
    }
  }

  // Sort secondary gridlock roads by highest utilization surge
  secondaryGridlockRoads.sort((a, b) => b.scenarioUtilization - a.scenarioUtilization);

  // 6. Generate precise summary sentence
  // e.g. "Closing Minto Bridge Railway Underpass causes +24.8% longer trips and overloads 5 nearby roads."
  let closureSubject = "";
  if (floodedHotspots.length > 1) {
    const names = floodedHotspots.map((h) => h.name.split(" ")[0]).join(", ");
    closureSubject = `${floodedHotspots.length} inundated hotspots (${names})`;
  } else if (activeHotspot && closedRoadIds.size === 0) {
    closureSubject = activeHotspot.name;
  } else if (closedRoadIds.size === 1 && !activeHotspot) {
    const singleId = Array.from(closedRoadIds)[0];
    closureSubject = graph.roadMeta[singleId]?.name || `Corridor #${singleId}`;
  } else if (activeHotspot && closedRoadIds.size > 0) {
    closureSubject = `${activeHotspot.name} and ${closedRoadIds.size} individual corridor${closedRoadIds.size > 1 ? "s" : ""}`;
  } else {
    closureSubject = `${closedRoadIds.size} road corridor${closedRoadIds.size > 1 ? "s" : ""}`;
  }

  const travelSign = avgTravelTimeDeltaPct >= 0 ? "+" : "";
  const overloadCount = secondaryGridlockRoads.length;
  const overloadText =
    overloadCount === 1
      ? "overloads 1 nearby road"
      : `overloads ${overloadCount} nearby roads`;

  let summarySentence = `Closing ${closureSubject} causes ${travelSign}${avgTravelTimeDeltaPct}% longer trips and ${overloadText}.`;
  if (tripsDisconnected > 0) {
    summarySentence += ` (${tripsDisconnected} trips completely disconnected, illustrative).`;
  }

  // 7. Construct Step-by-Step Cascade Progression (3 Steps)
  // Step 1: Normal (Baseline condition)
  // Step 2: Link Floods and Traffic Shifts (Primary severance, flow detouring)
  // Step 3: Secondary Gridlock (Detour links overload, cascade domino effect)
  const secondaryRoadIds = secondaryGridlockRoads.map((r) => r.roadId);
  const cascadeSteps: CascadeStep[] = [
    {
      step: 1,
      title: "Step 1: Normal State",
      subtitle: "Pre-event baseline equilibrium",
      badge: "BASELINE (0.0% Δ)",
      description: "Corridors operate under standard peak traffic. Underpasses carry intended design volumes without inundation.",
      blockedRoadIds: [],
      secondaryGridlockRoadIds: [],
      avgTravelTimeMin: baselineResult.averageTravelTimeMinutes,
      travelTimeDeltaPct: 0.0,
      disconnectedTrips: 0,
      overloadedRoadsCount: baselineResult.overloadedRoadsCount,
      activeHighlights: "none",
    },
    {
      step: 2,
      title: "Step 2: Link Inundation & Diversion",
      subtitle: `${totalBlocked.size} corridor${totalBlocked.size > 1 ? "s" : ""} severed by waterlogging`,
      badge: "PRIMARY SEVERANCE",
      description: `${closureSubject} becomes impassable. Drivers divert onto immediate parallel radials, multiplying volumes along adjacent feeder arterials.`,
      blockedRoadIds: Array.from(totalBlocked),
      secondaryGridlockRoadIds: [],
      avgTravelTimeMin: Number((effectiveBaseAvgTime * (1 + (rawTravelTimeDeltaPct * 0.45) / 100)).toFixed(2)),
      travelTimeDeltaPct: Number((rawTravelTimeDeltaPct * 0.45).toFixed(1)),
      disconnectedTrips: Math.round(tripsDisconnected * 0.5),
      overloadedRoadsCount: baselineResult.overloadedRoadsCount + Math.min(2, overloadCount),
      activeHighlights: "primary_flood",
    },
    {
      step: 3,
      title: "Step 3: Secondary Gridlock Ripple",
      subtitle: `${overloadCount} parallel road${overloadCount > 1 ? "s" : ""} pushed over 100% capacity`,
      badge: "CASCADE GRIDLOCK",
      description: `Detour routes collapse as volume exceeds physical capacity. Secondary gridlock spreads outward, raising average travel times by ${travelSign}${avgTravelTimeDeltaPct}%.`,
      blockedRoadIds: Array.from(totalBlocked),
      secondaryGridlockRoadIds: secondaryRoadIds,
      avgTravelTimeMin: effectiveScenAvgTime,
      travelTimeDeltaPct: avgTravelTimeDeltaPct,
      disconnectedTrips: tripsDisconnected,
      overloadedRoadsCount: scenarioTraffic.overloadedRoadsCount,
      activeHighlights: "secondary_gridlock",
    },
  ];

  return {
    hasActiveClosures,
    blockedRoadIds: totalBlocked,
    hotspotBlockedRoadIds,
    manuallyClosedRoadIds: closedRoadIds,
    activeHotspot,
    floodedHotspots,
    effectiveRadiusMeters,
    scenarioTraffic,
    tripsDisconnected,
    tripsDisconnectedPct,
    avgTravelTimeDeltaPct,
    roadsPushedOverCapacity: secondaryGridlockRoads,
    secondaryGridlockRoads,
    summarySentence,
    cascadeSteps,
  };
}
