import React, { useState, useEffect, useMemo, useCallback } from "react";
import {
  Activity,
  Layers,
  MapPin,
  RefreshCw,
  Info,
  ShieldAlert,
  Hospital as HospitalIcon,
  Database,
  SlidersHorizontal,
  Play,
  Users,
  Home,
  RotateCcw,
} from "lucide-react";
import RoadMap, { ZONE_BOUNDS, ZONE_CENTER } from "./components/RoadMap";
import RightTabsPanel, { TinyFishLiveFeedData } from "./components/RightTabsPanel";
import ModelAssumptionsModal from "./components/ModelAssumptionsModal";
import ResidentReportingModal from "./components/ResidentReportingModal";
import LandingCoverPage from "./components/LandingCoverPage";
import { buildRoadGraph } from "./simulation/graph";
import { generateODDemand, assignTrafficIterative } from "./simulation/traffic";
import { runWhatIfScenario, RainfallLevel } from "./simulation/whatIfEngine";
import { analyzeHospitalAccess } from "./simulation/hospitalAccessibilityEngine";
import { calculateAreaKm2 } from "./utils/geo";
import { FLOOD_HOTSPOTS } from "./data/floodHotspots";

export interface ActiveZone {
  name: string;
  south: number;
  west: number;
  north: number;
  east: number;
  center: [number, number];
  isDefault: boolean;
  areaKm2: number;
}

export const DEFAULT_CENTRAL_DELHI_ZONE: ActiveZone = {
  name: "Central Delhi (Connaught Place, Minto Bridge, ITO)",
  south: 28.6180,
  west: 77.2050,
  north: 28.6480,
  east: 77.2500,
  center: [28.6315, 77.2270],
  isDefault: true,
  areaKm2: 14.6,
};

export default function App() {
  const [currentZone, setCurrentZone] = useState<ActiveZone>(DEFAULT_CENTRAL_DELHI_ZONE);
  const [roads, setRoads] = useState<any[]>([]);
  const [hospitals, setHospitals] = useState<any[]>([]);
  const [dataSource, setDataSource] = useState<"OSM live" | "fallback snapshot">("fallback snapshot");
  const [loading, setLoading] = useState<boolean>(true);
  const [loadingMessage, setLoadingMessage] = useState<string>("Initializing Central Delhi network...");
  const [selectedRoad, setSelectedRoad] = useState<any | null>(null);
  const [fetchError, setFetchError] = useState<string | null>(null);

  // What-If & Cascade State
  const [closedRoadIds, setClosedRoadIds] = useState<Set<string>>(new Set());
  const [selectedHotspotId, setSelectedHotspotId] = useState<string | null>(null);
  const [rainfallLevel, setRainfallLevel] = useState<RainfallLevel>("Extreme");
  const [activeTab, setActiveTab] = useState<string>("what_if");
  const [cascadeStepIndex, setCascadeStepIndex] = useState<number>(2); // 0: Normal, 1: Link Floods, 2: Secondary Gridlock

  // Hospital Access State
  const [selectedHospitalAreaId, setSelectedHospitalAreaId] = useState<string | null>(null);
  const [showHospitalNodes, setShowHospitalNodes] = useState<boolean>(true);

  // Live Feed & TinyFish State
  const [liveFeed, setLiveFeed] = useState<TinyFishLiveFeedData | null>(null);
  const [isLiveFeedLoading, setIsLiveFeedLoading] = useState<boolean>(false);
  const [useLiveTinyFish, setUseLiveTinyFish] = useState<boolean>(false);

  // Modal Dialog States
  const [showAssumptionsModal, setShowAssumptionsModal] = useState<boolean>(false);
  const [showReportingModal, setShowReportingModal] = useState<boolean>(false);

  // Application View: Landing Cover page vs Dashboard Analysis
  const [view, setView] = useState<"landing" | "dashboard">("landing");

  // Run demo scenario: loads Minto Bridge flooded, Extreme rainfall, opens Cascade tab, and navigates to dashboard
  const handleRunDemoScenario = useCallback(() => {
    setClosedRoadIds(new Set());
    setSelectedHotspotId("minto-bridge");
    setRainfallLevel("Extreme");
    setUseLiveTinyFish(false);
    setActiveTab("cascade");
    setCascadeStepIndex(2); // Domino secondary gridlock
    setSelectedRoad(null);
    setSelectedHospitalAreaId(null);
    setView("dashboard");
  }, []);

  // Fetch roads and hospitals from backend Express proxy
  const loadZoneData = useCallback(async (targetZone: ActiveZone = currentZone, bypassCache = false) => {
    setLoading(true);
    setFetchError(null);
    setLoadingMessage(`Querying OpenStreetMap for drivable roads in ${targetZone.name}...`);

    try {
      const bboxParams = `south=${targetZone.south}&west=${targetZone.west}&north=${targetZone.north}&east=${targetZone.east}`;
      const bypassParam = bypassCache ? "&bypassCache=true" : "";

      // 1. Fetch Roads
      const roadsPromise = fetch(`/api/roads?${bboxParams}${bypassParam}`).then(async (res) => {
        const json = await res.json();
        if (!res.ok || json.ok === false) {
          throw new Error(json.error || `Roads endpoint failed HTTP ${res.status}`);
        }
        return json;
      });

      // 2. Fetch Hospitals
      const hospitalsPromise = fetch(`/api/hospitals?${bboxParams}${bypassParam}`).then(async (res) => {
        const json = await res.json();
        if (!res.ok || json.ok === false) {
          throw new Error(json.error || `Hospitals endpoint failed HTTP ${res.status}`);
        }
        return json;
      });

      const [roadsData, hospitalsData] = await Promise.all([roadsPromise, hospitalsPromise]);

      const loadedRoads = roadsData?.roads || [];
      const loadedHospitals = hospitalsData?.hospitals || [];
      const source = roadsData?.source === "OSM live" ? "OSM live" : "fallback snapshot";

      setRoads(loadedRoads);
      setHospitals(loadedHospitals);
      setDataSource(source);
      setCurrentZone(targetZone);
    } catch (err: any) {
      console.warn("Zone data fetch error:", err?.message || err);
      setFetchError(err.message || "Failed to load network for this area.");
    } finally {
      setLoading(false);
      setLoadingMessage("");
    }
  }, [currentZone]);

  const handleRunAnalysisArea = useCallback((bounds: [[number, number], [number, number]], name?: string) => {
    const south = Math.min(bounds[0][0], bounds[1][0]);
    const north = Math.max(bounds[0][0], bounds[1][0]);
    const west = Math.min(bounds[0][1], bounds[1][1]);
    const east = Math.max(bounds[0][1], bounds[1][1]);
    const center: [number, number] = [(south + north) / 2, (west + east) / 2];
    const areaKm2 = calculateAreaKm2(bounds);

    const initialName = name || `Custom Area (${areaKm2} km²)`;
    const newZone: ActiveZone = {
      name: initialName,
      south,
      west,
      north,
      east,
      center,
      isDefault: false,
      areaKm2,
    };

    setClosedRoadIds(new Set());
    setSelectedHotspotId(null);
    setSelectedRoad(null);
    setSelectedHospitalAreaId(null);

    loadZoneData(newZone, false);

    // Reverse-geocode in the background if no explicit name was provided
    if (!name) {
      fetch(`/api/reverse-geocode?lat=${center[0]}&lon=${center[1]}`)
        .then((r) => r.json())
        .then((data) => {
          if (data.ok && data.name) {
            setCurrentZone((prev) =>
              prev.south === south && prev.west === west ? { ...prev, name: data.name } : prev
            );
          }
        })
        .catch(() => {});
    }
  }, [loadZoneData]);

  const handleResetToCentralDelhi = useCallback(() => {
    setClosedRoadIds(new Set());
    setSelectedHotspotId(null);
    setSelectedRoad(null);
    setSelectedHospitalAreaId(null);
    loadZoneData(DEFAULT_CENTRAL_DELHI_ZONE, false);
  }, [loadZoneData]);

  // Active hotspots in currently analyzed zone
  const activeZoneHotspots = useMemo(() => {
    return FLOOD_HOTSPOTS.filter(
      (h) =>
        h.lat >= currentZone.south &&
        h.lat <= currentZone.north &&
        h.lon >= currentZone.west &&
        h.lon <= currentZone.east
    );
  }, [currentZone]);

  useEffect(() => {
    loadZoneData(DEFAULT_CENTRAL_DELHI_ZONE);
  }, []);

  // Fetch TinyFish Live Flood Feed for current selected area
  const fetchLiveFeed = useCallback(
    async (bypassCache = false, zoneOverride?: ActiveZone, roadsOverride?: any[]) => {
      const targetZone = zoneOverride || currentZone;
      const targetRoads = roadsOverride || roads;
      const targetHotspots = FLOOD_HOTSPOTS.filter(
        (h) =>
          h.lat >= targetZone.south &&
          h.lat <= targetZone.north &&
          h.lon >= targetZone.west &&
          h.lon <= targetZone.east
      );

      setIsLiveFeedLoading(true);
      try {
        const payload = {
          areaName: targetZone.name,
          lat: targetZone.center[0],
          lon: targetZone.center[1],
          south: targetZone.south,
          west: targetZone.west,
          north: targetZone.north,
          east: targetZone.east,
          isDefault: targetZone.isDefault,
          hotspots: targetHotspots.map((h) => ({ name: h.name, aliases: h.aliases || [] })),
          roads: Array.from(
            new Set(
              targetRoads
                .map((r: any) => r.name)
                .filter((n): n is string => Boolean(n) && typeof n === "string" && n.length > 3)
            )
          ),
          bypassCache,
        };

        const res = await fetch("/api/live-flood-feed", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });

        if (!res.ok) throw new Error(`Live feed HTTP ${res.status}`);
        const data = await res.json();
        setLiveFeed(data);
      } catch (err: any) {
        console.info("Info: Live flood feed fetch:", err?.message || err);
      } finally {
        setIsLiveFeedLoading(false);
      }
    },
    [currentZone, roads]
  );

  // Automatically fetch live feed when zone or roads change
  useEffect(() => {
    fetchLiveFeed(false, currentZone, roads);
  }, [currentZone.name, currentZone.south, currentZone.west, roads.length]);

  // When "Use live TinyFish conditions" is enabled:
  // 1. Matched news hotspots become flooded
  const liveMatchedHotspotIds = useMemo(() => {
    if (!useLiveTinyFish || !liveFeed?.matches) return [];
    return liveFeed.matches.map((m: any) => m.hotspotName);
  }, [useLiveTinyFish, liveFeed]);

  // 2. Matched road corridors from news advisories are closed
  const liveMatchedRoadIds = useMemo(() => {
    if (!useLiveTinyFish || !liveFeed?.matchedRoads || !roads || roads.length === 0) {
      return new Set<string>();
    }
    const matchedNames = new Set(
      liveFeed.matchedRoads.map((mr: any) => mr.roadName.toLowerCase().trim())
    );
    const matchedIds = new Set<string>();
    for (const r of roads) {
      if (r.name && matchedNames.has(r.name.toLowerCase().trim())) {
        matchedIds.add(String(r.id));
      }
    }
    return matchedIds;
  }, [useLiveTinyFish, liveFeed, roads]);

  // Combined closed road IDs (manual road closures + live matched road closures)
  const effectiveClosedRoadIds = useMemo(() => {
    const combined = new Set(closedRoadIds);
    if (useLiveTinyFish) {
      liveMatchedRoadIds.forEach((id) => combined.add(id));
    }
    return combined;
  }, [closedRoadIds, useLiveTinyFish, liveMatchedRoadIds]);

  // Build network graph from loaded roads (nodes at intersections, edges with length, speed, capacity)
  const graph = useMemo(() => {
    if (!roads || roads.length === 0) return null;
    return buildRoadGraph(roads);
  }, [roads]);

  // 1. Generate synthetic origin-destination demand with a Gravity Model between ~12 zone centroid nodes
  // Label: "synthetic demand (illustrative)"
  const odPairs = useMemo(() => {
    if (!graph) return [];
    return generateODDemand(graph);
  }, [graph]);

  // 2. Assign trips to shortest-time paths using Dijkstra, with BPR congestion:
  //    travel time = t0 * (1 + 0.15 * (flow / capacity)^4)
  // Run 4 iterations (MSA) so flows spread over alternative corridors
  const baselineTraffic = useMemo(() => {
    if (!graph || odPairs.length === 0) return null;
    return assignTrafficIterative(graph, odPairs, { iterations: 4 });
  }, [graph, odPairs]);

  // Toggle closure for an individual road corridor
  const toggleRoadClosed = useCallback((roadId: string) => {
    setClosedRoadIds((prev: Set<string>) => {
      const next = new Set(prev);
      const idStr = String(roadId);
      if (next.has(idStr)) {
        next.delete(idStr);
      } else {
        next.add(idStr);
      }
      return next;
    });
  }, []);

  // Reset all flood & road closures back to baseline
  const resetClosures = useCallback(() => {
    setClosedRoadIds(new Set());
    setSelectedHotspotId(null);
    setUseLiveTinyFish(false);
    setCascadeStepIndex(2);
    setSelectedHospitalAreaId(null);
  }, []);

  // 3. What-If & Cascade simulation engine
  const whatIfScenario = useMemo(() => {
    if (!graph || !baselineTraffic) return null;
    return runWhatIfScenario({
      graph,
      odPairs,
      baselineResult: baselineTraffic,
      osmRoads: roads,
      closedRoadIds: effectiveClosedRoadIds,
      selectedHotspotId: useLiveTinyFish ? null : selectedHotspotId,
      rainfallLevel,
      activeHotspotIds: liveMatchedHotspotIds,
    });
  }, [
    graph,
    odPairs,
    baselineTraffic,
    roads,
    effectiveClosedRoadIds,
    selectedHotspotId,
    rainfallLevel,
    useLiveTinyFish,
    liveMatchedHotspotIds,
  ]);

  // 4. Hospital Accessibility Engine
  const hospitalAccess = useMemo(() => {
    if (!graph || hospitals.length === 0) return null;
    const blockedSet = whatIfScenario?.hasActiveClosures
      ? whatIfScenario.blockedRoadIds
      : new Set<string>();

    return analyzeHospitalAccess({
      graph,
      hospitals,
      roads,
      blockedRoads: blockedSet,
      scenarioTraffic: whatIfScenario?.scenarioTraffic,
    });
  }, [graph, hospitals, roads, whatIfScenario]);

  if (view === "landing") {
    return (
      <>
        <LandingCoverPage
          onLaunch={() => setView("dashboard")}
          onRunDemo={handleRunDemoScenario}
        />
        {/* Model Assumptions Modal */}
        <ModelAssumptionsModal
          isOpen={showAssumptionsModal}
          onClose={() => setShowAssumptionsModal(false)}
        />
        {/* Resident Reporting Concept Mockup Modal */}
        <ResidentReportingModal
          isOpen={showReportingModal}
          onClose={() => setShowReportingModal(false)}
        />
      </>
    );
  }

  return (
    <div className="w-full h-full min-h-screen flex flex-col bg-[#080b10] text-slate-100 font-sans select-none overflow-hidden">
      {/* Top Landing & Planner Header */}
      <header className="h-14 bg-[#0a0d14] border-b border-[#182333] px-3 lg:px-5 flex items-center justify-between shrink-0 z-30 select-none">
        <div className="flex items-center gap-3 min-w-0">
          {/* Home button to return to Cover / Landing Page */}
          <button
            type="button"
            onClick={() => setView("landing")}
            className="px-2.5 py-1.5 rounded bg-[#131c2a] hover:bg-[#1c2738] border border-[#23354d] text-slate-300 hover:text-white font-mono text-xs flex items-center gap-1.5 transition-colors cursor-pointer shadow-sm"
            title="Return to Cover / Landing page"
          >
            <Home className="w-3.5 h-3.5 text-cyan-400" />
            <span className="font-bold">HOME</span>
          </button>

          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded bg-[#131c2a] border border-[#24354d] flex items-center justify-center text-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.25)]">
              <Activity className="w-4 h-4" />
            </div>
            <div>
              <span className="font-mono font-black text-sm tracking-tight text-white flex items-center gap-1.5">
                <span>ROADRISK DELHI</span>
                <span className="text-[10px] text-cyan-400 px-1.5 py-0.2 rounded bg-cyan-950/80 border border-cyan-800/60 font-semibold tracking-wider truncate max-w-[200px]">
                  {currentZone.isDefault ? "CENTRAL ZONE" : currentZone.name.toUpperCase()}
                </span>
              </span>
              <span className="text-[10px] font-mono text-slate-400 uppercase tracking-widest hidden xl:block">
                Pre-Monsoon Flood What-If &amp; Cascade Engine for Resilient Roads and Hospital Access
              </span>
            </div>
          </div>
        </div>

        {/* Header Right: Actions, Demo Scenario, Resident Reporting, Assumptions */}
        <div className="flex items-center gap-2 font-mono text-xs">
          {/* Reset to Central Delhi Button if custom area active */}
          {!currentZone.isDefault && (
            <button
              type="button"
              onClick={handleResetToCentralDelhi}
              className="px-2.5 py-1.5 rounded bg-[#131c2a] hover:bg-[#1a283b] border border-cyan-700/60 text-cyan-300 font-bold text-[11px] flex items-center gap-1.5 transition-colors cursor-pointer"
              title="Reset simulation back to default Central Delhi zone"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">RESET TO CENTRAL DELHI</span>
              <span className="sm:hidden">RESET</span>
            </button>
          )}

          {/* Run Demo Scenario Button */}
          <button
            type="button"
            onClick={handleRunDemoScenario}
            className="px-3 py-1.5 rounded bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs flex items-center gap-1.5 transition-all shadow-[0_0_15px_rgba(245,158,11,0.35)] cursor-pointer"
            title="Load Minto Bridge flooded, Extreme rainfall, and open the Cascade tab"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span className="whitespace-nowrap font-black">RUN DEMO SCENARIO</span>
          </button>

          {/* Resident Reporting (Concept Mockup) */}
          <button
            type="button"
            onClick={() => setShowReportingModal(true)}
            className="px-2.5 py-1.5 rounded bg-[#141b26] hover:bg-[#1b2536] border border-[#25374d] text-slate-200 hover:text-cyan-300 text-[11px] font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
            title="Open resident reporting concept mockup form"
          >
            <Users className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden sm:inline">RESIDENT REPORTING (MOCKUP)</span>
            <span className="sm:hidden">REPORT</span>
          </button>

          {/* Model Assumptions */}
          <button
            type="button"
            onClick={() => setShowAssumptionsModal(true)}
            className="px-2.5 py-1.5 rounded bg-[#131d2b] hover:bg-[#1a293d] border border-[#253952] text-[#38bdf8] font-bold text-[11px] flex items-center gap-1.5 transition-colors cursor-pointer"
            title="View theoretical model assumptions & methodology"
          >
            <Info className="w-3.5 h-3.5 text-[#38bdf8]" />
            <span className="hidden md:inline">ASSUMPTIONS</span>
          </button>

          {/* Quick Refresh */}
          <button
            type="button"
            onClick={() => loadZoneData(currentZone, true)}
            disabled={loading}
            className="px-2 py-1.5 rounded bg-[#141d2b] hover:bg-[#1a273b] border border-[#24364e] text-slate-300 hover:text-cyan-300 text-[11px] font-bold flex items-center gap-1 transition-colors cursor-pointer"
            title="Bypass server cache and re-query OpenStreetMap"
          >
            <RefreshCw className={`w-3 h-3 ${loading ? "animate-spin text-cyan-400" : ""}`} />
            <span className="hidden lg:inline">REFRESH OSM</span>
          </button>
        </div>
      </header>

      {/* Main Workstation: Map on Left, Planner Tabs on Right */}
      <div className="flex-1 flex flex-col lg:flex-row overflow-hidden relative">
        {/* Left Map Viewport */}
        <main className="flex-1 h-full relative overflow-hidden bg-slate-950">
          <RoadMap
            roads={roads}
            hospitals={hospitals}
            graph={graph}
            dataSource={dataSource}
            loading={loading}
            onRefresh={() => loadZoneData(currentZone, true)}
            selectedRoadId={selectedRoad?.id}
            onSelectRoad={(road) => setSelectedRoad(road)}
            baselineTraffic={baselineTraffic}
            odPairs={odPairs}
            whatIfScenario={whatIfScenario}
            closedRoadIds={effectiveClosedRoadIds}
            onToggleRoadClosed={toggleRoadClosed}
            selectedHotspotId={selectedHotspotId}
            onSelectHotspot={(id) => setSelectedHotspotId(id)}
            rainfallLevel={rainfallLevel}
            activeTab={activeTab}
            cascadeStepIndex={cascadeStepIndex}
            onResetClosures={resetClosures}
            hospitalAccess={hospitalAccess}
            selectedHospitalAreaId={selectedHospitalAreaId}
            onSelectHospitalArea={setSelectedHospitalAreaId}
            showHospitalNodes={showHospitalNodes}
            onToggleHospitalNodes={() => setShowHospitalNodes((v: boolean) => !v)}
            currentZone={currentZone}
            onRunAnalysisArea={handleRunAnalysisArea}
            onResetToCentralDelhi={handleResetToCentralDelhi}
            fetchError={fetchError}
            onRetryAnalysis={() => loadZoneData(currentZone, true)}
          />

          {/* Loading overlay */}
          {loading && (
            <div className="absolute inset-0 z-[2000] bg-[#0c0e12]/80 backdrop-blur-sm flex items-center justify-center p-4">
              <div className="p-6 rounded bg-[#101520] border border-[#223348] shadow-2xl text-center space-y-3 max-w-sm w-full font-mono">
                <div className="w-10 h-10 mx-auto rounded-full bg-[#162335] border border-cyan-400/40 flex items-center justify-center text-cyan-400">
                  <RefreshCw className="w-5 h-5 animate-spin" />
                </div>
                <div className="text-xs font-bold text-white uppercase tracking-wider">
                  Loading Road Infrastructure
                </div>
                <div className="text-[11px] text-slate-300 bg-[#090c10] border border-[#1b2536] px-3 py-2 rounded">
                  {loadingMessage}
                </div>
              </div>
            </div>
          )}
        </main>

        {/* Right Planner Tabs Panel */}
        <RightTabsPanel
          roads={roads}
          hospitals={hospitals}
          graph={graph}
          dataSource={dataSource}
          loading={loading}
          selectedRoad={selectedRoad}
          onClearSelectedRoad={() => setSelectedRoad(null)}
          baselineTraffic={baselineTraffic}
          odPairs={odPairs}
          whatIfScenario={whatIfScenario}
          closedRoadIds={effectiveClosedRoadIds}
          onToggleRoadClosed={toggleRoadClosed}
          selectedHotspotId={selectedHotspotId}
          onSelectHotspot={(id) => setSelectedHotspotId(id)}
          rainfallLevel={rainfallLevel}
          onSetRainfallLevel={setRainfallLevel}
          onResetClosures={resetClosures}
          activeTab={activeTab}
          onTabChange={setActiveTab}
          cascadeStepIndex={cascadeStepIndex}
          onSetCascadeStepIndex={setCascadeStepIndex}
          hospitalAccess={hospitalAccess}
          selectedHospitalAreaId={selectedHospitalAreaId}
          onSelectHospitalArea={setSelectedHospitalAreaId}
          liveFeed={liveFeed}
          isLiveFeedLoading={isLiveFeedLoading}
          onRefreshLiveFeed={() => fetchLiveFeed(true)}
          useLiveTinyFish={useLiveTinyFish}
          onToggleUseLiveTinyFish={setUseLiveTinyFish}
          activeZoneHotspots={activeZoneHotspots}
          currentZone={currentZone}
          onSimulateHotspotFix={(id) => {
            setSelectedHotspotId(id);
            setActiveTab("what_if");
          }}
        />
      </div>

      {/* Model Assumptions Modal */}
      <ModelAssumptionsModal
        isOpen={showAssumptionsModal}
        onClose={() => setShowAssumptionsModal(false)}
      />

      {/* Resident Reporting Concept Mockup Modal */}
      <ResidentReportingModal
        isOpen={showReportingModal}
        onClose={() => setShowReportingModal(false)}
      />
    </div>
  );
}
