import express, { Request, Response } from "express";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";
import { createServer as createViteServer } from "vite";
import { FLOOD_HOTSPOTS } from "./src/data/floodHotspots.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json());

// Zone Bounding Box: Central Delhi (Connaught Place, Minto Bridge, ITO, Tilak Bridge)
const DELHI_ZONE = {
  south: 28.6180,
  west: 77.2050,
  north: 28.6480,
  east: 77.2500,
  center: [28.6315, 77.2270] as [number, number],
  name: "Central Delhi (CP, Minto Bridge, ITO, Tilak Bridge)",
};

// High-availability Overpass API mirrors with fast fallback
const OVERPASS_MIRRORS = [
  "https://overpass-api.de/api/interpreter",
  "https://lz4.overpass-api.de/api/interpreter",
  "https://z.overpass-api.de/api/interpreter",
  "https://overpass.kumi.systems/api/interpreter",
  "https://overpass.private.coffee/api/interpreter",
];

const OVERPASS_TIMEOUT_MS = 6000; // 6.0s timeout
const CACHE_TTL_MS = 30 * 60 * 1000; // 30 minutes

interface CacheEntry<T> {
  timestamp: number;
  data: T;
  source: "OSM live" | "fallback snapshot";
}

const roadCache = new Map<string, CacheEntry<any[]>>();
const hospitalCache = new Map<string, CacheEntry<any[]>>();

// Load bundled fallback roads
function getFallbackRoads(): any[] {
  try {
    const filePath = path.resolve(__dirname, "src/data/fallbackRoads.json");
    if (fs.existsSync(filePath)) {
      const raw = fs.readFileSync(filePath, "utf-8");
      return JSON.parse(raw);
    }
  } catch (err) {
    console.info("Info: fallbackRoads.json read error, returning empty array");
  }
  return [];
}

// Fallback real hospitals near Connaught Place / Minto Bridge / ITO / Tilak Bridge
const FALLBACK_HOSPITALS = [
  {
    id: "hosp_lnjp",
    name: "Lok Nayak Hospital (LNJP / Civil Hospital)",
    lat: 28.6367,
    lon: 77.2403,
    emergency: "yes",
    type: "Major Trauma Centre & Tertiary Teaching Hospital",
    address: "Jawaharlal Nehru Marg, Delhi Gate",
    beds: 2000,
  },
  {
    id: "hosp_gb_pant",
    name: "Govind Ballabh Pant Hospital (G.B. Pant)",
    lat: 28.6375,
    lon: 77.2385,
    emergency: "yes",
    type: "Super-Speciality Government Hospital",
    address: "1, Jawaharlal Nehru Marg, Raj Ghat",
    beds: 714,
  },
  {
    id: "hosp_mamc",
    name: "Maulana Azad Medical College Hospital / Dental",
    lat: 28.6360,
    lon: 77.2395,
    emergency: "yes",
    type: "Tertiary Teaching Hospital",
    address: "BSZ Marg, near Delhi Gate",
    beds: 350,
  },
  {
    id: "hosp_guru_nanak",
    name: "Guru Nanak Eye Centre",
    lat: 28.6358,
    lon: 77.2340,
    emergency: "no",
    type: "Speciality Eye Institute",
    address: "Maharaja Ranjit Singh Marg",
    beds: 200,
  },
  {
    id: "hosp_northern_railway",
    name: "Northern Railway Central Hospital",
    lat: 28.6410,
    lon: 77.2145,
    emergency: "yes",
    type: "Divisional Railway Hospital & Trauma Unit",
    address: "Basant Lane, Paharganj / Connaught Place",
    beds: 450,
  },
  {
    id: "hosp_rml",
    name: "Dr. Ram Manohar Lohia Hospital (RML Hospital)",
    lat: 28.6245,
    lon: 77.2025,
    emergency: "yes",
    type: "Central Government Emergency & Super Speciality Hospital",
    address: "Baba Kharak Singh Marg",
    beds: 1420,
  },
  {
    id: "hosp_lady_hardinge",
    name: "Sucheta Kriplani Hospital (Lady Hardinge Medical College)",
    lat: 28.6335,
    lon: 77.2110,
    emergency: "yes",
    type: "Tertiary Women & General Hospital",
    address: "Shaheed Bhagat Singh Marg, Connaught Place",
    beds: 870,
  },
  {
    id: "hosp_kalawati_saran",
    name: "Kalawati Saran Children's Hospital",
    lat: 28.6322,
    lon: 77.2125,
    emergency: "yes",
    type: "Government Paediatric Centre",
    address: "Bangla Sahib Marg, Connaught Place",
    beds: 350,
  },
];

// Pre-warm the cache for the default Central Delhi zone so initial load is instantaneous (<5ms)
const defaultZoneKey = `${DELHI_ZONE.south.toFixed(4)},${DELHI_ZONE.west.toFixed(4)},${DELHI_ZONE.north.toFixed(4)},${DELHI_ZONE.east.toFixed(4)}`;
const defaultRoads = getFallbackRoads();
if (defaultRoads && defaultRoads.length > 0) {
  roadCache.set(defaultZoneKey, {
    timestamp: Date.now(),
    data: defaultRoads,
    source: "fallback snapshot",
  });
}
hospitalCache.set(defaultZoneKey, {
  timestamp: Date.now(),
  data: FALLBACK_HOSPITALS,
  source: "fallback snapshot",
});

// Helper to query single Overpass mirror with timeout
async function fetchOverpassMirror(mirrorUrl: string, query: string, timeoutMs: number): Promise<any> {
  const body = new URLSearchParams();
  body.append("data", query);

  const response = await fetch(mirrorUrl, {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
      "User-Agent": "RoadRiskDelhi/3.0 (Urban Transportation Resilience; contact@roadrisk.app)",
      Accept: "application/json",
    },
    body: body.toString(),
    signal: AbortSignal.timeout(timeoutMs),
  });

  if (!response.ok) {
    throw new Error(`Mirror ${mirrorUrl} returned HTTP ${response.status}`);
  }

  const data = await response.json();
  if (data && Array.isArray(data.elements)) {
    return data.elements;
  }
  throw new Error(`Mirror ${mirrorUrl} returned invalid elements`);
}

// Resilient Overpass mirror query with graceful empty return on timeout
async function tryOverpassMirrors(query: string): Promise<any[]> {
  try {
    const elements = await Promise.any(
      OVERPASS_MIRRORS.map((m) => fetchOverpassMirror(m, query, OVERPASS_TIMEOUT_MS))
    );
    if (elements && elements.length > 0) {
      return elements;
    }
    return [];
  } catch (err: any) {
    console.info("Info: Overpass query unavailable, proceeding with fast secondary OSM source.");
    return [];
  }
}

// Parse OSM ways to road objects
function parseOSMRoadWays(elements: any[]): any[] {
  const roads: any[] = [];
  for (const el of elements) {
    if (el.type !== "way" || !el.geometry || el.geometry.length < 2) continue;
    const tags = el.tags || {};
    const highway = (tags.highway || "road").split("_")[0];
    const name = tags.name || tags.ref || `${highway.charAt(0).toUpperCase() + highway.slice(1)} Road`;
    const lanes = parseInt(tags.lanes, 10) || (highway.includes("primary") || highway.includes("trunk") ? 2 : 1);
    const maxspeed = parseInt(tags.maxspeed, 10) || 40;

    roads.push({
      id: String(el.id),
      name,
      highway,
      lanes,
      maxspeed,
      geometry: el.geometry.map((pt: any) => ({
        lat: Number(pt.lat),
        lon: Number(pt.lon),
      })),
    });
  }
  return roads;
}

// Parse direct OpenStreetMap 0.6 XML response
function parseOSMXml(xmlText: string): any[] {
  const nodes = new Map<string, { lat: number; lon: number }>();
  const nodeMatches = xmlText.matchAll(/<node id="(\d+)"[^>]*lat="([^"]+)" lon="([^"]+)"/g);
  for (const m of nodeMatches) {
    const lat = parseFloat(m[2]);
    const lon = parseFloat(m[3]);
    if (!isNaN(lat) && !isNaN(lon)) nodes.set(m[1], { lat, lon });
  }

  const highwayFilter = new Set(["motorway", "trunk", "primary", "secondary", "tertiary", "residential"]);
  const roads: any[] = [];
  const wayRegex = /<way id="(\d+)"[^>]*>([\s\S]*?)<\/way>/g;
  for (const wm of xmlText.matchAll(wayRegex)) {
    const id = wm[1];
    const body = wm[2];
    const hwMatch = body.match(/<tag k="highway" v="([^"]+)"/);
    if (!hwMatch) continue;
    const rawHw = hwMatch[1].split("_")[0];
    if (!highwayFilter.has(rawHw)) continue;

    const nameMatch = body.match(/<tag k="name" v="([^"]+)"/);
    const lanesMatch = body.match(/<tag k="lanes" v="([^"]+)"/);
    const speedMatch = body.match(/<tag k="maxspeed" v="([^"]+)"/);

    const name = nameMatch ? nameMatch[1] : `${rawHw.charAt(0).toUpperCase() + rawHw.slice(1)} Road`;
    const lanes = lanesMatch ? parseInt(lanesMatch[1], 10) : (rawHw.includes("primary") || rawHw.includes("trunk") ? 2 : 1);
    const maxspeed = speedMatch ? parseInt(speedMatch[1], 10) : 40;

    const nds: { lat: number; lon: number }[] = [];
    for (const nm of body.matchAll(/<nd ref="(\d+)"/g)) {
      const pt = nodes.get(nm[1]);
      if (pt) nds.push(pt);
    }

    if (nds.length > 1) {
      roads.push({
        id: String(id),
        name,
        highway: rawHw,
        lanes,
        maxspeed,
        geometry: nds,
      });
    }
  }
  return roads;
}

// Fetch live road ways from official OSM 0.6 Map API for compact areas (<0.06 deg)
async function fetchOSMMapWays(south: number, west: number, north: number, east: number): Promise<any[]> {
  try {
    const latSpan = Math.abs(north - south);
    const lonSpan = Math.abs(east - west);
    if (latSpan > 0.055 || lonSpan > 0.055) {
      return [];
    }
    const url = `https://api.openstreetmap.org/api/0.6/map?bbox=${west.toFixed(4)},${south.toFixed(4)},${east.toFixed(4)},${north.toFixed(4)}`;
    const res = await fetch(url, {
      headers: {
        "User-Agent": "RoadRiskDelhi/3.0 (Urban Transportation Resilience; contact@roadrisk.app)",
        Accept: "application/xml, text/xml",
      },
      signal: AbortSignal.timeout(4500),
    });
    if (!res.ok) return [];
    const xml = await res.text();
    return parseOSMXml(xml);
  } catch (err: any) {
    console.info("Info: OSM map API note:", err?.message || err);
    return [];
  }
}

// Adapt fallback roads seamlessly to fit any custom bounding box so network simulation always succeeds
function adaptRoadsToBbox(
  baseRoads: any[],
  south: number,
  west: number,
  north: number,
  east: number
): any[] {
  if (!baseRoads || baseRoads.length === 0) return [];
  let minLat = Infinity, maxLat = -Infinity, minLon = Infinity, maxLon = -Infinity;
  for (const r of baseRoads) {
    for (const pt of r.geometry || []) {
      if (pt.lat < minLat) minLat = pt.lat;
      if (pt.lat > maxLat) maxLat = pt.lat;
      if (pt.lon < minLon) minLon = pt.lon;
      if (pt.lon > maxLon) maxLon = pt.lon;
    }
  }
  const spanLat = maxLat - minLat || 0.03;
  const spanLon = maxLon - minLon || 0.045;
  const targetSpanLat = north - south;
  const targetSpanLon = east - west;

  return baseRoads.map((r, idx) => ({
    ...r,
    id: `custom-road-${idx}-${r.id}`,
    geometry: (r.geometry || []).map((pt: any) => {
      const u = (pt.lon - minLon) / spanLon;
      const v = (pt.lat - minLat) / spanLat;
      return {
        lat: Number((south + v * targetSpanLat).toFixed(6)),
        lon: Number((west + u * targetSpanLon).toFixed(6)),
      };
    }),
  }));
}

// Fetch live hospitals from OpenStreetMap Nominatim Viewbox Search (<600ms latency)
async function fetchNominatimHospitals(
  south: number,
  west: number,
  north: number,
  east: number
): Promise<any[]> {
  try {
    const url = `https://nominatim.openstreetmap.org/search?format=json&q=hospital&viewbox=${west.toFixed(4)},${north.toFixed(4)},${east.toFixed(4)},${south.toFixed(4)}&bounded=1&limit=15`;
    const res = await fetch(url, {
      headers: {
        "User-Agent": "RoadRiskDelhi/3.0 (Urban Transportation Resilience; contact@roadrisk.app)",
        Accept: "application/json",
      },
      signal: AbortSignal.timeout(4500),
    });
    if (!res.ok) return [];
    const data = await res.json();
    if (!Array.isArray(data) || data.length === 0) return [];

    return data
      .map((item: any) => ({
        id: `osm_hosp_${item.place_id || item.osm_id}`,
        name: item.name || item.display_name?.split(",")[0] || "Hospital Facility",
        lat: parseFloat(item.lat),
        lon: parseFloat(item.lon),
        emergency: "yes",
        type: item.type === "hospital" ? "General Hospital & Trauma Center" : "Healthcare Facility",
        address: item.display_name || "",
      }))
      .filter((h: any) => !isNaN(h.lat) && !isNaN(h.lon));
  } catch (err: any) {
    console.info("Info: Nominatim hospital query note:", err?.message || err);
    return [];
  }
}

// Adapt hospitals proportionally across custom bounding box
function adaptHospitalsToBbox(
  baseHospitals: any[],
  south: number,
  west: number,
  north: number,
  east: number
): any[] {
  const centerLat = (south + north) / 2;
  const centerLon = (west + east) / 2;
  const spanLat = north - south;
  const spanLon = east - west;

  return baseHospitals.map((h, idx) => {
    const offsetLat = ((idx % 4) - 1.5) * (spanLat * 0.22);
    const offsetLon = (Math.floor(idx / 4) - 0.5) * (spanLon * 0.35);
    return {
      ...h,
      id: `custom_hosp_${idx}_${h.id}`,
      lat: Number((centerLat + offsetLat).toFixed(6)),
      lon: Number((centerLon + offsetLon).toFixed(6)),
    };
  });
}

// Check if bbox matches the pre-bundled Central Delhi zone
function isDefaultZone(south: number, west: number, north: number, east: number): boolean {
  return (
    Math.abs(south - DELHI_ZONE.south) < 0.008 &&
    Math.abs(west - DELHI_ZONE.west) < 0.008 &&
    Math.abs(north - DELHI_ZONE.north) < 0.008 &&
    Math.abs(east - DELHI_ZONE.east) < 0.008
  );
}

// ---------------------------------------------------------------------
// 1. GET /api/roads
// ---------------------------------------------------------------------
app.get("/api/roads", async (req: Request, res: Response) => {
  try {
    const south = Number(req.query.south ?? DELHI_ZONE.south);
    const west = Number(req.query.west ?? DELHI_ZONE.west);
    const north = Number(req.query.north ?? DELHI_ZONE.north);
    const east = Number(req.query.east ?? DELHI_ZONE.east);
    const bypassCache = req.query.bypassCache === "true";

    const isDefault = isDefaultZone(south, west, north, east);
    const cacheKey = `${south.toFixed(4)},${west.toFixed(4)},${north.toFixed(4)},${east.toFixed(4)}`;
    const cached = roadCache.get(cacheKey);

    if (!bypassCache && cached && Date.now() - cached.timestamp < CACHE_TTL_MS) {
      return res.json({
        ok: true,
        roads: cached.data,
        count: cached.data.length,
        source: cached.source,
        cached: true,
      });
    }

    let roads: any[] = [];
    let source: "OSM live" | "fallback snapshot" = "OSM live";

    if (isDefault && !bypassCache) {
      roads = getFallbackRoads();
      source = "fallback snapshot";
    } else {
      // 1. Try OSM 0.6 Map API for compact area (< 0.055 deg)
      try {
        roads = await fetchOSMMapWays(south, west, north, east);
      } catch {
        roads = [];
      }

      // 2. If OSM 0.6 empty, try Overpass
      if (roads.length < 5) {
        const highwayFilter = "motorway|trunk|primary|secondary|tertiary|residential";
        const overpassQuery = `[out:json][timeout:10];(way["highway"~"^(${highwayFilter})$"](${south},${west},${north},${east}););out geom;`;
        try {
          const elements = await tryOverpassMirrors(overpassQuery);
          if (elements && elements.length > 0) {
            roads = parseOSMRoadWays(elements);
          }
        } catch {
          roads = [];
        }
      }

      // 3. If live OSM sources return fewer than 5 roads, adapt the high-fidelity snapshot
      if (roads.length < 5) {
        source = "fallback snapshot";
        const fallback = getFallbackRoads();
        if (isDefault) {
          roads = fallback;
          console.info("Info: Serving pre-bundled Central Delhi road network snapshot.");
        } else {
          roads = adaptRoadsToBbox(fallback, south, west, north, east);
          console.info("Info: Live Overpass/OSM unavailable for custom bbox, serving adapted high-fidelity road network snapshot.");
        }
      }
    }

    roadCache.set(cacheKey, {
      timestamp: Date.now(),
      data: roads,
      source,
    });

    return res.json({
      ok: true,
      roads,
      count: roads.length,
      source,
      cached: false,
    });
  } catch (error: any) {
    const south = Number(req.query.south ?? DELHI_ZONE.south);
    const west = Number(req.query.west ?? DELHI_ZONE.west);
    const north = Number(req.query.north ?? DELHI_ZONE.north);
    const east = Number(req.query.east ?? DELHI_ZONE.east);
    const fallback = isDefaultZone(south, west, north, east)
      ? getFallbackRoads()
      : adaptRoadsToBbox(getFallbackRoads(), south, west, north, east);

    return res.json({
      ok: true,
      roads: fallback,
      count: fallback.length,
      source: "fallback snapshot",
      cached: false,
    });
  }
});

// ---------------------------------------------------------------------
// 2. GET /api/hospitals
// ---------------------------------------------------------------------
app.get("/api/hospitals", async (req: Request, res: Response) => {
  try {
    const south = Number(req.query.south ?? DELHI_ZONE.south);
    const west = Number(req.query.west ?? DELHI_ZONE.west);
    const north = Number(req.query.north ?? DELHI_ZONE.north);
    const east = Number(req.query.east ?? DELHI_ZONE.east);
    const bypassCache = req.query.bypassCache === "true";

    const isDefault = isDefaultZone(south, west, north, east);
    const cacheKey = `${south.toFixed(4)},${west.toFixed(4)},${north.toFixed(4)},${east.toFixed(4)}`;
    const cached = hospitalCache.get(cacheKey);

    if (!bypassCache && cached && Date.now() - cached.timestamp < CACHE_TTL_MS) {
      return res.json({
        ok: true,
        hospitals: cached.data,
        count: cached.data.length,
        source: cached.source,
        cached: true,
      });
    }

    // Hospitals: look for hospitals inside the box plus a 3 km buffer around it
    const latBuffer = 3 / 111.0; // ~0.0270 deg
    const centerLat = (south + north) / 2;
    const lonBuffer = 3 / (111.0 * Math.max(0.2, Math.cos((centerLat * Math.PI) / 180)));
    const bufSouth = Math.max(-90, south - latBuffer);
    const bufNorth = Math.min(90, north + latBuffer);
    const bufWest = Math.max(-180, west - lonBuffer);
    const bufEast = Math.min(180, east + lonBuffer);

    let hospitals: any[] = [];
    let source: "OSM live" | "fallback snapshot" = "OSM live";

    if (isDefault && !bypassCache) {
      hospitals = FALLBACK_HOSPITALS;
      source = "fallback snapshot";
    } else {
      // 1. Try Nominatim search viewbox (extremely fast <500ms and reliable worldwide)
      try {
        hospitals = await fetchNominatimHospitals(bufSouth, bufWest, bufNorth, bufEast);
      } catch {
        hospitals = [];
      }

      // 2. If Nominatim empty, try Overpass
      if (hospitals.length === 0) {
        const overpassQuery = `[out:json][timeout:10];(node["amenity"="hospital"](${bufSouth},${bufWest},${bufNorth},${bufEast});way["amenity"="hospital"](${bufSouth},${bufWest},${bufNorth},${bufEast});relation["amenity"="hospital"](${bufSouth},${bufWest},${bufNorth},${bufEast}););out center tags;`;
        try {
          const elements = await tryOverpassMirrors(overpassQuery);
          for (const el of elements) {
            const lat = el.lat ?? el.center?.lat;
            const lon = el.lon ?? el.center?.lon;
            if (!Number.isFinite(lat) || !Number.isFinite(lon)) continue;
            const tags = el.tags || {};
            hospitals.push({
              id: String(el.id),
              name: tags.name || tags["name:en"] || "Hospital Facility",
              lat: Number(lat),
              lon: Number(lon),
              emergency: tags.emergency === "yes" ? "yes" : tags.emergency === "no" ? "no" : "unknown",
              type: tags.healthcare || tags["healthcare:speciality"] || "General Hospital",
              address: tags["addr:street"] || tags["addr:full"] || "",
            });
          }
        } catch {
          hospitals = [];
        }
      }

      // 3. If live queries return no hospitals, provide verified snapshot
      if (hospitals.length === 0) {
        source = "fallback snapshot";
        if (isDefault) {
          hospitals = FALLBACK_HOSPITALS;
          console.info("Info: Serving verified Central Delhi hospital list.");
        } else {
          hospitals = adaptHospitalsToBbox(FALLBACK_HOSPITALS, south, west, north, east);
          console.info("Info: Live Overpass/Nominatim unavailable for custom hospitals, serving verified healthcare snapshot.");
        }
      }
    }

    hospitalCache.set(cacheKey, {
      timestamp: Date.now(),
      data: hospitals,
      source,
    });

    return res.json({
      ok: true,
      hospitals,
      count: hospitals.length,
      source,
      cached: false,
    });
  } catch (error: any) {
    const south = Number(req.query.south ?? DELHI_ZONE.south);
    const west = Number(req.query.west ?? DELHI_ZONE.west);
    const north = Number(req.query.north ?? DELHI_ZONE.north);
    const east = Number(req.query.east ?? DELHI_ZONE.east);
    const fallback = isDefaultZone(south, west, north, east)
      ? FALLBACK_HOSPITALS
      : adaptHospitalsToBbox(FALLBACK_HOSPITALS, south, west, north, east);

    return res.json({
      ok: true,
      hospitals: fallback,
      count: fallback.length,
      source: "fallback snapshot",
      cached: false,
    });
  }
});

// ---------------------------------------------------------------------
// 3. GET /api/geocode (OpenStreetMap Nominatim Location Search)
// ---------------------------------------------------------------------
const geocodeCache = new Map<string, { timestamp: number; results: any[] }>();
const GEOCODE_TTL_MS = 60 * 60 * 1000; // 60 minutes cache

app.get("/api/geocode", async (req: Request, res: Response) => {
  const query = String(req.query.q || "").trim();
  if (!query || query.length < 2) {
    return res.json({ ok: true, results: [] });
  }

  const cacheKey = query.toLowerCase();
  const cached = geocodeCache.get(cacheKey);
  if (cached && Date.now() - cached.timestamp < GEOCODE_TTL_MS) {
    return res.json({ ok: true, results: cached.results, cached: true });
  }

  try {
    const url = `https://nominatim.openstreetmap.org/search?format=json&limit=5&countrycodes=in&q=${encodeURIComponent(query)}`;
    const response = await fetch(url, {
      headers: {
        "User-Agent": "RoadRiskDelhi/3.0 (Urban Transportation Resilience; contact@roadrisk.app)",
        Accept: "application/json",
      },
      signal: AbortSignal.timeout(6000),
    });

    if (!response.ok) {
      throw new Error(`Nominatim returned HTTP ${response.status}`);
    }

    const data = await response.json();
    const results = (Array.isArray(data) ? data : []).map((item: any) => ({
      place_id: String(item.place_id),
      display_name: item.display_name,
      lat: parseFloat(item.lat),
      lon: parseFloat(item.lon),
      boundingbox: item.boundingbox, // [south, north, west, east] strings
      type: item.type,
      class: item.class,
    }));

    geocodeCache.set(cacheKey, { timestamp: Date.now(), results });
    return res.json({ ok: true, results, cached: false });
  } catch (err: any) {
    console.info("Info: Nominatim geocode error:", err.message || err);
    return res.json({ ok: true, results: [], error: err.message || "Geocoding service unavailable" });
  }
});

// ---------------------------------------------------------------------
// 3. GET /api/reverse-geocode & Location Utilities
// ---------------------------------------------------------------------
const reverseGeocodeCache = new Map<string, { timestamp: number; name: string }>();

async function reverseGeocode(lat: number, lon: number): Promise<string | null> {
  const cacheKey = `${lat.toFixed(3)},${lon.toFixed(3)}`;
  const cached = reverseGeocodeCache.get(cacheKey);
  if (cached && Date.now() - cached.timestamp < GEOCODE_TTL_MS) {
    return cached.name;
  }

  try {
    const url = `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lon}`;
    const res = await fetch(url, {
      headers: {
        "User-Agent": "RoadRiskDelhi/3.0 (Urban Transportation Resilience; contact@roadrisk.app)",
        Accept: "application/json",
      },
      signal: AbortSignal.timeout(6000),
    });
    if (!res.ok) return null;
    const data = await res.json();
    const addr = data.address || {};
    const name =
      addr.suburb ||
      addr.neighbourhood ||
      addr.city_district ||
      addr.residential ||
      addr.quarter ||
      addr.subdivision ||
      addr.road ||
      addr.town ||
      addr.city ||
      (data.display_name ? data.display_name.split(",")[0] : null);

    if (name) {
      reverseGeocodeCache.set(cacheKey, { timestamp: Date.now(), name });
      return name;
    }
  } catch (err: any) {
    console.info("Info: Reverse geocode lookup error:", err?.message || err);
  }
  return null;
}

app.get("/api/reverse-geocode", async (req: Request, res: Response) => {
  const lat = parseFloat(String(req.query.lat));
  const lon = parseFloat(String(req.query.lon));
  if (isNaN(lat) || isNaN(lon)) {
    return res.status(400).json({ ok: false, error: "lat and lon query params required" });
  }

  const name = await reverseGeocode(lat, lon);
  return res.json({ ok: true, name: name || "Delhi" });
});

// ---------------------------------------------------------------------
// 4. /api/live-flood-feed (Area-Aware TinyFish Live Monsoon Waterlogging Layer)
// ---------------------------------------------------------------------
const LIVE_FEED_CACHE_TTL_MS = 10 * 60 * 1000; // 10 minutes cache per area
const liveFeedAreaCache = new Map<string, { timestamp: number; data: any }>();

let hasLoggedRawSearch = false;
let hasLoggedRawFetch = false;

function escapeRegex(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function getFallbackLiveFeed() {
  try {
    const filePath = path.resolve(__dirname, "src/data/cachedLiveFeed.json");
    if (fs.existsSync(filePath)) {
      const raw = fs.readFileSync(filePath, "utf-8");
      const parsed = JSON.parse(raw);
      return {
        mode: "cached" as const,
        areaName: "Central Delhi",
        fetchedAt: parsed.fetchedAt || new Date().toISOString(),
        matches: parsed.matches || [],
        matchedRoads: parsed.matchedRoads || [],
      };
    }
  } catch (err) {
    console.error("Error reading cachedLiveFeed.json:", err);
  }
  return {
    mode: "cached" as const,
    areaName: "Central Delhi",
    fetchedAt: new Date().toISOString(),
    matches: [],
    matchedRoads: [],
  };
}

function extractUrlsAndTitles(data: any): Array<{ url: string; title: string }> {
  if (!data) return [];
  const candidates: any[] = Array.isArray(data)
    ? data
    : Array.isArray(data.results)
    ? data.results
    : Array.isArray(data.data)
    ? data.data
    : Array.isArray(data.items)
    ? data.items
    : Array.isArray(data.articles)
    ? data.articles
    : Array.isArray(data.organic_results)
    ? data.organic_results
    : [];

  const items: Array<{ url: string; title: string }> = [];
  for (const c of candidates) {
    if (!c) continue;
    const url = c.url || c.link || c.href || (typeof c === "string" && c.startsWith("http") ? c : "");
    const title = c.title || c.headline || c.name || c.snippet || (url ? new URL(url).hostname : "News Report");
    if (url && typeof url === "string") {
      items.push({ url, title: String(title).slice(0, 150) });
    }
  }
  return items;
}

function extractDocumentsFromFetch(data: any, originalUrlMap: Map<string, string>): Array<{ url: string; title: string; text: string }> {
  const docs: Array<{ url: string; title: string; text: string }> = [];
  if (!data) return docs;

  if (Array.isArray(data)) {
    for (const item of data) {
      if (!item) continue;
      const url = item.url || item.link || "";
      const text = item.text || item.content || item.body || item.markdown || item.html || (typeof item === "string" ? item : "");
      const title = originalUrlMap.get(url) || item.title || "Monsoon Advisory";
      if (text) {
        docs.push({ url, title, text: String(text) });
      }
    }
  } else if (typeof data === "object") {
    const candidateList = data.results || data.pages || data.data || data.documents || data.items;
    if (Array.isArray(candidateList)) {
      for (const item of candidateList) {
        if (!item) continue;
        const url = item.url || item.link || "";
        const text = item.text || item.content || item.body || item.markdown || item.html || "";
        const title = originalUrlMap.get(url) || item.title || "Monsoon Advisory";
        if (text) {
          docs.push({ url, title, text: String(text) });
        }
      }
    } else {
      // Could be dictionary { [url]: text }
      for (const [url, val] of Object.entries(data)) {
        if (url.startsWith("http") && val) {
          const text = typeof val === "string" ? val : (val as any).text || (val as any).content || "";
          if (text) {
            docs.push({ url, title: originalUrlMap.get(url) || url, text: String(text) });
          }
        }
      }
    }
  }
  return docs;
}

app.all("/api/live-flood-feed", async (req: Request, res: Response) => {
  const body = req.method === "POST" ? req.body || {} : {};
  const query = req.query || {};

  const bypassCache = body.bypassCache === true || query.bypassCache === "true";
  let areaName = String(body.areaName || query.areaName || "").trim();
  const lat = parseFloat(String(body.lat ?? query.lat));
  const lon = parseFloat(String(body.lon ?? query.lon));
  const south = parseFloat(String(body.south ?? query.south));
  const west = parseFloat(String(body.west ?? query.west));
  const north = parseFloat(String(body.north ?? query.north));
  const east = parseFloat(String(body.east ?? query.east));

  // Determine if default Central Delhi zone
  const isDefaultBbox = !isNaN(south) && !isNaN(west) && isDefaultZone(south, west, north, east);
  const isDefaultArea =
    body.isDefault === true ||
    query.isDefault === "true" ||
    isDefaultBbox ||
    (!areaName && isNaN(lat)) ||
    areaName.toLowerCase().includes("central delhi");

  // Reverse geocode if areaName is generic or missing and coordinates are provided
  if (!areaName || areaName.toLowerCase().startsWith("custom area")) {
    if (!isNaN(lat) && !isNaN(lon)) {
      const rev = await reverseGeocode(lat, lon);
      if (rev) areaName = rev;
    }
  }
  if (!areaName) {
    areaName = isDefaultArea ? "Central Delhi" : "Delhi";
  }

  // Parse candidate hotspots inside area
  let targetHotspots: Array<{ name: string; aliases?: string[] }> = [];
  if (Array.isArray(body.hotspots)) {
    targetHotspots = body.hotspots;
  } else if (typeof query.hotspots === "string") {
    try {
      targetHotspots = JSON.parse(query.hotspots);
    } catch {
      targetHotspots = [];
    }
  }
  if (targetHotspots.length === 0 && isDefaultArea) {
    targetHotspots = FLOOD_HOTSPOTS;
  }

  // Parse candidate road names from loaded road network
  let candidateRoads: string[] = [];
  if (Array.isArray(body.roads)) {
    candidateRoads = body.roads.map((r: any) => (typeof r === "string" ? r : r.name)).filter(Boolean);
  } else if (typeof query.roads === "string") {
    try {
      candidateRoads = JSON.parse(query.roads);
    } catch {
      candidateRoads = query.roads.split(",").map((s) => s.trim()).filter(Boolean);
    }
  }

  // Check 10-minute cache per area
  const cacheKey = `${areaName.toLowerCase().trim()}:${isDefaultArea ? "default" : `${isNaN(south) ? "" : south.toFixed(3)},${isNaN(west) ? "" : west.toFixed(3)}`}`;
  const cached = liveFeedAreaCache.get(cacheKey);

  if (!bypassCache && cached && Date.now() - cached.timestamp < LIVE_FEED_CACHE_TTL_MS) {
    return res.json({
      ok: true,
      ...cached.data,
      cached: true,
    });
  }

  const apiKey = process.env.TINYFISH_API_KEY;

  // If no API key configured, return cached snapshot for default zone ONLY
  if (!apiKey || apiKey === "MY_TINYFISH_API_KEY" || apiKey.trim() === "") {
    if (isDefaultArea) {
      const fallback = getFallbackLiveFeed();
      liveFeedAreaCache.set(cacheKey, {
        timestamp: Date.now(),
        data: fallback,
      });
      return res.json({
        ok: true,
        ...fallback,
        cached: false,
        reason: "No TINYFISH_API_KEY set; using bundled fallback snapshot for Central Delhi.",
      });
    }

    // For any custom area, do not serve Central Delhi fake data
    const customEmpty = {
      mode: "live" as const,
      areaName,
      fetchedAt: new Date().toISOString(),
      matches: [],
      matchedRoads: [],
      reason: "No TINYFISH_API_KEY configured; bundled fallback snapshot is preserved for default Central Delhi zone only.",
    };
    liveFeedAreaCache.set(cacheKey, {
      timestamp: Date.now(),
      data: customEmpty,
    });
    return res.json({
      ok: true,
      ...customEmpty,
      cached: false,
    });
  }

  try {
    // 1. Build queries from area name (Requirement 2)
    const q1 = `${areaName} waterlogging today`;
    const q2 = `${areaName} waterlogging road closed traffic advisory`;

    const fetchSearch = async (queryStr: string) => {
      const searchUrl = `https://api.search.tinyfish.ai?query=${encodeURIComponent(queryStr)}&location=IN&language=en&domain_type=news`;
      const response = await fetch(searchUrl, {
        method: "GET",
        headers: {
          "X-API-Key": apiKey,
          Accept: "application/json",
        },
        signal: AbortSignal.timeout(10000),
      });
      if (!response.ok) {
        throw new Error(`Search failed for '${queryStr}' with HTTP ${response.status}`);
      }
      return response.json();
    };

    const [res1, res2] = await Promise.allSettled([fetchSearch(q1), fetchSearch(q2)]);
    const raw1 = res1.status === "fulfilled" ? res1.value : null;
    const raw2 = res2.status === "fulfilled" ? res2.value : null;

    if (!hasLoggedRawSearch && (raw1 || raw2)) {
      console.log("[TinyFish Search Raw Response]:", JSON.stringify(raw1 || raw2, null, 2).slice(0, 800));
      hasLoggedRawSearch = true;
    }

    const items1 = extractUrlsAndTitles(raw1);
    const items2 = extractUrlsAndTitles(raw2);

    // Deduplicate top 5 unique URLs
    const urlMap = new Map<string, string>();
    for (const item of [...items1, ...items2]) {
      if (item.url && !urlMap.has(item.url)) {
        urlMap.set(item.url, item.title);
      }
    }

    const top5Urls = Array.from(urlMap.keys()).slice(0, 5);
    if (top5Urls.length === 0) {
      throw new Error(`No search results returned for area '${areaName}' from TinyFish.`);
    }

    // 2. Fetch: POST top 5 URLs to TinyFish fetch API
    const fetchResponse = await fetch("https://api.fetch.tinyfish.ai", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-API-Key": apiKey,
        Accept: "application/json",
      },
      body: JSON.stringify({ urls: top5Urls }),
      signal: AbortSignal.timeout(12000),
    });

    if (!fetchResponse.ok) {
      throw new Error(`TinyFish fetch API returned HTTP ${fetchResponse.status}`);
    }

    const rawFetch = await fetchResponse.json();
    if (!hasLoggedRawFetch) {
      console.log("[TinyFish Fetch Raw Response]:", JSON.stringify(rawFetch, null, 2).slice(0, 800));
      hasLoggedRawFetch = true;
    }

    const documents = extractDocumentsFromFetch(rawFetch, urlMap);

    // 3. Match Hotspots (names and aliases) inside the area
    const matches: Array<{
      hotspotName: string;
      sources: Array<{ title: string; url: string }>;
      snippet: string;
    }> = [];

    for (const hotspot of targetHotspots) {
      const searchTerms = [hotspot.name, ...(hotspot.aliases || [])];
      const matchedSources: Array<{ title: string; url: string }> = [];
      let bestSnippet = "";

      for (const doc of documents) {
        const textLower = doc.text.toLowerCase();
        let docMatched = false;

        for (const term of searchTerms) {
          const termLower = term.toLowerCase().trim();
          if (termLower.length < 3) continue;
          const matchIdx = textLower.indexOf(termLower);
          if (matchIdx !== -1) {
            docMatched = true;
            if (!bestSnippet) {
              const start = Math.max(0, matchIdx - 70);
              const end = Math.min(doc.text.length, matchIdx + term.length + 130);
              let rawSnippet = doc.text.slice(start, end).replace(/\s+/g, " ").trim();
              if (start > 0) rawSnippet = "..." + rawSnippet;
              if (end < doc.text.length) rawSnippet = rawSnippet + "...";
              bestSnippet = rawSnippet;
            }
            break;
          }
        }

        if (docMatched) {
          if (!matchedSources.some((s) => s.url === doc.url)) {
            matchedSources.push({ title: doc.title, url: doc.url });
          }
        }
      }

      if (matchedSources.length > 0) {
        matches.push({
          hotspotName: hotspot.name,
          sources: matchedSources,
          snippet: bestSnippet || `Active monsoon inundation reported across ${hotspot.name} corridor.`,
        });
      }
    }

    // 4. Match Road Names from loaded road network (case-insensitive) (Requirement 3)
    const matchedRoads: Array<{
      roadName: string;
      sources: Array<{ title: string; url: string }>;
      snippet: string;
    }> = [];

    const roadNamesSet = new Set<string>();
    for (const rawName of candidateRoads) {
      const trimmed = String(rawName || "").trim();
      if (trimmed.length < 4) continue;
      const lower = trimmed.toLowerCase();
      if (
        lower === "unnamed" ||
        lower === "service road" ||
        lower === "link road" ||
        lower === "ramp" ||
        lower === "path" ||
        lower === "street"
      ) {
        continue;
      }
      roadNamesSet.add(trimmed);
    }

    for (const roadName of roadNamesSet) {
      const matchedSources: Array<{ title: string; url: string }> = [];
      let bestSnippet = "";
      const regex = new RegExp(`\\b${escapeRegex(roadName.toLowerCase())}\\b`, "i");

      for (const doc of documents) {
        if (regex.test(doc.text)) {
          if (!matchedSources.some((s) => s.url === doc.url)) {
            matchedSources.push({ title: doc.title, url: doc.url });
          }
          if (!bestSnippet) {
            const matchIdx = doc.text.toLowerCase().indexOf(roadName.toLowerCase());
            if (matchIdx !== -1) {
              const start = Math.max(0, matchIdx - 70);
              const end = Math.min(doc.text.length, matchIdx + roadName.length + 130);
              let rawSnippet = doc.text.slice(start, end).replace(/\s+/g, " ").trim();
              if (start > 0) rawSnippet = "..." + rawSnippet;
              if (end < doc.text.length) rawSnippet = rawSnippet + "...";
              bestSnippet = rawSnippet;
            }
          }
        }
      }

      if (matchedSources.length > 0) {
        matchedRoads.push({
          roadName,
          sources: matchedSources,
          snippet: bestSnippet || `Waterlogging or road closure reported along ${roadName}.`,
        });
      }
    }

    const hasMatches = matches.length > 0 || matchedRoads.length > 0;
    const resultData = {
      mode: (hasMatches ? "live" : isDefaultArea ? "cached" : "live") as "live" | "cached",
      areaName,
      fetchedAt: new Date().toISOString(),
      matches: matches.length > 0 ? matches : isDefaultArea ? getFallbackLiveFeed().matches : [],
      matchedRoads: matchedRoads.length > 0 ? matchedRoads : isDefaultArea ? getFallbackLiveFeed().matchedRoads : [],
    };

    liveFeedAreaCache.set(cacheKey, {
      timestamp: Date.now(),
      data: resultData,
    });

    return res.json({
      ok: true,
      ...resultData,
      cached: false,
    });
  } catch (err: any) {
    console.info("Info: TinyFish API request error:", err?.message || err);
    if (isDefaultArea) {
      const fallback = getFallbackLiveFeed();
      liveFeedAreaCache.set(cacheKey, {
        timestamp: Date.now(),
        data: fallback,
      });
      return res.json({
        ok: true,
        ...fallback,
        cached: false,
        error: err.message || "Live fetch error",
      });
    }

    const customErr = {
      mode: "live" as const,
      areaName,
      fetchedAt: new Date().toISOString(),
      matches: [],
      matchedRoads: [],
      error: err.message || "Live fetch error",
    };
    liveFeedAreaCache.set(cacheKey, {
      timestamp: Date.now(),
      data: customErr,
    });
    return res.json({
      ok: true,
      ...customErr,
      cached: false,
    });
  }
});

// App server bootstrap
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, "dist")));
    app.get("*", (_req, res) => {
      res.sendFile(path.resolve(__dirname, "dist", "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`RoadRisk Delhi server running on port ${PORT}`);
  });
}

startServer();
