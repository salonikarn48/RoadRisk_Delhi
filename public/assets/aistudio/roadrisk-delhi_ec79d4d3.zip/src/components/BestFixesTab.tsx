import React, { useState, useMemo } from "react";
import {
  Award,
  Sliders,
  DollarSign,
  Clock,
  Zap,
  Building,
  CheckCircle2,
  Info,
  TrendingUp,
  Sparkles,
  ShieldCheck,
  ChevronRight,
  ArrowRight,
  Droplets,
  Layers,
  Heart,
  AlertTriangle,
} from "lucide-react";
import {
  analyzeBestFixes,
  BestFixesAnalysisResult,
  FixPlan,
  HotspotEvaluation,
} from "../simulation/bestFixesEngine";
import { COST_DISCLAIMER } from "../data/fixCosts";
import { RainfallLevel } from "../simulation/whatIfEngine";

export interface BestFixesTabProps {
  graph: any;
  roads: any[];
  odPairs: any[];
  hospitals: any[];
  rainfallLevel: RainfallLevel;
  onSimulateHotspotFix?: (hotspotId: string) => void;
  onNavigateToWhatIf?: () => void;
  targetHotspots?: any[];
}

export default function BestFixesTab({
  graph,
  roads,
  odPairs,
  hospitals,
  rainfallLevel,
  onSimulateHotspotFix,
  onNavigateToWhatIf,
  targetHotspots,
}: BestFixesTabProps) {
  // Policy Weights: Default 50% Connectivity / 50% Hospital Access
  const [connectivityWeight, setConnectivityWeight] = useState<number>(0.5);
  const hospitalWeight = useMemo(() => Number((1.0 - connectivityWeight).toFixed(2)), [connectivityWeight]);

  // Equity-Aware Toggle
  const [isEquityAware, setIsEquityAware] = useState<boolean>(false);

  // Budget Selection: Default ₹10 Cr
  const [budgetCr, setBudgetCr] = useState<number>(10.0);
  const [isCustomBudget, setIsCustomBudget] = useState<boolean>(false);

  // If the selected area has no surveyed flood hotspots
  if (targetHotspots && targetHotspots.length === 0) {
    return (
      <div className="p-4 rounded-lg bg-[#0e131d] border border-[#1e2a3c] text-center space-y-3">
        <div className="w-9 h-9 rounded-full bg-amber-950/60 border border-amber-600/40 text-amber-400 flex items-center justify-center mx-auto">
          <Info className="w-4 h-4" />
        </div>
        <div className="font-bold text-white text-xs uppercase tracking-wider font-mono">
          No Hotspots in Selected Area
        </div>
        <p className="text-xs text-slate-300 font-sans leading-relaxed max-w-sm mx-auto">
          No surveyed waterlogging hotspots in this selected area. You can still simulate manual road closures on the map, or reset to Central Delhi to test the Pareto fix optimizer.
        </p>
      </div>
    );
  }

  // Compute Best Fixes Optimization
  const analysis: BestFixesAnalysisResult | null = useMemo(() => {
    return analyzeBestFixes({
      graph,
      roads,
      odPairs,
      hospitals,
      rainfallLevel,
      weights: { connectivity: connectivityWeight, hospital: hospitalWeight },
      budgetCr,
      isEquityAware,
      targetHotspots,
    });
  }, [graph, roads, odPairs, hospitals, rainfallLevel, connectivityWeight, hospitalWeight, budgetCr, isEquityAware, targetHotspots]);

  if (!analysis) {
    return (
      <div className="p-4 rounded bg-[#0f1420] border border-[#1e2736] text-center text-xs text-slate-400 space-y-2">
        <Info className="w-5 h-5 text-slate-500 mx-auto" />
        <div>Awaiting network graph and road demand matrix initialization...</div>
      </div>
    );
  }

  if (targetHotspots && targetHotspots.length === 0) {
    return (
      <div className="space-y-4 font-mono text-xs">
        <div className="p-4 rounded-lg bg-[#0f1420] border border-[#1e2736] text-center space-y-3">
          <AlertTriangle className="w-6 h-6 text-amber-400 mx-auto" />
          <div className="text-sm font-bold text-white uppercase tracking-wider">No Known Waterlogging Hotspots</div>
          <p className="text-slate-400 text-xs font-sans max-w-sm mx-auto leading-relaxed">
            The municipal fix optimizer evaluates capital vs quick interventions for known flood hotspots. No mapped hotspots exist in this bounding box.
          </p>
          <div className="p-3 rounded bg-[#090d14] border border-[#23354c] text-[11px] text-amber-300 font-sans leading-relaxed">
            No known waterlogging hotspots here. Click any road on the map to simulate a closure, or use Live Feed.
          </div>
          {onNavigateToWhatIf && (
            <button
              type="button"
              onClick={onNavigateToWhatIf}
              className="px-3 py-1.5 rounded bg-cyan-950 border border-cyan-500/60 text-cyan-300 text-xs font-bold cursor-pointer hover:bg-cyan-900 transition-colors"
            >
              Go to What-If Tab &rarr;
            </button>
          )}
        </div>
      </div>
    );
  }

  const { bestPlan, quickOnlyPlan, capitalOnlyPlan, rankedHotspots, paretoPoints } = analysis;

  // SVG Pareto Chart Calculations (₹0 to ₹20 Cr)
  const svgWidth = 340;
  const svgHeight = 150;
  const padding = { top: 20, right: 25, bottom: 25, left: 35 };
  const chartW = svgWidth - padding.left - padding.right;
  const chartH = svgHeight - padding.top - padding.bottom;

  // X scale: 0 to 20 Cr
  const maxScaleBudget = 20.0;
  const getX = (cost: number) => padding.left + (Math.min(maxScaleBudget, Math.max(0, cost)) / maxScaleBudget) * chartW;
  // Y scale: 0% to 100%
  const getY = (rec: number) => padding.top + chartH - (Math.min(100, Math.max(0, rec)) / 100) * chartH;

  // Build step-path (Pareto style staircase)
  const paretoPath = useMemo(() => {
    if (!paretoPoints || paretoPoints.length === 0) return "";
    let d = `M ${getX(0)} ${getY(0)}`;
    let prevY = getY(0);

    for (const pt of paretoPoints) {
      const curX = getX(pt.costCr);
      const curY = getY(pt.recoveryPct);
      // Horizontal step, then vertical rise
      d += ` L ${curX} ${prevY} L ${curX} ${curY}`;
      prevY = curY;
    }
    // Extend to ₹20 Cr with current max recovery
    d += ` L ${getX(maxScaleBudget)} ${prevY}`;
    return d;
  }, [paretoPoints]);

  return (
    <div className="space-y-4 font-mono text-xs">
      {/* 1. TOP HEADER & OFFICIAL DISCLAIMER */}
      <div className="p-3.5 rounded bg-[#0f1715] border border-emerald-900/60 space-y-2.5">
        <div className="flex items-center justify-between border-b border-[#162723] pb-2">
          <div className="flex items-center gap-2">
            <Award className="w-4 h-4 text-emerald-400" />
            <span className="font-bold text-white uppercase tracking-wider text-xs">
              MUNICIPAL BEST-FIX RECOMMENDER
            </span>
          </div>
          <span className="text-[9px] px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-700 font-bold">
            CPWD/DSR CALIBRATED
          </span>
        </div>

        <p className="text-[11px] text-slate-300 font-sans leading-relaxed">
          Combinatorial optimization across Quick (pump + automated diversion) vs Capital (drainage culvert reconstruction) interventions to maximize network trip and hospital access protection.
        </p>

        {/* Mandatory CPWD Disclaimer */}
        <div className="p-2 rounded bg-[#080d0c] border border-[#142621] text-[9.5px] text-amber-300/90 flex items-center gap-1.5">
          <Info className="w-3.5 h-3.5 text-amber-400 shrink-0" />
          <span>Note: Every cost is <strong>indicative, calibrated to CPWD/DSR-style rates, not official quotes</strong>.</span>
        </div>
      </div>

      {/* 2. POLICY CONTROLS: SLIDERS & EQUITY TOGGLE */}
      <div className="p-3.5 rounded bg-[#0e1420] border border-[#1b2639] space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-[10px] font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
            <Sliders className="w-3.5 h-3.5 text-cyan-400" />
            <span>POLICY OBJECTIVE WEIGHTS</span>
          </span>
          <span className="text-cyan-300 font-bold text-[10.5px]">
            {Math.round(connectivityWeight * 100)}% Road / {Math.round(hospitalWeight * 100)}% Hospital
          </span>
        </div>

        {/* Connectivity vs Hospital Slider */}
        <div className="space-y-1.5">
          <input
            type="range"
            min="0"
            max="100"
            step="5"
            value={Math.round(connectivityWeight * 100)}
            onChange={(e) => setConnectivityWeight(Number(e.target.value) / 100)}
            className="w-full accent-cyan-400 cursor-pointer h-1.5 bg-[#172335] rounded-lg appearance-none"
          />
          <div className="flex justify-between text-[9px] text-slate-400">
            <span>100% Hospital Priority</span>
            <span className="text-slate-500 font-semibold">50/50 Balanced</span>
            <span>100% Connectivity Priority</span>
          </div>
        </div>

        {/* Equity-Aware Toggle */}
        <div className="pt-2 border-t border-[#172336] flex items-center justify-between gap-3">
          <div className="space-y-0.5">
            <div className="flex items-center gap-1.5 text-white font-bold text-xs">
              <Heart className={`w-3.5 h-3.5 ${isEquityAware ? "text-rose-400 fill-rose-400" : "text-slate-400"}`} />
              <span>Equity-aware prioritization</span>
            </div>
            <p className="text-[10px] text-slate-400 font-sans leading-tight">
              Multiplies recovery by a vulnerability weight (synthetic, labeled illustrative: transit dependency, public hospital gateway).
            </p>
          </div>
          <button
            type="button"
            onClick={() => setIsEquityAware(!isEquityAware)}
            className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer shrink-0 border ${
              isEquityAware
                ? "bg-rose-600 border-rose-400 shadow-[0_0_10px_rgba(244,63,94,0.5)]"
                : "bg-[#182333] border-[#293c56]"
            }`}
            aria-pressed={isEquityAware}
          >
            <span
              className={`block w-4 h-4 rounded-full bg-white transition-transform ${
                isEquityAware ? "translate-x-5" : "translate-x-1"
              }`}
            />
          </button>
        </div>
      </div>

      {/* 3. BUDGET SELECTOR */}
      <div className="p-3.5 rounded bg-[#0f1420] border border-[#1c293d] space-y-2.5">
        <div className="flex items-center justify-between">
          <span className="text-[10px] font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
            <DollarSign className="w-3.5 h-3.5 text-emerald-400" />
            <span>MUNICIPAL CAPITAL BUDGET ENVELOPE</span>
          </span>
          <span className="text-emerald-400 font-bold text-xs">₹{budgetCr.toFixed(1)} Cr</span>
        </div>

        {/* 3 Preset Options */}
        <div className="grid grid-cols-3 gap-1.5">
          <button
            type="button"
            onClick={() => {
              setBudgetCr(10.0);
              setIsCustomBudget(false);
            }}
            className={`py-2 px-1 rounded text-center transition-all cursor-pointer border ${
              budgetCr === 10.0 && !isCustomBudget
                ? "bg-emerald-950/80 border-emerald-400 text-emerald-200 font-bold shadow-sm"
                : "bg-[#090d14] border-[#1f2c40] text-slate-400 hover:text-white"
            }`}
          >
            <div className="text-[11px] font-bold">₹10 Cr</div>
            <div className="text-[8.5px] text-slate-500 mt-0.5">Target Budget</div>
          </button>

          <button
            type="button"
            onClick={() => {
              setBudgetCr(20.0);
              setIsCustomBudget(false);
            }}
            className={`py-2 px-1 rounded text-center transition-all cursor-pointer border ${
              budgetCr === 20.0 && !isCustomBudget
                ? "bg-emerald-950/80 border-emerald-400 text-emerald-200 font-bold shadow-sm"
                : "bg-[#090d14] border-[#1f2c40] text-slate-400 hover:text-white"
            }`}
          >
            <div className="text-[11px] font-bold">₹20 Cr</div>
            <div className="text-[8.5px] text-slate-500 mt-0.5">Extended Envelope</div>
          </button>

          <button
            type="button"
            onClick={() => setIsCustomBudget(true)}
            className={`py-2 px-1 rounded text-center transition-all cursor-pointer border ${
              isCustomBudget
                ? "bg-emerald-950/80 border-emerald-400 text-emerald-200 font-bold shadow-sm"
                : "bg-[#090d14] border-[#1f2c40] text-slate-400 hover:text-white"
            }`}
          >
            <div className="text-[11px] font-bold">Custom</div>
            <div className="text-[8.5px] text-slate-500 mt-0.5">Slider / Manual</div>
          </button>
        </div>

        {/* Custom Budget Slider */}
        {isCustomBudget && (
          <div className="space-y-1.5 pt-1 border-t border-[#1a2538]">
            <div className="flex justify-between items-center text-[10px] text-slate-400">
              <span>Select Custom Ceiling:</span>
              <span className="font-bold text-emerald-300">₹{budgetCr.toFixed(1)} Crore</span>
            </div>
            <input
              type="range"
              min="2"
              max="35"
              step="0.5"
              value={budgetCr}
              onChange={(e) => setBudgetCr(Number(e.target.value))}
              className="w-full accent-emerald-400 cursor-pointer h-1.5 bg-[#172335] rounded-lg appearance-none"
            />
            <div className="flex justify-between text-[8.5px] text-slate-500">
              <span>₹2 Cr</span>
              <span>₹15 Cr</span>
              <span>₹35 Cr</span>
            </div>
          </div>
        )}
      </div>

      {/* 4. "BEST PLAN UNDER ₹X Cr" CARD */}
      <div className="p-3.5 rounded bg-gradient-to-br from-[#0c1f19] to-[#0d1624] border border-emerald-500/80 shadow-[0_0_20px_rgba(16,185,129,0.2)] space-y-3">
        <div className="flex items-start justify-between border-b border-[#193a2f] pb-2">
          <div>
            <span className="text-[9.5px] font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-emerald-300" />
              <span>OPTIMAL PROGRAM ENVELOPE</span>
            </span>
            <h3 className="font-bold text-white text-sm mt-0.5">
              Best plan under ₹{budgetCr % 1 === 0 ? budgetCr.toFixed(0) : budgetCr.toFixed(1)} Cr
            </h3>
          </div>
          <span className="text-base font-black text-emerald-300 tabular-nums px-2 py-0.5 rounded bg-emerald-950 border border-emerald-600">
            {bestPlan.combinedRecoveryPct}% RECOVERY
          </span>
        </div>

        {/* High-Level Program Metrics */}
        <div className="grid grid-cols-3 gap-2 text-center">
          <div className="p-2 rounded bg-[#07130f] border border-[#163329]">
            <span className="text-[8.5px] text-slate-400 uppercase block">Cost Committed</span>
            <span className="text-xs font-black text-emerald-400 tabular-nums">
              ₹{bestPlan.totalCostCr} Cr
            </span>
            <span className="text-[8px] text-slate-500 block">
              (₹{bestPlan.remainingBudgetCr} Cr unspent)
            </span>
          </div>

          <div className="p-2 rounded bg-[#07130f] border border-[#163329]">
            <span className="text-[8.5px] text-slate-400 uppercase block">Hotspots Fixed</span>
            <span className="text-xs font-black text-white tabular-nums">
              {bestPlan.totalHotspotsFixed} of {rankedHotspots.length}
            </span>
            <span className="text-[8px] text-slate-500 block">
              {bestPlan.quickFixCount}Q &bull; {bestPlan.capitalFixCount}C
            </span>
          </div>

          <div className="p-2 rounded bg-[#07130f] border border-[#163329]">
            <span className="text-[8.5px] text-slate-400 uppercase block">Benefit Density</span>
            <span className="text-xs font-black text-amber-300 tabular-nums">
              {bestPlan.recoveryPerCrore} % / ₹Cr
            </span>
            <span className="text-[8px] text-slate-500 block">yield efficiency</span>
          </div>
        </div>

        {/* Selected Fixes in the Plan */}
        <div className="space-y-1.5 pt-1">
          <div className="flex items-center justify-between text-[10px]">
            <span className="font-bold text-slate-300 uppercase">
              SELECTED INTERVENTIONS ({bestPlan.items.length})
            </span>
            <span className="text-[9px] text-emerald-400 font-bold">Maximized Return</span>
          </div>

          <div className="space-y-1.5 max-h-52 overflow-y-auto pr-1">
            {bestPlan.items.map((item, idx) => {
              const isQuick = item.fixType === "quick";
              return (
                <div
                  key={item.hotspotId || idx}
                  className="p-2 rounded bg-[#070e12] border border-[#182e27] flex items-center justify-between text-[11px]"
                >
                  <div className="truncate pr-2">
                    <div className="flex items-center gap-1.5">
                      <span
                        className={`text-[8.5px] font-black px-1.5 py-0.2 rounded uppercase border ${
                          isQuick
                            ? "bg-cyan-950 text-cyan-300 border-cyan-700"
                            : "bg-purple-950 text-purple-300 border-purple-700"
                        }`}
                      >
                        {isQuick ? "QUICK PUMP" : "CAPITAL DRAIN"}
                      </span>
                      <span className="font-bold text-white truncate">{item.hotspotName}</span>
                    </div>
                    <div className="text-[9.5px] text-slate-400 truncate mt-0.5">
                      {item.option.title} &bull; Delivery:{" "}
                      <strong className="text-slate-200">{item.deliveryTimeDisplay}</strong>
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <span className="font-bold text-emerald-300 tabular-nums block text-xs">
                      ₹{item.costCr} Cr
                    </span>
                    <span className="text-[9px] text-slate-400 block">
                      +{item.recoveryPct}% gain
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* 5. PLAIN SVG COST-VS-RECOVERY PARETO STEP CHART */}
      <div className="p-3.5 rounded bg-[#0e1420] border border-[#1b2639] space-y-2">
        <div className="flex items-center justify-between border-b border-[#182333] pb-1.5">
          <span className="text-[10px] font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
            <TrendingUp className="w-3.5 h-3.5 text-cyan-400" />
            <span>COST-VS-RECOVERY STEP CHART (PARETO FRONTIER)</span>
          </span>
          <span className="text-[9px] px-1.5 py-0.2 rounded bg-[#162232] text-amber-300 border border-[#23354d]">
            illustrative
          </span>
        </div>

        <p className="text-[10.5px] text-slate-400 font-sans leading-relaxed">
          Marginal benefit curve from ₹0 to ₹20 Crore. Shows decreasing marginal returns beyond critical early underpass pump deployments.
        </p>

        {/* SVG Container */}
        <div className="bg-[#080c14] border border-[#182436] rounded p-2 overflow-hidden flex justify-center">
          <svg
            viewBox={`0 0 ${svgWidth} ${svgHeight}`}
            className="w-full max-w-sm h-auto select-none"
          >
            {/* Gridlines */}
            {[0, 25, 50, 75, 100].map((val) => (
              <g key={`grid-y-${val}`}>
                <line
                  x1={padding.left}
                  y1={getY(val)}
                  x2={svgWidth - padding.right}
                  y2={getY(val)}
                  stroke="#1c2838"
                  strokeWidth="0.8"
                  strokeDasharray="2 2"
                />
                <text
                  x={padding.left - 4}
                  y={getY(val) + 3}
                  fill="#64748b"
                  fontSize="8"
                  fontFamily="monospace"
                  textAnchor="end"
                >
                  {val}%
                </text>
              </g>
            ))}

            {/* X-axis budget ticks */}
            {[0, 5, 10, 15, 20].map((b) => (
              <g key={`grid-x-${b}`}>
                <line
                  x1={getX(b)}
                  y1={padding.top}
                  x2={getX(b)}
                  y2={padding.top + chartH}
                  stroke="#1c2838"
                  strokeWidth="0.8"
                  strokeDasharray="2 2"
                />
                <text
                  x={getX(b)}
                  y={padding.top + chartH + 14}
                  fill="#64748b"
                  fontSize="8"
                  fontFamily="monospace"
                  textAnchor="middle"
                >
                  ₹{b}Cr
                </text>
              </g>
            ))}

            {/* Axes Lines */}
            <line
              x1={padding.left}
              y1={padding.top + chartH}
              x2={svgWidth - padding.right}
              y2={padding.top + chartH}
              stroke="#334155"
              strokeWidth="1.2"
            />
            <line
              x1={padding.left}
              y1={padding.top}
              x2={padding.left}
              y2={padding.top + chartH}
              stroke="#334155"
              strokeWidth="1.2"
            />

            {/* Step Path (Pareto staircase) */}
            <path
              d={paretoPath}
              fill="none"
              stroke="#10b981"
              strokeWidth="2.2"
              strokeLinejoin="miter"
            />

            {/* Data points */}
            {paretoPoints.map((pt, i) => (
              <circle
                key={`pt-${i}`}
                cx={getX(pt.costCr)}
                cy={getY(pt.recoveryPct)}
                r="3"
                fill="#064e3b"
                stroke="#10b981"
                strokeWidth="1.5"
              />
            ))}

            {/* Current Active Budget Indicator */}
            <line
              x1={getX(bestPlan.totalCostCr)}
              y1={padding.top}
              x2={getX(bestPlan.totalCostCr)}
              y2={padding.top + chartH}
              stroke="#38bdf8"
              strokeWidth="1.2"
              strokeDasharray="3 2"
            />
            <circle
              cx={getX(bestPlan.totalCostCr)}
              cy={getY(bestPlan.combinedRecoveryPct)}
              r="5"
              fill="#38bdf8"
              stroke="#ffffff"
              strokeWidth="1.5"
            />
            <text
              x={getX(bestPlan.totalCostCr) + 5}
              y={getY(bestPlan.combinedRecoveryPct) - 6}
              fill="#38bdf8"
              fontSize="8.5"
              fontFamily="monospace"
              fontWeight="bold"
            >
              ₹{bestPlan.totalCostCr}Cr: {bestPlan.combinedRecoveryPct}%
            </text>
          </svg>
        </div>

        <div className="flex justify-between items-center text-[9px] text-slate-500 pt-0.5">
          <span>X: Capital Expenditure (₹ Crore)</span>
          <span>Y: Systemic Trip &amp; Hospital Recovery %</span>
        </div>
      </div>

      {/* 6. "QUICK VS CAPITAL" SIDE-BY-SIDE COMPARISON */}
      <div className="p-3.5 rounded bg-[#0f1420] border border-[#1b2639] space-y-3">
        <div className="flex items-center justify-between border-b border-[#182333] pb-1.5">
          <span className="text-[10px] font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
            <Building className="w-3.5 h-3.5 text-purple-400" />
            <span>"QUICK VS CAPITAL" SIDE-BY-SIDE</span>
          </span>
          <span className="text-[9px] text-slate-500">Under ₹{budgetCr % 1 === 0 ? budgetCr.toFixed(0) : budgetCr.toFixed(1)} Cr</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          {/* Left: Quick Only Plan */}
          <div className="p-3 rounded bg-[#0b121b] border border-cyan-800/60 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-black px-1.5 py-0.2 rounded bg-cyan-950 text-cyan-300 border border-cyan-700 uppercase">
                ONLY QUICK FIXES
              </span>
              <span className="text-[9px] text-slate-400">Pumps &amp; Diversions</span>
            </div>

            <div className="text-xl font-bold text-white tabular-nums">
              {quickOnlyPlan.combinedRecoveryPct}%
              <span className="text-[10px] text-slate-400 font-normal ml-1">recovery</span>
            </div>

            <div className="space-y-1 text-[10.5px] text-slate-300 pt-1 border-t border-[#162334]">
              <div className="flex justify-between">
                <span className="text-slate-400">Cost:</span>
                <strong className="text-cyan-300 font-mono">₹{quickOnlyPlan.totalCostCr} Crore</strong>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Time to deliver:</span>
                <strong className="text-emerald-400 font-mono">
                  {quickOnlyPlan.maxDeliveryDaysQuick || 14} days
                </strong>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Hotspots Covered:</span>
                <strong className="text-white font-mono">{quickOnlyPlan.totalHotspotsFixed} spots</strong>
              </div>
              <div className="flex justify-between text-amber-300 font-bold">
                <span>Recovery per crore:</span>
                <span className="font-mono">{quickOnlyPlan.recoveryPerCrore} % / ₹Cr</span>
              </div>
            </div>

            <div className="text-[9.5px] text-cyan-400/90 pt-1 border-t border-[#162334] leading-snug">
              Fastest deployment before monsoon arrival; maximum recovery per crore.
            </div>
          </div>

          {/* Right: Capital Only Plan */}
          <div className="p-3 rounded bg-[#130d19] border border-purple-800/60 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-black px-1.5 py-0.2 rounded bg-purple-950 text-purple-300 border border-purple-700 uppercase">
                ONLY CAPITAL WORKS
              </span>
              <span className="text-[9px] text-slate-400">Culverts &amp; Sumps</span>
            </div>

            <div className="text-xl font-bold text-white tabular-nums">
              {capitalOnlyPlan.combinedRecoveryPct}%
              <span className="text-[10px] text-slate-400 font-normal ml-1">recovery</span>
            </div>

            <div className="space-y-1 text-[10.5px] text-slate-300 pt-1 border-t border-[#261530]">
              <div className="flex justify-between">
                <span className="text-slate-400">Cost:</span>
                <strong className="text-purple-300 font-mono">₹{capitalOnlyPlan.totalCostCr} Crore</strong>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Time to deliver:</span>
                <strong className="text-amber-400 font-mono">
                  {capitalOnlyPlan.maxDeliveryMonthsCapital || 8} months
                </strong>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Hotspots Covered:</span>
                <strong className="text-white font-mono">{capitalOnlyPlan.totalHotspotsFixed} spots</strong>
              </div>
              <div className="flex justify-between text-amber-300 font-bold">
                <span>Recovery per crore:</span>
                <span className="font-mono">{capitalOnlyPlan.recoveryPerCrore} % / ₹Cr</span>
              </div>
            </div>

            <div className="text-[9.5px] text-purple-300/90 pt-1 border-t border-[#261530] leading-snug">
              Permanent structural immunity; longer delivery window across fiscal quarters.
            </div>
          </div>
        </div>
      </div>

      {/* 7. HOTSPOT PRIORITY RANKING TABLE */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-[10px] font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
            <Award className="w-3.5 h-3.5 text-emerald-400" />
            <span>INDIVIDUAL HOTSPOT PRIORITY RANKING ({rankedHotspots.length})</span>
          </span>
          <span className="text-[9px] text-slate-500">Sorted by Combined Yield</span>
        </div>

        <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
          {rankedHotspots.map((spot) => {
            const activeScore = isEquityAware ? spot.equityCombinedScore : spot.baseCombinedScore;
            return (
              <div
                key={spot.hotspotId}
                className="p-3 rounded bg-[#0d121c] border border-[#1c293d] hover:border-emerald-500/60 transition-colors space-y-2"
              >
                <div className="flex items-start justify-between gap-1.5">
                  <div className="flex items-start gap-2 min-w-0">
                    <span className="w-5 h-5 rounded bg-[#162232] border border-[#24354c] flex items-center justify-center font-bold text-[10px] text-emerald-400 shrink-0">
                      #{spot.rank}
                    </span>
                    <div className="truncate">
                      <span className="font-bold text-white text-xs block truncate">
                        {spot.hotspotName}
                      </span>
                      {isEquityAware && (
                        <div className="text-[9px] text-rose-300 flex items-center gap-1 mt-0.5">
                          <span>Vulnerability: {spot.vulnerabilityWeight}x</span>
                          <span className="text-slate-500">&bull;</span>
                          <span className="truncate">{spot.vulnerabilityRationale}</span>
                        </div>
                      )}
                    </div>
                  </div>

                  <span className="text-xs font-black text-emerald-400 font-mono shrink-0 tabular-nums">
                    {activeScore}/100
                  </span>
                </div>

                {/* Quick vs Capital Options Grid */}
                <div className="grid grid-cols-2 gap-2 text-[10px]">
                  <div className="p-2 rounded bg-[#080d14] border border-[#162334]">
                    <div className="flex items-center justify-between font-bold text-cyan-300">
                      <span>Quick Fix:</span>
                      <span>₹{spot.quickOption.costCr} Cr</span>
                    </div>
                    <div className="text-[9px] text-slate-400 mt-0.5">
                      {spot.quickOption.deliveryTimeDisplay} &bull; Pump &amp; diverters
                    </div>
                  </div>

                  <div className="p-2 rounded bg-[#080d14] border border-[#162334]">
                    <div className="flex items-center justify-between font-bold text-purple-300">
                      <span>Capital:</span>
                      <span>₹{spot.capitalOption.costCr} Cr</span>
                    </div>
                    <div className="text-[9px] text-slate-400 mt-0.5">
                      {spot.capitalOption.deliveryTimeDisplay} &bull; Culvert reconstruction
                    </div>
                  </div>
                </div>

                {/* Simulation Action Button */}
                {onSimulateHotspotFix && (
                  <button
                    type="button"
                    onClick={() => onSimulateHotspotFix(spot.hotspotId)}
                    className="w-full py-1.5 px-2 rounded bg-[#13222d] hover:bg-[#1a3040] border border-[#224558] text-cyan-300 hover:text-white font-mono font-bold text-[10.5px] flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
                  >
                    <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                    <span>SIMULATE THIS DRAIN CLEARED IN WHAT-IF</span>
                  </button>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
