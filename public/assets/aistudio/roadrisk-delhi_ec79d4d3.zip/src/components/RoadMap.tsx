import React, { useState, useMemo, useEffect, useRef, useCallback } from "react";
import { Link } from "react-router-dom";
import {
  MapContainer,
  TileLayer,
  Polyline,
  Tooltip,
  Popup,
  Marker,
  Rectangle,
  Circle,
  CircleMarker,
  useMap,
} from "react-leaflet";
import L from "leaflet";
import {
  Database,
  RefreshCw,
  Crosshair,
  Layers,
  MapPin,
  Compass,
  Activity,
  AlertTriangle,
  Info,
  Clock,
  TrendingUp,
  SlidersHorizontal,
  Droplets,
  CloudRain,
  RotateCcw,
  ShieldAlert,
  Hospital as HospitalIcon,
  AlertOctagon,
  Navigation,
  Scan,
  Maximize2,
  Check,
  X,
  ChevronDown,
  ChevronUp,
  Square,
  Play,
} from "lucide-react";
import { getRoadSpeed, getRoadCapacity } from "../simulation/graph";
import { getUtilizationColor, getCongestionLevel } from "../simulation/traffic";
import {
  FLOOD_HOTSPOTS,
  getEffectiveRadius,
} from "../data/floodHotspots";
import {
  WhatIfScenarioResult,
  FloodHotspot,
  RainfallLevel,
} from "../simulation/whatIfEngine";
import {
  HospitalAccessAnalysisResult,
  DemandNodeAccess,
} from "../simulation/hospitalAccessibilityEngine";
import LocationSearch from "./LocationSearch";
import { calculateAreaKm2 } from "../utils/geo";

// Zone coordinates: Central Delhi (Connaught Place, Minto Bridge, ITO, Tilak Bridge)
export const ZONE_BOUNDS: [[number, number], [number, number]] = [
  [28.6180, 77.2050],
  [28.6480, 77.2500],
];

export const ZONE_CENTER: [number, number] = [28.6315, 77.2270];

export function isValidBbox(south: any, west: any, north: any, east: any): boolean {
  return (
    typeof south === "number" &&
    typeof west === "number" &&
    typeof north === "number" &&
    typeof east === "number" &&
    Number.isFinite(south) &&
    Number.isFinite(west) &&
    Number.isFinite(north) &&
    Number.isFinite(east) &&
    south < north &&
    west < east
  );
}

function MapBoundsFitter({ bounds }: { bounds: [[number, number], [number, number]] }) {
  const map = useMap();
  const fittedRef = useRef<string | null>(null);

  useEffect(() => {
    if (!map) return;
    const key = `${bounds[0][0].toFixed(5)}_${bounds[0][1].toFixed(5)}_${bounds[1][0].toFixed(5)}_${bounds[1][1].toFixed(5)}`;
    if (fittedRef.current === key) return;
    fittedRef.current = key;

    try {
      map.fitBounds(bounds, { padding: [30, 30], maxZoom: 16 });
    } catch (e) {
      console.warn("fitBounds error:", e);
    }
  }, [map, bounds]);

  return null;
}

function MapInvalidator({ boundsKey }: { boundsKey: string }) {
  const map = useMap();

  useEffect(() => {
    if (!map) return;

    // Invalidate immediately, then with timers to allow layout to settle
    map.invalidateSize();

    const t1 = setTimeout(() => {
      map.invalidateSize();
    }, 150);

    const t2 = setTimeout(() => {
      map.invalidateSize();
    }, 350);

    const handleResize = () => {
      map.invalidateSize();
    };

    window.addEventListener("resize", handleResize);

    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      window.removeEventListener("resize", handleResize);
    };
  }, [map, boundsKey]);

  return null;
}

export function getRoadHierarchyColor(highway: string): string {
  const clean = String(highway || "").toLowerCase().split("_")[0];
  switch (clean) {
    case "motorway":
      return "#c084fc"; // purple
    case "trunk":
      return "#fb7185"; // rose
    case "primary":
      return "#38bdf8"; // sky blue
    case "secondary":
      return "#22d3ee"; // cyan
    case "tertiary":
      return "#34d399"; // emerald
    case "residential":
    default:
      return "#94a3b8"; // slate
  }
}

export function getRoadHierarchyWeight(highway: string): number {
  const clean = String(highway || "").toLowerCase().split("_")[0];
  if (clean === "motorway" || clean === "trunk") return 4.5;
  if (clean === "primary") return 3.5;
  if (clean === "secondary") return 2.8;
  return 2.0;
}

// Red cross hospital marker icon
const hospitalIcon = L.divIcon({
  className: "custom-hospital-marker",
  html: `<div style="display:flex;align-items:center;justify-content:center;width:24px;height:24px;background:#dc2626;border:2px solid #ffffff;border-radius:50%;color:#ffffff;font-family:monospace;font-size:15px;font-weight:900;box-shadow:0 0 12px rgba(220,38,38,0.85);cursor:pointer;"><span style="transform:translateY(-1px);">+</span></div>`,
  iconSize: [24, 24],
  iconAnchor: [12, 12],
});

function MapViewController({ center, zoom }: { center: [number, number]; zoom: number }) {
  const map = useMap();
  useEffect(() => {
    map.setView(center, zoom);
  }, [center, zoom, map]);
  return null;
}

function MapFlyHandler({
  target,
  onTargetConsumed,
}: {
  target: { center?: [number, number]; zoom?: number; bounds?: [[number, number], [number, number]] } | null;
  onTargetConsumed: () => void;
}) {
  const map = useMap();
  useEffect(() => {
    if (!target || !map) return;
    if (target.bounds) {
      map.fitBounds(target.bounds, { padding: [50, 50], maxZoom: 15, animate: true });
    } else if (target.center) {
      map.flyTo(target.center, target.zoom || 14, { duration: 1.2 });
    }
    onTargetConsumed();
  }, [target, map, onTargetConsumed]);
  return null;
}

function MapBoundsExtractor({ onRegisterExtract }: { onRegisterExtract: (fn: () => [[number, number], [number, number]]) => void }) {
  const map = useMap();
  useEffect(() => {
    onRegisterExtract(() => {
      const b = map.getBounds();
      return [
        [b.getSouth(), b.getWest()],
        [b.getNorth(), b.getEast()],
      ];
    });
  }, [map, onRegisterExtract]);
  return null;
}

function MapAreaDrawInteraction({
  isDrawingMode,
  onBoundsChange,
  onDrawingComplete,
}: {
  isDrawingMode: boolean;
  onBoundsChange: (bounds: [[number, number], [number, number]]) => void;
  onDrawingComplete: () => void;
}) {
  const map = useMap();
  const [dragStart, setDragStart] = useState<L.LatLng | null>(null);
  const [currentDrag, setCurrentDrag] = useState<L.LatLng | null>(null);

  useEffect(() => {
    if (!map) return;
    if (isDrawingMode) {
      map.dragging.disable();
      map.touchZoom.disable();
      map.doubleClickZoom.disable();
      map.scrollWheelZoom.disable();
      map.boxZoom.disable();
      map.getContainer().style.cursor = "crosshair";
    } else {
      map.dragging.enable();
      map.touchZoom.enable();
      map.doubleClickZoom.enable();
      map.scrollWheelZoom.enable();
      map.boxZoom.enable();
      map.getContainer().style.cursor = "";
      setDragStart(null);
      setCurrentDrag(null);
    }
  }, [isDrawingMode, map]);

  useEffect(() => {
    if (!map || !isDrawingMode) return;

    const onMouseDown = (e: L.LeafletMouseEvent) => {
      setDragStart(e.latlng);
      setCurrentDrag(e.latlng);
    };

    const onMouseMove = (e: L.LeafletMouseEvent) => {
      if (dragStart) {
        setCurrentDrag(e.latlng);
      }
    };

    const onMouseUp = (e: L.LeafletMouseEvent) => {
      if (dragStart) {
        const p1 = dragStart;
        const p2 = e.latlng;
        const south = Math.min(p1.lat, p2.lat);
        const north = Math.max(p1.lat, p2.lat);
        const west = Math.min(p1.lng, p2.lng);
        const east = Math.max(p1.lng, p2.lng);

        if (Math.abs(north - south) > 0.001 && Math.abs(east - west) > 0.001) {
          onBoundsChange([[south, west], [north, east]]);
          onDrawingComplete();
        }
        setDragStart(null);
        setCurrentDrag(null);
      }
    };

    map.on("mousedown", onMouseDown);
    map.on("mousemove", onMouseMove);
    map.on("mouseup", onMouseUp);

    return () => {
      map.off("mousedown", onMouseDown);
      map.off("mousemove", onMouseMove);
      map.off("mouseup", onMouseUp);
    };
  }, [map, isDrawingMode, dragStart, onBoundsChange, onDrawingComplete]);

  if (isDrawingMode && dragStart && currentDrag) {
    const s = Math.min(dragStart.lat, currentDrag.lat);
    const n = Math.max(dragStart.lat, currentDrag.lat);
    const w = Math.min(dragStart.lng, currentDrag.lng);
    const e = Math.max(dragStart.lng, currentDrag.lng);
    return (
      <Rectangle
        bounds={[[s, w], [n, e]]}
        pathOptions={{
          color: "#f59e0b",
          weight: 2,
          dashArray: "6 4",
          fillColor: "#f59e0b",
          fillOpacity: 0.25,
        }}
      />
    );
  }

  return null;
}

export interface ActiveZone {
  name: string;
  south: number;
  west: number;
  north: number;
  east: number;
  center: [number, number];
  isDefault: boolean;
  areaKm2: number;
}

export interface RoadMapProps {
  roads: any[];
  hospitals: any[];
  graph: any;
  dataSource: "OSM live" | "fallback snapshot";
  loading: boolean;
  loadingMessage?: string;
  onRefresh: () => void;
  selectedRoadId?: string | null;
  onSelectRoad?: (road: any) => void;
  baselineTraffic?: any;
  odPairs?: any[];
  // Zone & Area Selection Props
  currentZone?: ActiveZone;
  onRunAnalysisArea?: (bounds: [[number, number], [number, number]], name?: string) => void;
  onResetToCentralDelhi?: () => void;
  fetchError?: string | null;
  onRetryAnalysis?: () => void;
  // What-If & Cascade Props
  whatIfScenario?: WhatIfScenarioResult | null;
  closedRoadIds?: Set<string>;
  onToggleRoadClosed?: (roadId: string) => void;
  selectedHotspotId?: string | null;
  onSelectHotspot?: (hotspotId: string | null) => void;
  rainfallLevel?: RainfallLevel;
  activeTab?: string;
  cascadeStepIndex?: number;
  onResetClosures?: () => void;
  // Hospital Access Props
  hospitalAccess?: HospitalAccessAnalysisResult | null;
  selectedHospitalAreaId?: string | null;
  onSelectHospitalArea?: (areaId: string | null) => void;
  showHospitalNodes?: boolean;
  onToggleHospitalNodes?: () => void;
}

export type MapMode = "utilization" | "hierarchy";

export default function RoadMap({
  roads,
  hospitals,
  graph,
  dataSource,
  loading,
  loadingMessage,
  onRefresh,
  selectedRoadId,
  onSelectRoad,
  baselineTraffic,
  odPairs = [],
  whatIfScenario = null,
  closedRoadIds = new Set(),
  onToggleRoadClosed,
  selectedHotspotId = null,
  onSelectHotspot,
  rainfallLevel = "Extreme",
  activeTab = "what_if",
  cascadeStepIndex = 2,
  onResetClosures,
  hospitalAccess = null,
  selectedHospitalAreaId = null,
  onSelectHospitalArea,
  showHospitalNodes = true,
  onToggleHospitalNodes,
  currentZone,
  onRunAnalysisArea,
  onResetToCentralDelhi,
  fetchError = null,
  onRetryAnalysis,
}: RoadMapProps) {
  const [showHospitals, setShowHospitals] = useState<boolean>(true);
  const [showHotspotCircles, setShowHotspotCircles] = useState<boolean>(true);
  const [mapMode, setMapMode] = useState<MapMode>("utilization");
  const [localShowHospitalNodes, setLocalShowHospitalNodes] = useState<boolean>(true);

  // Validate currentZone bbox (finite numbers, south < north, west < east).
  // If invalid, fall back to Central Delhi default bounds and warn.
  const { validBounds, isBboxValid } = useMemo(() => {
    if (
      currentZone &&
      isValidBbox(currentZone.south, currentZone.west, currentZone.north, currentZone.east)
    ) {
      return {
        validBounds: [
          [currentZone.south, currentZone.west],
          [currentZone.north, currentZone.east],
        ] as [[number, number], [number, number]],
        isBboxValid: true,
      };
    }
    return {
      validBounds: ZONE_BOUNDS,
      isBboxValid: !currentZone || currentZone.isDefault,
    };
  }, [currentZone]);

  // Log warning if invalid bounding box detected
  useEffect(() => {
    if (currentZone && !isBboxValid) {
      console.warn(
        "Invalid bounding box detected in AppStateContext, falling back to default Central Delhi bounds:",
        {
          south: currentZone.south,
          west: currentZone.west,
          north: currentZone.north,
          east: currentZone.east,
        }
      );
    }
  }, [currentZone, isBboxValid]);

  const activeZoneCenter: [number, number] = useMemo(() => {
    if (
      isBboxValid &&
      currentZone?.center &&
      Number.isFinite(currentZone.center[0]) &&
      Number.isFinite(currentZone.center[1])
    ) {
      return currentZone.center;
    }
    return ZONE_CENTER;
  }, [currentZone, isBboxValid]);

  // Key based on area bbox so MapContainer re-initializes cleanly on changes/revisits
  const mapKey = useMemo(() => {
    return `dashboard-map-${validBounds[0][0].toFixed(5)}-${validBounds[0][1].toFixed(5)}-${validBounds[1][0].toFixed(5)}-${validBounds[1][1].toFixed(5)}`;
  }, [validBounds]);

  const nodeCount = useMemo(() => {
    return Object.keys(graph?.nodes || {}).length;
  }, [graph]);

  // Requirement 6: console.log bbox, roads returned, and hospitals returned when analysis runs
  useEffect(() => {
    if (currentZone) {
      console.log(
        "Dashboard map active area bbox:",
        {
          south: currentZone.south,
          west: currentZone.west,
          north: currentZone.north,
          east: currentZone.east,
        },
        `Roads returned: ${roads.length}, Hospitals returned: ${hospitals.length}`
      );
    }
  }, [currentZone, roads.length, hospitals.length]);

  // Visible Hotspots: only hotspots from floodHotspots.js that fall inside the valid box are shown
  const visibleHotspots = useMemo(() => {
    const s = validBounds[0][0];
    const w = validBounds[0][1];
    const n = validBounds[1][0];
    const e = validBounds[1][1];
    return FLOOD_HOTSPOTS.filter(
      (h) => h.lat >= s && h.lat <= n && h.lon >= w && h.lon <= e
    );
  }, [validBounds]);

  // Area Selection States
  const [isAreaSelectMode, setIsAreaSelectMode] = useState<boolean>(false);
  const [isDrawingRectangle, setIsDrawingRectangle] = useState<boolean>(false);
  const [selectedAreaBounds, setSelectedAreaBounds] = useState<[[number, number], [number, number]] | null>(null);
  const [flyTarget, setFlyTarget] = useState<{
    center?: [number, number];
    zoom?: number;
    bounds?: [[number, number], [number, number]];
  } | null>(null);
  const [isTelemetryExpanded, setIsTelemetryExpanded] = useState<boolean>(true);

  // Getter for current map viewport bounds
  const extractBoundsRef = useRef<(() => [[number, number], [number, number]]) | null>(null);

  const selectedAreaKm2 = useMemo(() => {
    if (!selectedAreaBounds) return 0;
    return calculateAreaKm2(selectedAreaBounds);
  }, [selectedAreaBounds]);

  const isAreaTooLarge = selectedAreaKm2 > 25.0;
  const isAreaTooSmall = selectedAreaKm2 > 0 && selectedAreaKm2 < 0.3;
  const isAreaValid = Boolean(selectedAreaBounds && !isAreaTooLarge && !isAreaTooSmall);

  // Handle "Use current view"
  const handleUseCurrentView = useCallback(() => {
    if (extractBoundsRef.current) {
      const b = extractBoundsRef.current();
      setSelectedAreaBounds(b);
      setIsDrawingRectangle(false);
    }
  }, []);

  // Handle Location Search selection
  const handleLocationSelect = useCallback(
    (lat: number, lon: number, name: string, bbox?: [number, number, number, number]) => {
      if (bbox) {
        setFlyTarget({ bounds: [[bbox[0], bbox[1]], [bbox[2], bbox[3]]] });
      } else {
        setFlyTarget({ center: [lat, lon], zoom: 14 });
      }
    },
    []
  );

  // Handle Run Analysis on selected area
  const handleRunAnalysis = useCallback(() => {
    if (!selectedAreaBounds || !isAreaValid) return;
    if (onRunAnalysisArea) {
      onRunAnalysisArea(selectedAreaBounds);
      setIsAreaSelectMode(false);
      setSelectedAreaBounds(null);
      setIsDrawingRectangle(false);
    }
  }, [selectedAreaBounds, isAreaValid, onRunAnalysisArea]);

  // Active hospital nodes visibility
  const isHospitalLayerVisible =
    activeTab === "hospital_access" ? true : localShowHospitalNodes;

  const validRoads = useMemo(() => {
    return roads.filter(
      (r) =>
        r &&
        Array.isArray(r.geometry) &&
        r.geometry.length > 1 &&
        r.geometry.every(
          (pt: any) =>
            Number.isFinite(Number(pt.lat)) && Number.isFinite(Number(pt.lon))
        )
    );
  }, [roads]);

  const validHospitals = useMemo(() => {
    return hospitals.filter(
      (h) => Number.isFinite(Number(h.lat)) && Number.isFinite(Number(h.lon))
    );
  }, [hospitals]);

  // Selected Hospital Demand Area for baseline vs flooded route comparison
  const selectedHospitalArea = useMemo(() => {
    if (!selectedHospitalAreaId || !hospitalAccess?.areas) return null;
    return hospitalAccess.areas.find((a) => a.id === selectedHospitalAreaId) || null;
  }, [selectedHospitalAreaId, hospitalAccess]);

  // Determine active traffic result based on active cascade step
  const activeTrafficResult = useMemo(() => {
    if (!whatIfScenario?.hasActiveClosures) {
      return baselineTraffic;
    }
    // In cascade tab:
    if (activeTab === "cascade") {
      if (cascadeStepIndex === 0) return baselineTraffic;
      return whatIfScenario.scenarioTraffic || baselineTraffic;
    }
    // In What-If tab:
    return whatIfScenario.scenarioTraffic || baselineTraffic;
  }, [whatIfScenario, baselineTraffic, activeTab, cascadeStepIndex]);

  // Set of blocked roads according to active cascade step
  const activeBlockedRoadsSet = useMemo(() => {
    if (!whatIfScenario?.hasActiveClosures) return new Set<string>();
    if (activeTab === "cascade" && cascadeStepIndex === 0) {
      return new Set<string>(); // Step 1 is normal
    }
    return whatIfScenario.blockedRoadIds;
  }, [whatIfScenario, activeTab, cascadeStepIndex]);

  // Set of secondary gridlock road IDs for fast lookup
  const secondaryGridlockSet = useMemo(() => {
    if (!whatIfScenario?.hasActiveClosures) return new Set<string>();
    if (activeTab === "cascade" && cascadeStepIndex < 2) {
      return new Set<string>(); // Step 1 & 2 haven't reached secondary gridlock
    }
    return new Set(whatIfScenario.secondaryGridlockRoads.map((r) => r.roadId));
  }, [whatIfScenario, activeTab, cascadeStepIndex]);

  return (
    <div
      className="w-full relative select-none font-mono"
      style={{
        width: "100%",
        height: "calc(100vh - 56px)",
        position: "relative",
      }}
    >
      {/* Leaflet Map */}
      <MapContainer
        key={mapKey}
        center={activeZoneCenter}
        zoom={14}
        style={{ width: "100%", height: "100%", background: "#090c10" }}
        zoomControl={true}
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        <MapBoundsFitter bounds={validBounds} />
        <MapInvalidator boundsKey={mapKey} />
        <MapFlyHandler target={flyTarget} onTargetConsumed={() => setFlyTarget(null)} />
        <MapBoundsExtractor onRegisterExtract={(fn) => { extractBoundsRef.current = fn; }} />
        <MapAreaDrawInteraction
          isDrawingMode={isDrawingRectangle}
          onBoundsChange={(b) => setSelectedAreaBounds(b)}
          onDrawingComplete={() => setIsDrawingRectangle(false)}
        />

        {/* Active Analyzed Zone Bounding Box */}
        <Rectangle
          bounds={validBounds}
          pathOptions={{
            color: "#06b6d4",
            weight: 2,
            dashArray: "4 4",
            fillColor: "#06b6d4",
            fillOpacity: 0.03,
          }}
          interactive={false}
        />

        {/* Selected Area Highlighted Rectangle */}
        {selectedAreaBounds && (
          <Rectangle
            bounds={selectedAreaBounds}
            pathOptions={{
              color: isAreaTooLarge || isAreaTooSmall ? "#f43f5e" : "#f59e0b",
              weight: 2.5,
              dashArray: "6 4",
              fillColor: isAreaTooLarge || isAreaTooSmall ? "#f43f5e" : "#f59e0b",
              fillOpacity: 0.18,
            }}
          >
            <Tooltip permanent direction="center">
              <div className="font-mono text-xs font-bold text-slate-900 px-2.5 py-1 rounded bg-white shadow-xl border border-slate-300">
                {selectedAreaKm2} km²
              </div>
            </Tooltip>
          </Rectangle>
        )}

        {/* Flood Hotspots Inundation Radiuses (filtered for current zone) */}
        {showHotspotCircles &&
          visibleHotspots.map((hotspot) => {
            const isFloodedInScenario = Boolean(
              whatIfScenario?.floodedHotspots?.some(
                (h) => h.id === hotspot.id || h.name.toLowerCase() === hotspot.name.toLowerCase()
              )
            );
            const isSelected =
              selectedHotspotId === hotspot.id ||
              selectedHotspotId === hotspot.name ||
              isFloodedInScenario;
            const radius = getEffectiveRadius(hotspot, rainfallLevel);

            return (
              <Circle
                key={`hotspot-${hotspot.id || hotspot.name}`}
                center={[hotspot.lat, hotspot.lon]}
                radius={radius}
                pathOptions={{
                  color: isFloodedInScenario ? "#f43f5e" : isSelected ? "#38bdf8" : "#0284c7",
                  weight: isSelected || isFloodedInScenario ? 2.8 : 1.2,
                  dashArray: isSelected || isFloodedInScenario ? "4 3" : "2 2",
                  fillColor: isFloodedInScenario ? "#f43f5e" : isSelected ? "#0284c7" : "#0369a1",
                  fillOpacity: isFloodedInScenario ? 0.38 : isSelected ? 0.35 : 0.16,
                }}
                eventHandlers={{
                  click: () => onSelectHotspot && onSelectHotspot(isSelected ? null : (hotspot.id || hotspot.name)),
                }}
              >
                <Tooltip direction="top" opacity={0.95}>
                  <div className="font-mono text-xs text-slate-200 p-1 space-y-1 max-w-[220px]">
                    <div className="font-bold text-cyan-300 flex items-center gap-1">
                      <Droplets className="w-3.5 h-3.5 text-cyan-400" />
                      <span>{hotspot.name}</span>
                    </div>
                    <div className="text-[10px] text-slate-300">
                      Inundation radius: <strong className="text-white">{radius}m</strong> ({rainfallLevel})
                    </div>
                    {hotspot.aliases?.length > 0 && (
                      <div className="text-[9px] text-slate-400">
                        {hotspot.aliases.join(", ")}
                      </div>
                    )}
                    <div className="text-[9px] text-amber-300/90 pt-0.5 border-t border-cyan-800/40">
                      Click to toggle What-If flood severance
                    </div>
                  </div>
                </Tooltip>
              </Circle>
            );
          })}

        {/* Render Road Segments Colored by Utilization or Highway Type */}
        {validRoads.map((road) => {
          const positions: [number, number][] = road.geometry.map(
            (p: any) => [Number(p.lat), Number(p.lon)] as [number, number]
          );
          const rId = String(road.id);
          const isBlocked = activeBlockedRoadsSet.has(rId);
          const isSecondaryGridlock = secondaryGridlockSet.has(rId);
          const stat = activeTrafficResult?.roadStats?.[road.id];
          const baseStat = baselineTraffic?.roadStats?.[road.id];
          const utilization = stat?.utilization ?? 0;
          const trafficFlow = stat?.traffic ?? 0;
          const roadCapacity = stat?.capacity ?? getRoadCapacity(road.highway, road.lanes);

          // Styling logic
          let color = getRoadHierarchyColor(road.highway);
          let weight = getRoadHierarchyWeight(road.highway);
          let dashArray: string | undefined = undefined;
          let opacity = 0.88;

          if (isBlocked) {
            // Blocked / Flooded road styling
            color = "#ef4444";
            weight = 4.8;
            dashArray = "6 5";
            opacity = 0.95;
          } else if (isSecondaryGridlock) {
            // Secondary Gridlock corridor (diverted traffic overload)
            color = "#ec4899"; // Vibrant Magenta/Pink
            weight = 4.8;
            opacity = 1.0;
          } else if (mapMode === "utilization") {
            color = stat ? getUtilizationColor(utilization) : getRoadHierarchyColor(road.highway);
            if (utilization > 100) {
              weight = 4.2;
            } else if (utilization >= 70) {
              weight = 3.2;
            } else {
              weight = 2.0;
            }
          }

          const isSelected = selectedRoadId === road.id;
          if (isSelected) {
            weight += 3;
            color = "#facc15";
          }

          return (
            <React.Fragment key={`road-${road.id}`}>
              {/* Invisible wider hit area for easy clicking */}
              <Polyline
                positions={positions}
                pathOptions={{
                  color: "#ffffff",
                  weight: 16,
                  opacity: 0.0001,
                  className: "road-hit-area cursor-pointer",
                }}
                eventHandlers={{
                  click: () => onSelectRoad && onSelectRoad(road),
                }}
              />
              <Polyline
                positions={positions}
                pathOptions={{
                  color,
                  weight,
                  opacity,
                  dashArray,
                  className: "road-polyline-transition cursor-pointer",
                }}
                eventHandlers={{
                  click: () => onSelectRoad && onSelectRoad(road),
                }}
              >
                <Tooltip sticky direction="top" opacity={0.96}>
                  <div className="font-mono text-xs text-slate-200 space-y-1">
                    <div className="font-bold text-white flex items-center gap-1.5">
                      <span
                        className="w-2.5 h-2.5 rounded-full shrink-0"
                        style={{ backgroundColor: color }}
                      />
                      <span>{road.name || "Corridor Link"}</span>
                    </div>

                    {/* Status Badge */}
                    <div className="flex items-center gap-1.5 text-[10px]">
                      {isBlocked ? (
                        <span className="px-1.5 py-0.2 rounded font-bold uppercase text-[9px] bg-rose-950 text-rose-300 border border-rose-700">
                          SEVERED / WATERLOGGED
                        </span>
                      ) : isSecondaryGridlock ? (
                        <span className="px-1.5 py-0.2 rounded font-bold uppercase text-[9px] bg-pink-950 text-pink-300 border border-pink-700">
                          SECONDARY GRIDLOCK ({utilization}%)
                        </span>
                      ) : (
                        <span
                          className={`px-1.5 py-0.2 rounded font-bold uppercase text-[9px] ${
                            utilization > 100
                              ? "bg-rose-950 text-rose-300 border border-rose-700"
                              : utilization >= 70
                              ? "bg-amber-950 text-amber-300 border border-amber-700"
                              : "bg-emerald-950 text-emerald-300 border border-emerald-700"
                          }`}
                        >
                          {utilization > 100
                            ? `Over Capacity (${utilization}%)`
                            : utilization >= 70
                            ? `Near Cap (${utilization}%)`
                            : `Normal (${utilization}%)`}
                        </span>
                      )}
                      <span className="text-slate-400 capitalize">{road.highway}</span>
                    </div>

                    <div className="text-[10px] text-slate-300 grid grid-cols-2 gap-x-2 pt-0.5 border-t border-[#223348]">
                      <div>
                        <span className="text-slate-400">Flow: </span>
                        <strong className="text-white">{trafficFlow}</strong> veh/h
                      </div>
                      <div>
                        <span className="text-slate-400">Capacity: </span>
                        <span>{roadCapacity}</span>
                      </div>
                    </div>

                    {whatIfScenario?.hasActiveClosures && baseStat && (
                      <div className="text-[9.5px] text-slate-400 pt-0.5 border-t border-[#1e2a3c]">
                        Baseline: {baseStat.utilization}% &bull; Current: {utilization}% (
                        <strong
                          className={
                            utilization > baseStat.utilization
                              ? "text-rose-400"
                              : "text-emerald-400"
                          }
                        >
                          {utilization >= baseStat.utilization ? "+" : ""}
                          {(utilization - baseStat.utilization).toFixed(1)}% Δ
                        </strong>
                        )
                      </div>
                    )}
                  </div>
                </Tooltip>

                {/* Popup for road with interactive toggle button */}
                <Popup>
                  <div className="font-mono text-xs space-y-2 p-1 min-w-[210px] text-slate-900">
                    <div className="font-bold text-sm text-slate-950 border-b border-slate-200 pb-1">
                      {road.name || "Corridor Segment"}
                    </div>
                    <div className="grid grid-cols-2 gap-1 text-[11px] text-slate-700">
                      <div>Class: <strong className="capitalize">{road.highway}</strong></div>
                      <div>Capacity: <strong>{roadCapacity}</strong></div>
                      <div>Flow: <strong>{trafficFlow}</strong></div>
                      <div>Utilization: <strong className={utilization > 100 ? "text-red-600" : ""}>{utilization}%</strong></div>
                    </div>
                    {onToggleRoadClosed && (
                      <button
                        type="button"
                        onClick={() => onToggleRoadClosed(rId)}
                        className={`w-full py-1.5 px-2 rounded text-xs font-bold transition-colors cursor-pointer mt-1 ${
                          isBlocked
                            ? "bg-emerald-600 hover:bg-emerald-700 text-white"
                            : "bg-red-600 hover:bg-red-700 text-white"
                        }`}
                      >
                        {isBlocked ? "REOPEN ROAD IN WHAT-IF" : "CLOSE ROAD (SIMULATE FLOOD)"}
                      </button>
                    )}
                  </div>
                </Popup>
              </Polyline>
            </React.Fragment>
          );
        })}

        {/* ------------------------------------------------------------- */}
        {/* ROUTE COMPARISON OVERLAYS: BASELINE (CYAN) VS FLOODED (ROSE) */}
        {/* ------------------------------------------------------------- */}
        {selectedHospitalArea && (
          <>
            {/* 1. Baseline Route to Nearest Hospital (Solid Cyan) */}
            {selectedHospitalArea.baselineRouteCoords &&
              selectedHospitalArea.baselineRouteCoords.length > 1 && (
                <Polyline
                  positions={selectedHospitalArea.baselineRouteCoords}
                  pathOptions={{
                    color: "#06b6d4",
                    weight: 5.5,
                    opacity: 0.95,
                    lineCap: "round",
                    lineJoin: "round",
                  }}
                >
                  <Tooltip sticky direction="top" opacity={0.96}>
                    <div className="font-mono text-xs text-slate-900 font-bold p-1">
                      <div className="text-cyan-700">✓ BASELINE ROUTE (DRY ROADS)</div>
                      <div>To: {selectedHospitalArea.baselineHospital.name}</div>
                      <div>Time: {selectedHospitalArea.baselineTimeMin} min</div>
                    </div>
                  </Tooltip>
                </Polyline>
              )}

            {/* 2. Flooded Route to Nearest Hospital (Dashed Rose) */}
            {selectedHospitalArea.floodedRouteCoords &&
              selectedHospitalArea.floodedRouteCoords.length > 1 && (
                <Polyline
                  positions={selectedHospitalArea.floodedRouteCoords}
                  pathOptions={{
                    color: "#f43f5e",
                    weight: 5.5,
                    opacity: 1.0,
                    dashArray: "7 6",
                    lineCap: "round",
                    lineJoin: "round",
                  }}
                >
                  <Tooltip sticky direction="top" opacity={0.96}>
                    <div className="font-mono text-xs text-slate-900 font-bold p-1">
                      <div className="text-rose-600">⚠ FLOOD DETOUR ROUTE</div>
                      <div>
                        To:{" "}
                        {selectedHospitalArea.floodedHospital?.name ||
                          selectedHospitalArea.baselineHospital.name}
                      </div>
                      <div>
                        Time: {selectedHospitalArea.floodedTimeMin} min (
                        <span className="text-red-700">
                          +{selectedHospitalArea.extraDelayMin} min delay
                        </span>
                        )
                      </div>
                    </div>
                  </Tooltip>
                </Polyline>
              )}
          </>
        )}

        {/* ------------------------------------------------------------- */}
        {/* DEMAND NODES COLOR-CODED BY HOSPITAL ACCESS                   */}
        {/* Green: <= 15m, Amber: 15-30m, Red: >30m Golden Hour Alert     */}
        {/* ------------------------------------------------------------- */}
        {isHospitalLayerVisible &&
          hospitalAccess?.areas &&
          hospitalAccess.areas.map((area) => {
            const isSelected = selectedHospitalAreaId === area.id;
            return (
              <CircleMarker
                key={`hospital-node-${area.id}`}
                center={[area.lat, area.lon]}
                radius={isSelected ? 16 : 12}
                pathOptions={{
                  fillColor: area.statusColor,
                  fillOpacity: 0.95,
                  color: isSelected ? "#38bdf8" : "#ffffff",
                  weight: isSelected ? 3.5 : 2.0,
                  className: "hospital-demand-node cursor-pointer",
                }}
                eventHandlers={{
                  click: () =>
                    onSelectHospitalArea &&
                    onSelectHospitalArea(isSelected ? null : area.id),
                }}
              >
                <Tooltip direction="top" opacity={0.97}>
                  <div className="font-mono text-xs text-slate-200 p-1 space-y-1.5 min-w-[210px]">
                    <div className="flex items-center justify-between border-b border-[#24354d] pb-1">
                      <span className="font-bold text-white text-xs">{area.name}</span>
                      <span
                        className={`text-[9px] px-1.5 py-0.2 rounded font-bold uppercase ${
                          area.isGoldenHourBreached
                            ? "bg-rose-950 text-rose-300 border border-rose-700"
                            : area.statusColor === "#f59e0b"
                            ? "bg-amber-950 text-amber-300 border border-amber-700"
                            : "bg-emerald-950 text-emerald-300 border border-emerald-700"
                        }`}
                      >
                        {area.isGoldenHourBreached
                          ? ">30m ALERT"
                          : area.statusColor === "#f59e0b"
                          ? "15-30m DELAY"
                          : "<15m SAFE"}
                      </span>
                    </div>

                    <div className="text-[10.5px] space-y-1 text-slate-300">
                      <div className="flex justify-between">
                        <span className="text-slate-400">Baseline Transit:</span>
                        <strong className="text-cyan-300 font-mono">
                          {area.baselineTimeMin} min
                        </strong>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">Flooded Transit:</span>
                        <strong
                          className={`font-mono ${
                            area.extraDelayMin > 0 ? "text-rose-400" : "text-white"
                          }`}
                        >
                          {area.floodedTimeMin} min (+{area.extraDelayMin}m)
                        </strong>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">Nearest Hospital:</span>
                        <span className="text-white truncate max-w-[120px]">
                          {area.floodedHospital?.name || area.baselineHospital.name}
                        </span>
                      </div>
                      <div className="flex justify-between pt-0.5 border-t border-[#1d2b3e] text-[9.5px]">
                        <span className="text-slate-400">Population:</span>
                        <span>{area.population.toLocaleString()} (illustrative)</span>
                      </div>
                      <div className="flex justify-between text-amber-300 text-[9.5px] font-bold">
                        <span>Impact Score:</span>
                        <span className="font-mono">
                          {area.impactScore.toLocaleString()} person-min
                        </span>
                      </div>
                    </div>
                    <div className="text-[9px] text-cyan-400/90 pt-0.5 border-t border-cyan-800/40 text-center">
                      Click to compare baseline vs flooded routes on map
                    </div>
                  </div>
                </Tooltip>
              </CircleMarker>
            );
          })}

        {/* Hospitals Red Cross Markers */}
        {showHospitals &&
          validHospitals.map((h, i) => (
            <Marker
              key={h.id || `h-${i}`}
              position={[Number(h.lat), Number(h.lon)]}
              icon={hospitalIcon}
            >
              <Popup>
                <div className="font-mono text-xs space-y-1.5 p-1 min-w-[200px] text-slate-900">
                  <div className="flex items-center gap-1.5 text-red-600 font-bold border-b border-slate-200 pb-1">
                    <span className="text-base font-black">+</span>
                    <span className="text-sm">{h.name}</span>
                  </div>
                  <div className="text-[11px] text-slate-600">
                    {h.address || "Central Delhi Healthcare Node"}
                  </div>
                  {h.emergency && (
                    <div className="inline-block px-1.5 py-0.5 rounded bg-red-100 text-red-800 text-[10px] font-bold">
                      24/7 Trauma Emergency Care
                    </div>
                  )}
                </div>
              </Popup>
            </Marker>
          ))}
      </MapContainer>

      {/* TOP FLOATING CARD: BASELINE / WHAT-IF / GOLDEN HOUR TELEMETRY */}
      <div className="absolute top-3 left-3 z-[900] max-w-sm w-full pointer-events-auto space-y-2">
        <div className="p-3 rounded bg-[#0a0e16]/95 backdrop-blur-md border border-[#1e2a3c] shadow-2xl space-y-2">
          {/* Header */}
          <div className="flex items-center justify-between border-b border-[#1b2536] pb-1.5">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
              <span className="font-bold text-xs text-white uppercase tracking-wider">
                {activeTab === "hospital_access"
                  ? "HOSPITAL EMERGENCY ACCESS"
                  : whatIfScenario?.hasActiveClosures
                  ? "WHAT-IF NETWORK IMPACT"
                  : "BASELINE NETWORK"}
              </span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="text-[9px] px-1.5 py-0.5 rounded bg-[#131b28] text-amber-300 border border-[#23354d]">
                synthetic demand (illustrative)
              </span>
              <button
                type="button"
                onClick={() => setIsTelemetryExpanded((v) => !v)}
                className="p-0.5 rounded hover:bg-slate-800 text-slate-400 hover:text-white"
                title={isTelemetryExpanded ? "Collapse telemetry" : "Expand telemetry"}
              >
                {isTelemetryExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>

          {isTelemetryExpanded && (
            <>

          {/* Core Metrics */}
          {activeTab === "hospital_access" && hospitalAccess ? (
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="p-2 rounded bg-[#070a10] border border-[#172130]">
                <div className="flex items-center justify-between text-[10px] text-slate-400">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3 text-cyan-400" />
                    <span>Avg Transit</span>
                  </span>
                  <span
                    className={`font-bold text-[9px] ${
                      hospitalAccess.avgExtraDelayMin > 0 ? "text-rose-400" : "text-emerald-400"
                    }`}
                  >
                    +{hospitalAccess.avgExtraDelayMin}m Δ
                  </span>
                </div>
                <div className="text-base font-bold text-white tabular-nums mt-0.5">
                  {hospitalAccess.avgFloodedTimeMin} min
                </div>
                <div className="text-[9px] text-slate-500">
                  Baseline: {hospitalAccess.avgBaselineTimeMin} min
                </div>
              </div>
              <div className="p-2 rounded bg-[#070a10] border border-[#172130]">
                <div className="flex items-center justify-between text-[10px] text-slate-400">
                  <span className="flex items-center gap-1">
                    <HospitalIcon className="w-3 h-3 text-rose-400" />
                    <span>Golden Hour</span>
                  </span>
                  <span
                    className={`font-bold text-[9px] ${
                      hospitalAccess.hasGoldenHourBreach ? "text-rose-400" : "text-emerald-400"
                    }`}
                  >
                    {hospitalAccess.hasGoldenHourBreach ? "BREACHED" : "SAFE"}
                  </span>
                </div>
                <div
                  className={`text-base font-bold tabular-nums mt-0.5 ${
                    hospitalAccess.hasGoldenHourBreach ? "text-rose-400" : "text-emerald-400"
                  }`}
                >
                  {hospitalAccess.goldenHourBreachedAreas.length} &gt; 30 min
                </div>
                <div className="text-[9px] text-slate-500">
                  {hospitalAccess.areas.length - hospitalAccess.goldenHourBreachedAreas.length} safe
                </div>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-2 text-xs">
              {/* Metric 1: Avg Travel Time */}
              <div className="p-2 rounded bg-[#070a10] border border-[#172130]">
                <div className="flex items-center justify-between text-[10px] text-slate-400">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3 text-cyan-400" />
                    <span>Avg Travel Time</span>
                  </span>
                  {whatIfScenario?.hasActiveClosures && (
                    <span
                      className={`font-bold text-[9px] ${
                        whatIfScenario.avgTravelTimeDeltaPct > 0
                          ? "text-rose-400"
                          : "text-emerald-400"
                      }`}
                    >
                      +{whatIfScenario.avgTravelTimeDeltaPct}%
                    </span>
                  )}
                </div>
                <div className="text-sm font-bold text-white tabular-nums mt-0.5">
                  {whatIfScenario?.hasActiveClosures && whatIfScenario.baseAvgTravelTimeMin !== undefined && whatIfScenario.scenarioAvgTravelTimeMin !== undefined
                    ? `${whatIfScenario.baseAvgTravelTimeMin}m → ${whatIfScenario.scenarioAvgTravelTimeMin}m`
                    : `${activeTrafficResult?.averageTravelTimeMinutes ?? 0} min`}
                </div>
                <div className="text-[9px] text-slate-500">
                  {whatIfScenario?.hasActiveClosures
                    ? `+${whatIfScenario.avgTravelTimeDeltaPct}% connected trips`
                    : "Datum (0.0% Δ)"}
                </div>
              </div>

              {/* Metric 2: Over Capacity Roads */}
              <div className="p-2 rounded bg-[#070a10] border border-[#172130]">
                <div className="flex items-center justify-between text-[10px] text-slate-400">
                  <span className="flex items-center gap-1">
                    <TrendingUp className="w-3 h-3 text-rose-400" />
                    <span>Over Capacity</span>
                  </span>
                  {whatIfScenario?.hasActiveClosures && (
                    <span className="font-bold text-[9px] text-rose-400">
                      +{whatIfScenario.roadsPushedOverCapacity.length} ripple
                    </span>
                  )}
                </div>
                <div className="text-base font-bold text-rose-400 tabular-nums mt-0.5">
                  {whatIfScenario?.hasActiveClosures
                    ? `${whatIfScenario.roadsPushedOverCapacity.length} corridors`
                    : `${activeTrafficResult?.percentOverCapacity ?? 0}%`}
                </div>
                <div className="text-[9px] text-slate-500">
                  {whatIfScenario?.hasActiveClosures
                    ? `${whatIfScenario.tripsDisconnected} (${whatIfScenario.tripsDisconnectedPct}%) disconnected`
                    : `${activeTrafficResult?.overloadedRoadsCount ?? 0} corridors overloaded`}
                </div>
              </div>
            </div>
          )}

          {/* GOLDEN HOUR FLOATING ALERT IF BREACH OCCURS */}
          {hospitalAccess?.hasGoldenHourBreach && (
            <div className="p-2 rounded bg-[#200913] border border-rose-500 shadow-md space-y-1">
              <div className="flex items-center justify-between text-[9px] font-bold text-rose-300 uppercase">
                <span className="flex items-center gap-1">
                  <AlertOctagon className="w-3.5 h-3.5 text-rose-400 animate-pulse" />
                  <span>Golden Hour Alert (&gt;30 min)</span>
                </span>
                <span className="text-white font-mono">
                  {hospitalAccess.goldenHourBreachedAreas.length} area(s)
                </span>
              </div>
              <p className="text-[10px] text-rose-100 font-sans leading-tight">
                {hospitalAccess.goldenHourBreachedAreas[0].name} transit reached{" "}
                <strong>{hospitalAccess.goldenHourBreachedAreas[0].floodedTimeMin} min</strong> (+
                {hospitalAccess.goldenHourBreachedAreas[0].extraDelayMin}m added delay).
              </p>
            </div>
          )}

          {/* ACTIVE SUMMARY BANNER IF CLOSURES ACTIVE AND NOT ON HOSPITAL TAB */}
          {activeTab !== "hospital_access" && whatIfScenario?.hasActiveClosures && (
            <div className="p-2 rounded bg-[#160d19] border border-rose-600/70 space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-[9px] font-bold text-rose-300 uppercase flex items-center gap-1">
                  <AlertTriangle className="w-3 h-3 text-amber-400" />
                  <span>Dominant Ripple</span>
                </span>
                {onResetClosures && (
                  <button
                    type="button"
                    onClick={onResetClosures}
                    className="text-[9px] text-rose-400 hover:text-white underline cursor-pointer"
                  >
                    Clear All
                  </button>
                )}
              </div>
              <p className="text-[10px] text-slate-200 font-sans leading-tight">
                {whatIfScenario.summarySentence}
              </p>
            </div>
          )}

          {/* Network Stats & Source */}
          <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1 border-t border-[#172233]">
            <span>{validRoads.length} roads &bull; {validHospitals.length} hospitals</span>
            <div className="flex items-center gap-1">
              <span className="text-[9px] px-1.5 py-0.2 rounded bg-cyan-950 text-cyan-300 border border-cyan-800">
                {dataSource}
              </span>
              <button
                type="button"
                onClick={onRefresh}
                disabled={loading}
                className="p-1 hover:text-cyan-300 cursor-pointer"
                title="Query live OpenStreetMap"
              >
                <RefreshCw className={`w-3 h-3 ${loading ? "animate-spin text-cyan-400" : ""}`} />
              </button>
            </div>
          </div>
            </>
          )}
        </div>
      </div>

      {/* INVALID BBOX FALLBACK WARNING BANNER */}
      {!isBboxValid && currentZone && (
        <div className="absolute top-16 left-3 z-[1100] px-3 py-1.5 rounded bg-amber-950/90 border border-amber-500 text-amber-200 text-xs font-mono font-bold shadow-lg flex items-center gap-2 pointer-events-auto">
          <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
          <span>Invalid area bbox detected. Falling back to Central Delhi.</span>
        </div>
      )}

      {/* TOP-RIGHT FLOATING STACK: ROUTE COMPARISON CARD & AREA STATS CARD */}
      <div className="absolute top-3 right-3 z-[1000] max-w-xs w-full pointer-events-auto flex flex-col gap-2">
        {/* FLOATING ROUTE COMPARISON CARD ON MAP */}
        {selectedHospitalArea && (
          <div className="p-3 rounded bg-[#0b111a]/95 backdrop-blur-md border border-cyan-500/80 shadow-2xl space-y-2 text-xs">
            <div className="flex items-center justify-between border-b border-[#1b273b] pb-1.5">
              <span className="font-bold text-cyan-300 text-[11px] uppercase tracking-wider flex items-center gap-1">
                <Navigation className="w-3.5 h-3.5 text-cyan-400" />
                <span>HOSPITAL ROUTE TRACE</span>
              </span>
              <button
                type="button"
                onClick={() => onSelectHospitalArea && onSelectHospitalArea(null)}
                className="text-[10px] text-slate-400 hover:text-white px-1.5 py-0.2 rounded bg-[#172233] cursor-pointer"
              >
                ✕
              </button>
            </div>
            <div className="font-bold text-white text-xs">{selectedHospitalArea.name}</div>
            <div className="space-y-1.5 text-[10.5px]">
              {/* Baseline Route */}
              <div className="p-2 rounded bg-[#08101a] border border-[#16273e] space-y-0.5">
                <div className="flex items-center justify-between text-cyan-400 font-bold">
                  <span className="flex items-center gap-1.5">
                    <span className="w-2.5 h-1 rounded bg-[#06b6d4]" />
                    <span>Baseline Route:</span>
                  </span>
                  <span className="font-mono">{selectedHospitalArea.baselineTimeMin} min</span>
                </div>
                <div className="text-[9.5px] text-slate-400 truncate">
                  To: {selectedHospitalArea.baselineHospital.name}
                </div>
              </div>
              {/* Flooded Route */}
              <div className="p-2 rounded bg-[#160a13] border border-rose-900/80 space-y-0.5">
                <div className="flex items-center justify-between text-rose-300 font-bold">
                  <span className="flex items-center gap-1.5">
                    <span className="w-2.5 h-1 rounded bg-[#f43f5e] border border-dashed border-white" />
                    <span>Flooded Route:</span>
                  </span>
                  <span className="font-mono">{selectedHospitalArea.floodedTimeMin} min</span>
                </div>
                <div className="text-[9.5px] text-slate-400 truncate">
                  To:{" "}
                  {selectedHospitalArea.floodedHospital?.name ||
                    selectedHospitalArea.baselineHospital.name}
                </div>
                <div className="text-[9px] text-amber-300 font-bold pt-0.5">
                  Added Delay: +{selectedHospitalArea.extraDelayMin} min
                </div>
              </div>
              {/* Impact score */}
              <div className="p-1.5 rounded bg-[#070a12] border border-[#172233] flex justify-between items-center text-[10px]">
                <span className="text-slate-400">Impact Score:</span>
                <span className="text-amber-300 font-bold font-mono">
                  {selectedHospitalArea.impactScore.toLocaleString()} person-min
                </span>
              </div>
              {selectedHospitalArea.isGoldenHourBreached && (
                <div className="px-2 py-1 rounded bg-rose-950 text-rose-300 border border-rose-700 text-[9.5px] font-bold text-center">
                  ⚠️ GOLDEN HOUR BREACH (&gt;30 MIN)
                </div>
              )}
            </div>
          </div>
        )}

        {/* AREA STATS CARD (Requirement 5) */}
        <div className="p-2.5 rounded-lg bg-[#0a0e16]/95 backdrop-blur-md border border-[#1e2a3c] shadow-2xl space-y-2 text-xs">
          <div className="flex items-center justify-between gap-2 border-b border-[#1b2536] pb-1.5">
            <div className="flex items-center gap-1.5 min-w-0">
              <Database className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
              <span className="font-bold text-slate-100 uppercase tracking-wider text-[11px] truncate max-w-[130px]">
                {currentZone?.name || "Analyzed Area"}
              </span>
            </div>
            <span
              className={`text-[9px] px-2 py-0.5 rounded font-bold uppercase tracking-wider shrink-0 border ${
                dataSource === "OSM live"
                  ? "bg-emerald-950/80 text-emerald-300 border-emerald-600/70"
                  : "bg-amber-950/80 text-amber-300 border-amber-600/70"
              }`}
            >
              {dataSource}
            </span>
          </div>

          <div className="grid grid-cols-3 gap-1.5 text-center text-[10.5px]">
            <div className="p-1.5 rounded bg-[#070a10] border border-[#162130]">
              <div className="text-[9px] text-slate-400 uppercase">Roads</div>
              <div className="text-sm font-bold text-cyan-300 tabular-nums">
                {roads.length}
              </div>
            </div>
            <div className="p-1.5 rounded bg-[#070a10] border border-[#162130]">
              <div className="text-[9px] text-slate-400 uppercase">Nodes</div>
              <div className="text-sm font-bold text-slate-200 tabular-nums">
                {nodeCount}
              </div>
            </div>
            <div className="p-1.5 rounded bg-[#070a10] border border-[#162130]">
              <div className="text-[9px] text-slate-400 uppercase">Hospitals</div>
              <div className="text-sm font-bold text-red-400 tabular-nums">
                {hospitals.length}
              </div>
            </div>
          </div>

          {currentZone && (
            <div className="text-[9.5px] text-slate-400 flex items-center justify-between pt-0.5 border-t border-[#162130]">
              <span>Coverage:</span>
              <span className="text-slate-300 font-bold">
                {currentZone.areaKm2 ? `${currentZone.areaKm2} km²` : "Custom"}
              </span>
            </div>
          )}
        </div>
      </div>

      {/* LOADING OVERLAY ON MAP (Requirement 4) */}
      {loading && (
        <div className="absolute inset-0 z-[2000] bg-[#0c0e12]/80 backdrop-blur-sm flex items-center justify-center p-4 pointer-events-auto">
          <div className="p-6 rounded bg-[#101520] border border-[#223348] shadow-2xl text-center space-y-3 max-w-sm w-full font-mono">
            <div className="w-10 h-10 mx-auto rounded-full bg-[#162335] border border-cyan-400/40 flex items-center justify-center text-cyan-400">
              <RefreshCw className="w-5 h-5 animate-spin" />
            </div>
            <div className="text-xs font-bold text-white uppercase tracking-wider">
              Loading Road Infrastructure
            </div>
            <div className="text-[11px] text-slate-300 bg-[#090c10] border border-[#1b2536] px-3 py-2 rounded">
              {loadingMessage || "Querying OpenStreetMap for drivable roads and hospitals..."}
            </div>
          </div>
        </div>
      )}

      {/* ERROR OVERLAY WITH RETRY BUTTON ON MAP (Requirement 4) */}
      {!loading && (Boolean(fetchError) || roads.length === 0) && (
        <div className="absolute inset-0 z-[1900] bg-[#0c0e12]/85 backdrop-blur-sm flex items-center justify-center p-4 pointer-events-auto">
          <div className="p-6 rounded-lg bg-[#121622] border border-rose-500/50 shadow-2xl text-center space-y-4 max-w-md w-full font-mono">
            <div className="w-12 h-12 mx-auto rounded-full bg-rose-950/70 border border-rose-500/60 flex items-center justify-center text-rose-400">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <div className="space-y-1">
              <div className="text-sm font-bold text-white uppercase tracking-wider">
                Road Network Loading Issue
              </div>
              <p className="text-xs text-rose-300/90 leading-relaxed">
                {fetchError || "No roads found in this area. Try a different or slightly larger area"}
              </p>
            </div>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-2 pt-2">
              <button
                type="button"
                onClick={onRetryAnalysis || onRefresh}
                className="w-full sm:w-auto px-4 py-2 rounded bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-lg"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>RETRY OVERPASS FETCH</span>
              </button>
              <Link
                to="/select-area"
                className="w-full sm:w-auto px-4 py-2 rounded bg-[#1a2536] hover:bg-[#25354d] border border-[#2e425d] text-slate-200 hover:text-white font-bold text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <Scan className="w-3.5 h-3.5 text-amber-400" />
                <span>CHANGE AREA</span>
              </Link>
            </div>
          </div>
        </div>
      )}

      {/* BOTTOM-LEFT MAP CONTROLS & LEGEND */}
      <div className="absolute bottom-4 left-4 z-[1000] flex flex-col gap-2 pointer-events-auto">
        {/* Map Mode Selector */}
        <div className="p-1.5 rounded bg-[#0b0f16]/95 backdrop-blur-md border border-[#1b2636] flex items-center gap-1 text-[11px] shadow-lg">
          <button
            type="button"
            onClick={() => setMapMode("utilization")}
            className={`px-2.5 py-1 rounded transition-colors cursor-pointer ${
              mapMode === "utilization"
                ? "bg-cyan-950 text-cyan-300 font-bold border border-cyan-700/60"
                : "text-slate-400 hover:text-white"
            }`}
          >
            Utilization
          </button>
          <button
            type="button"
            onClick={() => setMapMode("hierarchy")}
            className={`px-2.5 py-1 rounded transition-colors cursor-pointer ${
              mapMode === "hierarchy"
                ? "bg-cyan-950 text-cyan-300 font-bold border border-cyan-700/60"
                : "text-slate-400 hover:text-white"
            }`}
          >
            Road Class
          </button>
          <div className="h-4 w-px bg-slate-700 mx-1" />
          <button
            type="button"
            onClick={() => setShowHotspotCircles(!showHotspotCircles)}
            className={`px-2 py-1 rounded transition-colors cursor-pointer flex items-center gap-1 text-[10px] ${
              showHotspotCircles
                ? "text-cyan-300 bg-cyan-950/60 border border-cyan-800/80"
                : "text-slate-500 hover:text-slate-300"
            }`}
            title="Toggle Waterlogging Hotspots"
          >
            <Droplets className="w-3 h-3" />
            <span>Hotspots</span>
          </button>
          <div className="h-4 w-px bg-slate-700 mx-1" />
          {/* Hospital Access Layer Toggle */}
          <button
            type="button"
            onClick={() => {
              if (onToggleHospitalNodes) {
                onToggleHospitalNodes();
              } else {
                setLocalShowHospitalNodes(!localShowHospitalNodes);
              }
            }}
            className={`px-2 py-1 rounded transition-colors cursor-pointer flex items-center gap-1.5 text-[10px] ${
              isHospitalLayerVisible
                ? "text-rose-200 bg-rose-950/80 border border-rose-700"
                : "text-slate-500 hover:text-slate-300"
            }`}
            title="Toggle Hospital Reachability Demand Nodes (Green/Amber/Red)"
          >
            <HospitalIcon className="w-3 h-3 text-rose-400" />
            <span>Hospital Nodes</span>
            <span
              className={`w-2 h-2 rounded-full ${
                hospitalAccess?.hasGoldenHourBreach ? "bg-rose-500 animate-pulse" : "bg-emerald-500"
              }`}
            />
          </button>
        </div>

        {/* Map Legend */}
        <div className="p-2.5 rounded bg-[#0b0f16]/95 backdrop-blur-md border border-[#1b2636] shadow-xl text-[10px] space-y-1.5 min-w-[210px]">
          <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider block">
            {isHospitalLayerVisible
              ? "HOSPITAL ACCESS & ROAD UTILIZATION"
              : mapMode === "utilization"
              ? "CONGESTION UTILIZATION (BPR)"
              : "HIGHWAY HIERARCHY"}
          </span>

          {/* Hospital Access Nodes Legend */}
          {isHospitalLayerVisible && (
            <div className="p-1.5 rounded bg-[#070b12] border border-[#162335] space-y-1 mb-1">
              <span className="text-[8.5px] font-bold text-slate-400 uppercase block">
                Demand Nodes Reachability:
              </span>
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-[#10b981] border border-white shrink-0" />
                <span className="text-slate-300">&le; 15 min (Safe Reach)</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-[#f59e0b] border border-white shrink-0" />
                <span className="text-slate-300">15 - 30 min (Delayed)</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-[#ef4444] border border-white shrink-0" />
                <span className="text-rose-300 font-bold">&gt; 30 min (Golden Hour Breach)</span>
              </div>
            </div>
          )}

          {/* Route Comparison Legend if route is active */}
          {selectedHospitalArea && (
            <div className="p-1.5 rounded bg-[#070b12] border border-cyan-800/60 space-y-1 mb-1">
              <span className="text-[8.5px] font-bold text-cyan-300 uppercase block">
                Hospital Routes:
              </span>
              <div className="flex items-center gap-2">
                <span className="w-3 h-1 rounded bg-[#06b6d4] shrink-0" />
                <span className="text-cyan-300 font-bold">Baseline Route</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-3 h-1 rounded bg-[#f43f5e] border border-dashed border-white shrink-0" />
                <span className="text-rose-300 font-bold">Flooded Detour Route</span>
              </div>
            </div>
          )}

          {mapMode === "utilization" ? (
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="w-3 h-1.5 rounded-sm bg-emerald-500 shrink-0" />
                <span className="text-slate-300">&lt; 70% Free Flow</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-3 h-1.5 rounded-sm bg-amber-500 shrink-0" />
                <span className="text-slate-300">70% - 100% Near Capacity</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-3 h-1.5 rounded-sm bg-rose-500 shrink-0" />
                <span className="text-slate-300">&gt; 100% Over Capacity</span>
              </div>
              {whatIfScenario?.hasActiveClosures && (
                <>
                  <div className="flex items-center gap-2 pt-0.5 border-t border-[#1a2538]">
                    <span className="w-3 h-1.5 rounded-sm bg-rose-600 border border-white shrink-0" />
                    <span className="text-rose-300 font-bold">Severed Corridor</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-1.5 rounded-sm bg-[#ec4899] shrink-0" />
                    <span className="text-[#f472b6] font-bold">Secondary Gridlock</span>
                  </div>
                </>
              )}
            </div>
          ) : (
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="w-3 h-1.5 rounded-sm bg-[#fb7185] shrink-0" />
                <span className="text-slate-300">Trunk / Flyover</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-3 h-1.5 rounded-sm bg-[#38bdf8] shrink-0" />
                <span className="text-slate-300">Primary Radial</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-3 h-1.5 rounded-sm bg-[#22d3ee] shrink-0" />
                <span className="text-slate-300">Secondary Link</span>
              </div>
            </div>
          )}

          <div className="flex items-center gap-2 pt-1 border-t border-[#172233]">
            <span className="w-2.5 h-2.5 rounded-full bg-red-600 text-white flex items-center justify-center text-[9px] font-black shrink-0">
              +
            </span>
            <span className="text-slate-300">Hospital (Red Cross)</span>
          </div>
        </div>
      </div>
    </div>
  );
}
