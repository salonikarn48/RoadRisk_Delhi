import React, { useState, useEffect, useRef, useCallback } from "react";
import { Search, MapPin, X, Loader2, Navigation } from "lucide-react";

export interface GeocodeResult {
  place_id: string;
  display_name: string;
  lat: number;
  lon: number;
  boundingbox?: string[]; // [south, north, west, east]
  type?: string;
  class?: string;
}

interface LocationSearchProps {
  onSelectLocation: (lat: number, lon: number, name: string, bbox?: [number, number, number, number]) => void;
  className?: string;
}

export default function LocationSearch({ onSelectLocation, className = "" }: LocationSearchProps) {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<GeocodeResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState<number>(-1);

  // In-memory client cache
  const clientCache = useRef<Map<string, GeocodeResult[]>>(new Map());
  const debounceTimer = useRef<any>(null);
  const wrapperRef = useRef<HTMLDivElement>(null);

  // Close on outside click
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const searchLocation = useCallback(async (q: string) => {
    const trimmed = q.trim();
    if (trimmed.length < 2) {
      setResults([]);
      setLoading(false);
      return;
    }

    const cacheKey = trimmed.toLowerCase();
    if (clientCache.current.has(cacheKey)) {
      setResults(clientCache.current.get(cacheKey)!);
      setIsOpen(true);
      setLoading(false);
      return;
    }

    setLoading(true);
    try {
      const res = await fetch(`/api/geocode?q=${encodeURIComponent(trimmed)}`);
      if (!res.ok) throw new Error("Search failed");
      const data = await res.json();
      const items: GeocodeResult[] = (data.results || []).slice(0, 5);
      clientCache.current.set(cacheKey, items);
      setResults(items);
      setIsOpen(items.length > 0);
    } catch (err) {
      console.info("Geocoding lookup failed:", err);
      setResults([]);
    } finally {
      setLoading(false);
    }
  }, []);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setQuery(val);
    setSelectedIndex(-1);

    if (debounceTimer.current) {
      clearTimeout(debounceTimer.current);
    }

    if (!val.trim()) {
      setResults([]);
      setIsOpen(false);
      return;
    }

    debounceTimer.current = setTimeout(() => {
      searchLocation(val);
    }, 300);
  };

  const handleSelect = (item: GeocodeResult) => {
    setQuery(item.display_name.split(",")[0]);
    setIsOpen(false);
    setSelectedIndex(-1);

    let bbox: [number, number, number, number] | undefined = undefined;
    if (item.boundingbox && item.boundingbox.length === 4) {
      const s = parseFloat(item.boundingbox[0]);
      const n = parseFloat(item.boundingbox[1]);
      const w = parseFloat(item.boundingbox[2]);
      const e = parseFloat(item.boundingbox[3]);
      if (!isNaN(s) && !isNaN(n) && !isNaN(w) && !isNaN(e)) {
        bbox = [s, w, n, e];
      }
    }

    onSelectLocation(item.lat, item.lon, item.display_name, bbox);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (!isOpen || results.length === 0) return;

    if (e.key === "ArrowDown") {
      e.preventDefault();
      setSelectedIndex((prev) => (prev < results.length - 1 ? prev + 1 : 0));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setSelectedIndex((prev) => (prev > 0 ? prev - 1 : results.length - 1));
    } else if (e.key === "Enter" && selectedIndex >= 0) {
      e.preventDefault();
      handleSelect(results[selectedIndex]);
    } else if (e.key === "Escape") {
      setIsOpen(false);
    }
  };

  const handleClear = () => {
    setQuery("");
    setResults([]);
    setIsOpen(false);
  };

  return (
    <div ref={wrapperRef} className={`relative font-sans text-xs ${className}`}>
      <div className="relative flex items-center">
        <div className="absolute left-3 pointer-events-none text-slate-400">
          {loading ? (
            <Loader2 className="w-3.5 h-3.5 animate-spin text-cyan-400" />
          ) : (
            <Search className="w-3.5 h-3.5" />
          )}
        </div>
        <input
          type="text"
          value={query}
          onChange={handleInputChange}
          onFocus={() => results.length > 0 && setIsOpen(true)}
          onKeyDown={handleKeyDown}
          placeholder="Search location in India (e.g. Lajpat Nagar, Rohini, Noida, Connaught Place)..."
          className="w-full pl-8 pr-8 py-2 bg-[#0b1017]/95 hover:bg-[#0e141d]/95 focus:bg-[#0e1520] border border-[#223348] focus:border-cyan-400/80 rounded-lg text-slate-100 placeholder-slate-400 font-mono text-[11.5px] outline-none shadow-lg backdrop-blur-md transition-all"
        />
        {query && (
          <button
            type="button"
            onClick={handleClear}
            className="absolute right-2.5 p-0.5 rounded hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition-colors"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {/* Dropdown Suggestions */}
      {isOpen && results.length > 0 && (
        <div className="absolute top-full left-0 right-0 mt-1.5 bg-[#0a0e16]/98 border border-[#24354d] rounded-lg shadow-2xl backdrop-blur-md z-[3000] overflow-hidden max-h-64 overflow-y-auto divide-y divide-[#182333]">
          <div className="px-3 py-1.5 text-[10px] font-mono text-cyan-400 uppercase tracking-wider bg-[#0f1724]">
            OpenStreetMap Location Matches ({results.length})
          </div>
          {results.map((item, idx) => {
            const parts = item.display_name.split(",");
            const title = parts[0]?.trim() || item.display_name;
            const subtitle = parts.slice(1, 4).join(", ").trim();
            const isSelected = idx === selectedIndex;

            return (
              <button
                key={item.place_id || idx}
                type="button"
                onClick={() => handleSelect(item)}
                onMouseEnter={() => setSelectedIndex(idx)}
                className={`w-full text-left px-3 py-2 flex items-start gap-2.5 transition-colors cursor-pointer ${
                  isSelected ? "bg-cyan-950/70 text-cyan-200" : "hover:bg-[#121a28] text-slate-200"
                }`}
              >
                <MapPin className={`w-3.5 h-3.5 mt-0.5 shrink-0 ${isSelected ? "text-cyan-400" : "text-slate-400"}`} />
                <div className="min-w-0 flex-1">
                  <div className="font-semibold text-[11.5px] truncate text-white">{title}</div>
                  {subtitle && (
                    <div className="text-[10px] text-slate-400 truncate font-mono">{subtitle}</div>
                  )}
                </div>
                <Navigation className="w-3 h-3 text-slate-500 shrink-0 mt-1" />
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}
