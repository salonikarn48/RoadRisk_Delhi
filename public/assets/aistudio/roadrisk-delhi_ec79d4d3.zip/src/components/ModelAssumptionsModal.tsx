import React from "react";
import {
  Info,
  X,
  Activity,
  Droplets,
  DollarSign,
  Cpu,
  CloudRain,
  Clock,
  ShieldAlert,
  CheckCircle2,
} from "lucide-react";
import { BPR_CONFIG } from "../simulation/traffic";
import { RAINFALL_LEVELS } from "../data/floodHotspots";
import { COST_DISCLAIMER } from "../data/fixCosts";

export interface ModelAssumptionsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function ModelAssumptionsModal({ isOpen, onClose }: ModelAssumptionsModalProps) {
  if (!isOpen) return null;

  const assumptions = [
    {
      id: "synthetic-demand",
      title: "1. Synthetic Demand (Illustrative)",
      icon: <Activity className="w-4 h-4 text-cyan-400" />,
      badge: "GRAVITY MODEL",
      summary: "Trip generation between 12 Central Delhi centroid intersection hubs",
      description:
        "Demand is synthetically modeled via a spatial gravity formulation (T_ij = K * (Mass_i * Mass_j) / (d_ij + 0.25)^1.5) connecting key CBD nodes (Connaught Place radials, Minto Bridge, ITO, Tilak Bridge, Delhi Gate, Mandi House). It reflects structural urban trip distributions without real-time GPS probe telemetry or census microdata.",
    },
    {
      id: "demo-hotspots",
      title: "2. Demo Hotspots (Public Lists)",
      icon: <Droplets className="w-4 h-4 text-blue-400" />,
      badge: "PWD / TRAFFIC POLICE",
      summary: "Illustrative locations based on published municipal waterlogging registries",
      description:
        "Hotspots (e.g. Minto Bridge Underpass, ITO Crossing, Tilak Bridge RUB, Delhi Gate) are derived from public Delhi Traffic Police annual monsoon advisories and PWD vulnerable underpass registers. Coordinates and nominal radiuses (240m–320m) are illustrative planning heuristics, not hydraulic site surveys.",
    },
    {
      id: "indicative-costs",
      title: "3. Indicative Fix Costs (CPWD / DSR)",
      icon: <DollarSign className="w-4 h-4 text-emerald-400" />,
      badge: "CPWD / DSR RATES",
      summary: `${COST_DISCLAIMER}`,
      description:
        "Costs for Quick fixes (high-power 3,000–5,000 GPM dewatering pumps & automated diversion barriers at ₹0.7–₹1.8 Cr, 8–18 days delivery) and Capital works (micro-tunneling storm culverts, sump deepening at ₹3.9–₹8.5 Cr, 5–10 months delivery) are indicative planning benchmarks calibrated to CPWD Delhi Schedule of Rates, not formal contractor tenders.",
    },
    {
      id: "bpr-parameters",
      title: "4. BPR Congestion Function Parameters",
      icon: <Cpu className="w-4 h-4 text-purple-400" />,
      badge: `α = ${BPR_CONFIG.ALPHA}, β = ${BPR_CONFIG.BETA}`,
      summary: "Iterative Dijkstra with Bureau of Public Roads delay formulation",
      description:
        `Travel time on each road link follows the standard BPR curve: t = t_0 * (1 + 0.15 * (V / C)^4), where V is assigned vehicular volume and C is OSM-derived lane capacity. Flows are solved using Method of Successive Averages (4 MSA iterations) with a numerical stability cap of 8.0x free-flow time to represent severe gridlock.`,
    },
    {
      id: "rainfall-multipliers",
      title: "5. Rainfall Radius Multipliers",
      icon: <CloudRain className="w-4 h-4 text-sky-400" />,
      badge: "HEURISTIC SCALING",
      summary: "Moderate (40%), Heavy (70%), Extreme (100% of surveyed hotspot radius)",
      description:
        "Rainfall intensity scales the geometric flood intersection radius: Moderate rainfall activates 40% of radius (low-depression collection); Heavy rainfall activates 70% (underpass sump breach); Extreme rainfall activates 100% (severe cloudburst spillover onto feeder radials). This is an operational heuristic, not IMD Doppler radar telemetry.",
    },
    {
      id: "golden-hour",
      title: "6. Golden Hour = 30 Minutes",
      icon: <Clock className="w-4 h-4 text-rose-400" />,
      badge: "THRESHOLD: 30 MIN",
      summary: "Emergency transit window from demand centroids to tertiary trauma facilities",
      description:
        "Emergency healthcare reachability evaluates congested travel time from 12 zone origins to the nearest tertiary trauma center (LNJP, GB Pant, RML Hospital, Lady Hardinge, Northern Railway Hospital). Trips under 15 min are classified as Safe, 15–30 min as Delayed, and trips exceeding 30 min (or severed) trigger a critical Golden Hour Breach alarm.",
    },
  ];

  return (
    <div className="fixed inset-0 z-[3000] flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-md select-none font-mono">
      <div className="w-full max-w-2xl bg-[#0b0f16] border border-[#233348] rounded-lg shadow-[0_20px_50px_rgba(0,0,0,0.9)] overflow-hidden flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="p-3.5 bg-[#0e1420] border-b border-[#1b2638] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded bg-[#152336] border border-cyan-500/40 flex items-center justify-center text-cyan-300">
              <Info className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-xs sm:text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <span>MODEL ASSUMPTIONS &amp; METHODOLOGY</span>
              </h2>
              <span className="text-[10px] text-slate-400 font-sans block">
                Theoretical framework, engineering formulas &amp; operational disclaimers
              </span>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded text-slate-400 hover:text-white hover:bg-[#1a2538] transition-colors cursor-pointer"
            title="Close assumptions"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content list */}
        <div className="p-4 overflow-y-auto space-y-3 flex-1">
          <div className="p-2.5 rounded bg-cyan-950/40 border border-cyan-800/50 text-[11px] text-cyan-200 font-sans leading-relaxed">
            <strong>PLANNING DISCLOSURE:</strong> RoadRisk is a pre-monsoon risk screening and infrastructure prioritization tool for MCD and PWD. Rather than hydraulic runoff forecasting, it models topological traffic rerouting and emergency trauma access loss when known underpasses flood.
          </div>

          <div className="space-y-2.5">
            {assumptions.map((item) => (
              <div
                key={item.id}
                className="p-3 rounded bg-[#101622] border border-[#1b273b] hover:border-[#283d5a] transition-colors space-y-1.5"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {item.icon}
                    <h3 className="text-xs font-bold text-white">{item.title}</h3>
                  </div>
                  <span className="text-[8.5px] font-bold px-1.5 py-0.2 rounded bg-[#162335] text-cyan-300 border border-cyan-800/60 uppercase">
                    {item.badge}
                  </span>
                </div>
                <div className="text-[10px] text-amber-300 font-medium">
                  {item.summary}
                </div>
                <p className="text-[11px] text-slate-300 font-sans leading-relaxed">
                  {item.description}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 bg-[#0a0d14] border-t border-[#182333] flex items-center justify-between shrink-0 text-[10px] text-slate-500">
          <div className="flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            <span>MCD / PWD Urban Resilience Protocol &bull; Central Delhi Zone</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="px-3 py-1 rounded bg-[#162438] hover:bg-[#1f324d] border border-cyan-500/40 text-cyan-200 font-bold transition-colors cursor-pointer"
          >
            DISMISS
          </button>
        </div>
      </div>
    </div>
  );
}
