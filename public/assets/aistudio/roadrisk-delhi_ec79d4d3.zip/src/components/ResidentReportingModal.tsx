import React, { useState } from "react";
import {
  Users,
  X,
  Camera,
  MapPin,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  ShieldAlert,
  FileCheck2,
  RefreshCw,
  Image as ImageIcon,
  Upload,
  Droplets,
  Clock,
  Sparkles,
} from "lucide-react";
import { FLOOD_HOTSPOTS } from "../data/floodHotspots";

export interface ResidentReportingModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export interface SubmittedReport {
  id: string;
  location: string;
  depth: string;
  roadClosed: boolean;
  description: string;
  timestamp: string;
  status: "Pending Field Validation" | "Verified by MCD Engineer";
  photoSample: string;
}

export default function ResidentReportingModal({ isOpen, onClose }: ResidentReportingModalProps) {
  const [location, setLocation] = useState<string>("Minto Bridge Railway Underpass");
  const [customStreet, setCustomStreet] = useState<string>("");
  const [waterDepth, setWaterDepth] = useState<string>("2 to 3 feet (Car axle submerged)");
  const [isPassable, setIsPassable] = useState<boolean>(false);
  const [description, setDescription] = useState<string>(
    "Underpass drain choked with silt. Water level rising fast; 2 cars stalled under bridge. Traffic backing up towards Connaught Place."
  );
  const [selectedPhoto, setSelectedPhoto] = useState<string>("minto_waterlogged.jpg");
  const [submittedReports, setSubmittedReports] = useState<SubmittedReport[]>([
    {
      id: "DEL-2026-8941",
      location: "Minto Bridge Railway Underpass",
      depth: "3+ feet (Fully impassable)",
      roadClosed: true,
      description: "Severe waterlogging near Shivaji Bridge rail cut. Water depth past knee level.",
      timestamp: "12 mins ago",
      status: "Verified by MCD Engineer",
      photoSample: "minto_waterlogged.jpg",
    },
    {
      id: "DEL-2026-8924",
      location: "ITO Junction / Vikas Marg",
      depth: "1.5 feet (Slow crawl)",
      roadClosed: false,
      description: "Water stagnation in left two lanes towards Laxmi Nagar.",
      timestamp: "45 mins ago",
      status: "Pending Field Validation",
      photoSample: "ito_crossing.jpg",
    },
  ]);
  const [hasJustSubmitted, setHasJustSubmitted] = useState<boolean>(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const resolvedLoc = customStreet.trim() ? customStreet.trim() : location;
    const newReport: SubmittedReport = {
      id: `DEL-2026-${Math.floor(1000 + Math.random() * 9000)}`,
      location: resolvedLoc,
      depth: waterDepth,
      roadClosed: !isPassable,
      description: description.trim() || "Water accumulation observed by resident.",
      timestamp: "Just now",
      status: "Pending Field Validation",
      photoSample: selectedPhoto,
    };

    setSubmittedReports([newReport, ...submittedReports]);
    setHasJustSubmitted(true);
    setTimeout(() => setHasJustSubmitted(false), 3500);
  };

  return (
    <div className="fixed inset-0 z-[3000] flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-md select-none font-mono">
      <div className="w-full max-w-2xl bg-[#0b0f16] border border-[#233348] rounded-lg shadow-[0_20px_50px_rgba(0,0,0,0.9)] overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-3.5 bg-[#0e1420] border-b border-[#1b2638] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded bg-[#162335] border border-cyan-500/40 flex items-center justify-center text-cyan-300">
              <Users className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xs sm:text-sm font-bold text-white uppercase tracking-wider">
                  RESIDENT REPORTING (CONCEPT MOCKUP)
                </h2>
                <span className="text-[8px] font-bold px-1.5 py-0.2 rounded bg-amber-950 text-amber-300 border border-amber-700/80 uppercase">
                  MOCKUP ONLY
                </span>
              </div>
              <span className="text-[10px] text-slate-400 font-sans block">
                Crowdsourced citizen reporting channel for MCD / PWD monsoon response
              </span>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded text-slate-400 hover:text-white hover:bg-[#1a2538] transition-colors cursor-pointer"
            title="Close modal"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="p-4 overflow-y-auto space-y-4 flex-1">
          {/* NOTICE: NOT CONNECTED TO SIMULATION */}
          <div className="p-2.5 rounded bg-[#191209] border border-amber-600/70 text-amber-200 text-xs font-sans space-y-1">
            <div className="flex items-center gap-1.5 font-bold font-mono text-amber-300 text-[11px] uppercase">
              <ShieldAlert className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              <span>CONCEPT MOCKUP &bull; NOT CONNECTED TO SIMULATION</span>
            </div>
            <p className="text-[10.5px] leading-relaxed">
              This intake interface is a design prototype illustrating how crowdsourced citizen hazard reports flow into municipal operations. Submissions here do <strong>not</strong> alter live simulation physics or topological link weights.
            </p>
          </div>

          {/* PROCESS DIAGRAM: reports → validation → feed back into inputs */}
          <div className="p-3 rounded bg-[#090d14] border border-[#1d293d] space-y-2">
            <span className="text-[9.5px] font-bold uppercase tracking-wider text-cyan-400 flex items-center gap-1.5">
              <Sparkles className="w-3 h-3 text-cyan-300" />
              <span>OPERATIONAL DATA PIPELINE DIAGRAM</span>
            </span>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-center pt-1">
              {/* Step 1 */}
              <div className="p-2.5 rounded bg-[#0f1622] border border-[#1b2a40] space-y-1 relative">
                <div className="w-7 h-7 mx-auto rounded-full bg-[#182638] border border-cyan-500/50 flex items-center justify-center text-cyan-300">
                  <Camera className="w-3.5 h-3.5" />
                </div>
                <div className="text-[10.5px] font-bold text-white">1. Citizen Reports</div>
                <div className="text-[9px] text-slate-400 font-sans leading-tight">
                  Location, water depth &amp; photo tagged via mobile app
                </div>
              </div>

              {/* Step 2 */}
              <div className="p-2.5 rounded bg-[#0f1622] border border-[#1b2a40] space-y-1 relative">
                <div className="w-7 h-7 mx-auto rounded-full bg-[#182638] border border-amber-500/50 flex items-center justify-center text-amber-300">
                  <FileCheck2 className="w-3.5 h-3.5" />
                </div>
                <div className="text-[10.5px] font-bold text-white">2. Validation Gate</div>
                <div className="text-[9px] text-amber-300/90 font-sans leading-tight font-medium">
                  Verified by MCD/PWD engineers &amp; CCTV footage before use
                </div>
              </div>

              {/* Step 3 */}
              <div className="p-2.5 rounded bg-[#0f1622] border border-[#1b2a40] space-y-1">
                <div className="w-7 h-7 mx-auto rounded-full bg-[#182638] border border-emerald-500/50 flex items-center justify-center text-emerald-300">
                  <RefreshCw className="w-3.5 h-3.5" />
                </div>
                <div className="text-[10.5px] font-bold text-white">3. Feed into Inputs</div>
                <div className="text-[9px] text-slate-400 font-sans leading-tight">
                  Verified severances feed into road resilience cascade model
                </div>
              </div>
            </div>

            <div className="text-center text-[10px] text-cyan-300/80 font-mono pt-1">
              reports &rarr; validation &rarr; feed back into inputs
            </div>
          </div>

          {/* SUBMISSION FORM */}
          <form onSubmit={handleSubmit} className="p-3.5 rounded bg-[#0e1420] border border-[#1c293d] space-y-3">
            <div className="text-[10.5px] font-bold text-slate-200 uppercase tracking-wider flex items-center justify-between border-b border-[#182334] pb-1.5">
              <span className="flex items-center gap-1.5">
                <Droplets className="w-3.5 h-3.5 text-cyan-400" />
                <span>SUBMIT WATERLOGGING OBSERVATION</span>
              </span>
              <span className="text-[9px] text-slate-500">Citizen Form</span>
            </div>

            {/* Location selector */}
            <div className="space-y-1">
              <label className="text-[10px] text-slate-300 font-bold uppercase flex items-center gap-1">
                <MapPin className="w-3 h-3 text-cyan-400" />
                <span>Incident Location (Central Delhi):</span>
              </label>
              <select
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                className="w-full bg-[#080c14] border border-[#23354c] text-white text-xs rounded px-2.5 py-1.5 font-mono focus:outline-none focus:border-cyan-400 cursor-pointer"
              >
                {FLOOD_HOTSPOTS.map((h) => (
                  <option key={h.id || h.name} value={h.name}>
                    {h.name}
                  </option>
                ))}
                <option value="Custom Street / Intersection">-- Other Street / Colony Road --</option>
              </select>

              {location === "Custom Street / Intersection" && (
                <input
                  type="text"
                  placeholder="Enter street name, colony or intersection..."
                  value={customStreet}
                  onChange={(e) => setCustomStreet(e.target.value)}
                  className="w-full mt-1 bg-[#080c14] border border-[#23354c] text-white text-xs rounded px-2.5 py-1.5 font-sans focus:outline-none focus:border-cyan-400"
                />
              )}
            </div>

            {/* Estimated Water Depth & Passability */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <div className="space-y-1">
                <label className="text-[10px] text-slate-300 font-bold uppercase block">
                  Observed Water Stagnation Depth:
                </label>
                <select
                  value={waterDepth}
                  onChange={(e) => setWaterDepth(e.target.value)}
                  className="w-full bg-[#080c14] border border-[#23354c] text-white text-xs rounded px-2 py-1.5 font-mono focus:outline-none focus:border-cyan-400 cursor-pointer"
                >
                  <option value="6 to 12 inches (Curb overtopping)">6 to 12 inches (Curb overtopping)</option>
                  <option value="1 to 2 feet (Knee level, small cars stuck)">1 to 2 feet (Knee level, small cars stuck)</option>
                  <option value="2 to 3 feet (Car axle submerged)">2 to 3 feet (Car axle submerged)</option>
                  <option value="3+ feet (Fully submerged / underpass blocked)">3+ feet (Fully submerged / underpass blocked)</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] text-slate-300 font-bold uppercase block">
                  Vehicular Passability:
                </label>
                <div className="grid grid-cols-2 gap-1.5 pt-0.5">
                  <button
                    type="button"
                    onClick={() => setIsPassable(false)}
                    className={`py-1.5 px-2 rounded text-[10.5px] font-bold border transition-colors cursor-pointer ${
                      !isPassable
                        ? "bg-rose-950 text-rose-200 border-rose-600 shadow-sm"
                        : "bg-[#080c14] border-[#1f2b3c] text-slate-400 hover:text-white"
                    }`}
                  >
                    Impassable (Blocked)
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsPassable(true)}
                    className={`py-1.5 px-2 rounded text-[10.5px] font-bold border transition-colors cursor-pointer ${
                      isPassable
                        ? "bg-amber-950 text-amber-200 border-amber-600 shadow-sm"
                        : "bg-[#080c14] border-[#1f2b3c] text-slate-400 hover:text-white"
                    }`}
                  >
                    Crawling / 1 Lane
                  </button>
                </div>
              </div>
            </div>

            {/* Photo Placeholder Area */}
            <div className="space-y-1">
              <label className="text-[10px] text-slate-300 font-bold uppercase flex items-center justify-between">
                <span className="flex items-center gap-1">
                  <ImageIcon className="w-3 h-3 text-cyan-400" />
                  <span>Geotagged Photo Evidence (Placeholder):</span>
                </span>
                <span className="text-[9px] text-slate-500">EXIF Geolocation</span>
              </label>

              <div className="p-3 border-2 border-dashed border-[#23354d] hover:border-cyan-500/60 rounded bg-[#080c14] text-center space-y-1.5 transition-colors cursor-pointer">
                <div className="w-8 h-8 mx-auto rounded-full bg-[#131d2b] flex items-center justify-center text-cyan-400">
                  <Upload className="w-4 h-4" />
                </div>
                <div className="text-[11px] text-slate-300 font-sans">
                  Drag &amp; drop waterlogging photo or <span className="text-cyan-400 underline">browse device</span>
                </div>
                <div className="text-[9px] text-slate-500">
                  Simulated upload: attaches GPS timestamp and visual flood gauge stamp
                </div>

                {/* Simulated photo options */}
                <div className="flex justify-center gap-2 pt-1">
                  {[
                    { id: "minto_waterlogged.jpg", label: "Minto Bridge RUB (3.2 ft)" },
                    { id: "ito_crossing.jpg", label: "ITO Radial Slipway" },
                    { id: "tilak_inundation.jpg", label: "Tilak Underpass" },
                  ].map((p) => (
                    <button
                      key={p.id}
                      type="button"
                      onClick={() => setSelectedPhoto(p.id)}
                      className={`text-[9px] px-2 py-0.5 rounded border transition-colors cursor-pointer ${
                        selectedPhoto === p.id
                          ? "bg-cyan-950 text-cyan-200 border-cyan-500"
                          : "bg-[#101824] text-slate-400 border-[#1f2a3c] hover:text-slate-200"
                      }`}
                    >
                      {p.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Description */}
            <div className="space-y-1">
              <label className="text-[10px] text-slate-300 font-bold uppercase block">
                Field Description &amp; Public Safety Impact:
              </label>
              <textarea
                rows={2}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Describe water accumulation, stuck emergency vehicles, or choked stormwater drains..."
                className="w-full bg-[#080c14] border border-[#23354c] text-slate-200 text-xs rounded p-2 font-sans focus:outline-none focus:border-cyan-400 resize-none"
              />
            </div>

            {/* MANDATORY VALIDATED BEFORE USE NOTE */}
            <div className="p-2.5 rounded bg-[#091512] border border-[#16382e] text-[10.5px] text-emerald-200 font-sans leading-relaxed flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <strong>Validated before use:</strong> All resident reports are quarantined in a pending review queue and rigorously verified by municipal engineers via field inspection or traffic CCTV cameras before being fed back into inputs.
              </div>
            </div>

            {/* Submit Action Button */}
            <div className="pt-1">
              <button
                type="submit"
                className="w-full py-2.5 px-4 rounded bg-gradient-to-r from-cyan-600 to-sky-600 hover:from-cyan-500 hover:to-sky-500 text-slate-950 font-mono font-bold text-xs flex items-center justify-center gap-2 cursor-pointer shadow-[0_0_15px_rgba(6,182,212,0.3)] transition-all"
              >
                <Upload className="w-3.5 h-3.5 text-slate-950" />
                <span className="uppercase tracking-wider">SUBMIT REPORT TO MCD QUEUE (MOCKUP)</span>
              </button>
            </div>

            {hasJustSubmitted && (
              <div className="p-2 rounded bg-emerald-950 border border-emerald-500 text-emerald-200 text-xs text-center font-bold animate-pulse">
                ✓ Report logged into Mockup Intake Ledger (Status: Pending Field Validation)
              </div>
            )}
          </form>

          {/* RECENT SUBMISSIONS QUEUE */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-[10px] text-slate-400 uppercase font-bold">
              <span>RECENT COMMUNITY LOGS ({submittedReports.length})</span>
              <span className="text-cyan-400">Intake Ledger</span>
            </div>

            <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
              {submittedReports.map((item) => (
                <div
                  key={item.id}
                  className="p-2.5 rounded bg-[#0a0f18] border border-[#182333] space-y-1 text-xs"
                >
                  <div className="flex items-start justify-between gap-1">
                    <div>
                      <div className="font-bold text-white text-xs flex items-center gap-1.5">
                        <span className="text-cyan-400">{item.id}</span>
                        <span>&bull;</span>
                        <span className="truncate">{item.location}</span>
                      </div>
                      <div className="text-[10px] text-slate-400 mt-0.5">
                        Depth: <strong className="text-amber-300">{item.depth}</strong> &bull; {item.timestamp}
                      </div>
                    </div>
                    <span
                      className={`text-[8.5px] px-1.5 py-0.2 rounded font-bold uppercase shrink-0 border ${
                        item.status === "Verified by MCD Engineer"
                          ? "bg-emerald-950 text-emerald-300 border-emerald-700"
                          : "bg-amber-950 text-amber-300 border-amber-700"
                      }`}
                    >
                      {item.status}
                    </span>
                  </div>
                  <p className="text-[10px] text-slate-300 font-sans leading-snug">
                    {item.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 bg-[#0a0d14] border-t border-[#182333] flex items-center justify-between shrink-0 text-[10px] text-slate-500">
          <span>Central Delhi Civic Resilience &bull; MCD Zone SP-City</span>
          <button
            type="button"
            onClick={onClose}
            className="px-3 py-1 rounded bg-[#162438] hover:bg-[#1f324d] border border-cyan-500/40 text-cyan-200 font-bold transition-colors cursor-pointer"
          >
            DISMISS
          </button>
        </div>
      </div>
    </div>
  );
}
