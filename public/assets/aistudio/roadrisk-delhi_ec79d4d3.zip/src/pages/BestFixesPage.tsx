import React from "react";
import { Link, useNavigate } from "react-router-dom";
import {
  Award,
  Home,
  Map,
  CloudRain,
  MapPin,
  Droplets,
  AlertTriangle,
  ArrowRight,
  Sparkles,
  Radio,
  Users,
  Info,
  Scan,
} from "lucide-react";
import BestFixesTab from "../components/BestFixesTab";
import { useAppState } from "../context/AppStateContext";

export default function BestFixesPage() {
  const navigate = useNavigate();
  const {
    currentZone,
    roads,
    graph,
    odPairs,
    hospitals,
    rainfallLevel,
    whatIfScenario,
    activeZoneHotspots,
    setSelectedHotspotId,
    setActiveTab,
  } = useAppState();

  const floodedCount = whatIfScenario?.floodedHotspots?.length || 0;
  const floodedNames = whatIfScenario?.floodedHotspots?.map((h) => h.name).join(", ");

  const hasAnalysis = Boolean(roads && roads.length > 0 && graph);

  return (
    <div className="relative w-full h-full min-h-screen bg-[#080b10] text-slate-100 flex flex-col justify-between overflow-x-hidden overflow-y-auto font-sans select-none">
      {/* Background Matrix & Subtle Ambient Glow */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div
          className="absolute inset-0 opacity-[0.05]"
          style={{
            backgroundImage: `radial-gradient(circle at 1px 1px, #38bdf8 1px, transparent 0)`,
            backgroundSize: "32px 32px",
          }}
        />
        <div className="absolute -top-32 left-1/3 w-[600px] h-[600px] bg-emerald-500/[0.07] rounded-full blur-[140px]" />
        <div className="absolute top-1/2 -right-32 w-[600px] h-[600px] bg-cyan-600/[0.05] rounded-full blur-[150px]" />
      </div>

      {/* Top Header Navigation */}
      <header className="relative z-10 w-full px-5 lg:px-10 py-4 border-b border-[#182333]/80 bg-[#090c10]/80 backdrop-blur-md flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded bg-[#131c2a] border border-[#24354d] flex items-center justify-center text-emerald-400 shadow-[0_0_15px_rgba(16,185,129,0.25)]">
            <Award className="w-4 h-4" />
          </div>
          <div>
            <div className="font-mono font-black text-sm tracking-tight text-white flex items-center gap-1.5">
              <span>ROADRISK DELHI</span>
              <span className="text-[10px] text-emerald-400 px-1.5 py-0.2 rounded bg-emerald-950/80 border border-emerald-800/60 font-semibold tracking-wider">
                BEST FIXES OPTIMIZER
              </span>
            </div>
            <div className="text-[10px] font-mono text-slate-500 uppercase tracking-widest hidden sm:block">
              CPWD / DSR Pareto Capital &amp; Quick Drainage Recommender
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <Link
            to="/"
            className="px-2.5 py-1.5 rounded bg-[#131c2a] hover:bg-[#1c2738] border border-[#23354d] text-slate-300 hover:text-white font-mono text-xs flex items-center gap-1.5 transition-colors cursor-pointer shadow-sm"
            title="Return to Home / Cover Page"
          >
            <Home className="w-3.5 h-3.5 text-cyan-400" />
            <span className="font-bold">HOME</span>
          </Link>

          <Link
            to="/dashboard"
            className="px-3 py-1.5 rounded bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs flex items-center gap-1.5 transition-colors shadow-sm cursor-pointer"
            title="Open Interactive Simulation Dashboard"
          >
            <Map className="w-3.5 h-3.5" />
            <span>DASHBOARD</span>
          </Link>

          <Link
            to="/select-area"
            className="hidden sm:flex px-2.5 py-1.5 rounded bg-[#131c2a] hover:bg-[#1c2738] border border-[#23354d] text-slate-300 hover:text-white font-mono text-xs items-center gap-1.5 transition-colors cursor-pointer"
            title="Select or draw custom analysis zone"
          >
            <Scan className="w-3.5 h-3.5 text-amber-400" />
            <span>AREA</span>
          </Link>

          <Link
            to="/live-feed"
            className="hidden md:flex px-2.5 py-1.5 rounded bg-[#131c2a] hover:bg-[#1c2738] border border-[#23354d] text-slate-300 hover:text-white font-mono text-xs items-center gap-1.5 transition-colors cursor-pointer"
            title="Open TinyFish Live Feed"
          >
            <Radio className="w-3.5 h-3.5 text-cyan-400" />
            <span>LIVE FEED</span>
          </Link>

          <Link
            to="/reports"
            className="hidden lg:flex px-2.5 py-1.5 rounded bg-[#131c2a] hover:bg-[#1c2738] border border-[#23354d] text-slate-300 hover:text-white font-mono text-xs items-center gap-1.5 transition-colors cursor-pointer"
            title="Open Resident Reporting"
          >
            <Users className="w-3.5 h-3.5 text-amber-400" />
            <span>REPORTS</span>
          </Link>

          <Link
            to="/assumptions"
            className="hidden lg:flex px-2.5 py-1.5 rounded bg-[#131c2a] hover:bg-[#1c2738] border border-[#23354d] text-slate-300 hover:text-white font-mono text-xs items-center gap-1.5 transition-colors cursor-pointer"
            title="Open Model Assumptions"
          >
            <Info className="w-3.5 h-3.5 text-sky-400" />
            <span>ASSUMPTIONS</span>
          </Link>
        </div>
      </header>

      {/* Main Content */}
      <main className="relative z-10 flex-1 w-full max-w-4xl mx-auto px-4 sm:px-6 py-8 space-y-6">
        {/* Scenario Summary Banner at Top */}
        <div className="p-4 rounded-xl bg-[#0e1420] border border-[#1e2a3f] shadow-lg font-mono text-xs space-y-3">
          <div className="flex items-center justify-between border-b border-[#182333] pb-2">
            <span className="text-[10.5px] font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              <span>ACTIVE SCENARIO SUMMARY</span>
            </span>
            <span className="text-[9px] px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold uppercase">
              Pareto Recommender
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
            {/* Area */}
            <div className="p-2.5 rounded bg-[#080d14] border border-[#162234] space-y-1">
              <div className="flex items-center gap-1.5 text-slate-400 text-[10px] uppercase">
                <MapPin className="w-3 h-3 text-cyan-400" />
                <span>Selected Area:</span>
              </div>
              <div className="font-bold text-white text-xs truncate">
                {currentZone.name}
              </div>
            </div>

            {/* Flooded Hotspots */}
            <div className="p-2.5 rounded bg-[#080d14] border border-[#162234] space-y-1">
              <div className="flex items-center gap-1.5 text-slate-400 text-[10px] uppercase">
                <Droplets className="w-3 h-3 text-rose-400" />
                <span>Inundated Hotspots:</span>
              </div>
              <div className="font-bold text-white text-xs truncate">
                {floodedCount > 0 ? (
                  <span className="text-rose-400">{floodedCount} spots ({floodedNames})</span>
                ) : (
                  <span className="text-slate-400">None (Baseline / Nominal)</span>
                )}
              </div>
            </div>

            {/* Rainfall Level */}
            <div className="p-2.5 rounded bg-[#080d14] border border-[#162234] space-y-1">
              <div className="flex items-center gap-1.5 text-slate-400 text-[10px] uppercase">
                <CloudRain className="w-3 h-3 text-blue-400" />
                <span>Rainfall Level:</span>
              </div>
              <div className="font-bold text-white text-xs">
                <span className="text-cyan-300">{rainfallLevel}</span>{" "}
                <span className="text-[10px] text-slate-500 font-normal">
                  ({rainfallLevel === "Moderate" ? "40%" : rainfallLevel === "Heavy" ? "70%" : "100%"} radius)
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Optimizer Component or Empty State */}
        {hasAnalysis ? (
          <div className="bg-[#0b1017] rounded-xl border border-[#1b2738] p-4 sm:p-6 shadow-2xl">
            <BestFixesTab
              graph={graph}
              roads={roads}
              odPairs={odPairs}
              hospitals={hospitals}
              rainfallLevel={rainfallLevel}
              targetHotspots={activeZoneHotspots}
              onSimulateHotspotFix={(hotspotId) => {
                setSelectedHotspotId(hotspotId);
                setActiveTab("what_if");
                navigate("/dashboard");
              }}
              onNavigateToWhatIf={() => {
                setActiveTab("what_if");
                navigate("/dashboard");
              }}
            />
          </div>
        ) : (
          <div className="p-8 rounded-xl bg-[#0e131d] border border-[#1e2a3c] text-center space-y-4 max-w-md mx-auto font-mono">
            <div className="w-12 h-12 rounded-full bg-cyan-950/60 border border-cyan-500/40 text-cyan-400 flex items-center justify-center mx-auto">
              <AlertTriangle className="w-6 h-6 text-amber-400" />
            </div>
            <div className="space-y-1">
              <h2 className="text-sm font-bold text-white uppercase tracking-wider">
                No Network Analysis Initialized
              </h2>
              <p className="text-xs text-slate-400 font-sans leading-relaxed">
                The municipal fix optimizer requires an active road graph and demand matrix. Open the simulation dashboard to initialize the network.
              </p>
            </div>
            <button
              type="button"
              onClick={() => navigate("/dashboard")}
              className="px-4 py-2.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs flex items-center justify-center gap-2 mx-auto cursor-pointer shadow-md transition-all"
            >
              <span>Go to Dashboard</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="relative z-10 w-full px-5 lg:px-10 py-4 border-t border-[#182333]/80 bg-[#06080d]/90 backdrop-blur-md flex flex-col sm:flex-row items-center justify-between text-[11px] font-mono text-slate-500 gap-2">
        <div className="flex items-center gap-2 text-center sm:text-left">
          <span>Illustrative simulation model. Data is synthetic or indicative. Team Pixel Pioneers</span>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-slate-400 font-bold">Team Pixel Pioneers</span>
          <span className="text-slate-600">&bull;</span>
          <span>Central Delhi Urban Resilience Lab</span>
        </div>
      </footer>
    </div>
  );
}
