import React from "react";
import { Link } from "react-router-dom";
import {
  Info,
  Home,
  Map,
  Activity,
  Droplets,
  DollarSign,
  Cpu,
  CloudRain,
  Clock,
  ShieldAlert,
  CheckCircle2,
  Radio,
  Award,
  Users,
} from "lucide-react";
import { BPR_CONFIG } from "../simulation/traffic";
import { RAINFALL_LEVELS } from "../data/floodHotspots";
import { COST_DISCLAIMER } from "../data/fixCosts";

export default function AssumptionsPage() {
  const assumptions = [
    {
      id: "synthetic-demand",
      title: "1. Synthetic Demand (Illustrative)",
      icon: <Activity className="w-5 h-5 text-cyan-400" />,
      badge: "GRAVITY MODEL",
      summary: "Trip generation between 12 Central Delhi centroid intersection hubs",
      description:
        "Demand is synthetically modeled via a spatial gravity formulation (T_ij = K * (Mass_i * Mass_j) / (d_ij + 0.25)^1.5) connecting key CBD nodes (Connaught Place radials, Minto Bridge, ITO, Tilak Bridge, Delhi Gate, Mandi House). It reflects structural urban trip distributions without real-time GPS probe telemetry or census microdata.",
    },
    {
      id: "demo-hotspots",
      title: "2. Demo Hotspots (Public Lists)",
      icon: <Droplets className="w-5 h-5 text-blue-400" />,
      badge: "PWD / TRAFFIC POLICE",
      summary: "Illustrative locations based on published municipal waterlogging registries",
      description:
        "Hotspots (e.g. Minto Bridge Underpass, ITO Crossing, Tilak Bridge RUB, Delhi Gate) are derived from public Delhi Traffic Police annual monsoon advisories and PWD vulnerable underpass registers. Coordinates and nominal radiuses (240m–320m) are illustrative planning heuristics, not hydraulic site surveys.",
    },
    {
      id: "indicative-costs",
      title: "3. Indicative Fix Costs (CPWD / DSR)",
      icon: <DollarSign className="w-5 h-5 text-emerald-400" />,
      badge: "CPWD / DSR RATES",
      summary: `${COST_DISCLAIMER}`,
      description:
        "Costs for Quick fixes (high-power 3,000–5,000 GPM dewatering pumps & automated diversion barriers at ₹0.7–₹1.8 Cr, 8–18 days delivery) and Capital works (micro-tunneling storm culverts, sump deepening at ₹3.9–₹8.5 Cr, 5–10 months delivery) are indicative planning benchmarks calibrated to CPWD Delhi Schedule of Rates, not formal contractor tenders.",
    },
    {
      id: "bpr-parameters",
      title: "4. BPR Congestion Function Parameters",
      icon: <Cpu className="w-5 h-5 text-purple-400" />,
      badge: `α = ${BPR_CONFIG.ALPHA}, β = ${BPR_CONFIG.BETA}`,
      summary: "Iterative Dijkstra with Bureau of Public Roads delay formulation",
      description:
        `Travel time on each road link follows the standard BPR curve: t = t_0 * (1 + 0.15 * (V / C)^4), where V is assigned vehicular volume and C is OSM-derived lane capacity. Flows are solved using Method of Successive Averages (4 MSA iterations) with a numerical stability cap of 8.0x free-flow time to represent severe gridlock.`,
    },
    {
      id: "rainfall-multipliers",
      title: "5. Rainfall Radius Multipliers",
      icon: <CloudRain className="w-5 h-5 text-sky-400" />,
      badge: "HEURISTIC SCALING",
      summary: "Moderate (40%), Heavy (70%), Extreme (100% of surveyed hotspot radius)",
      description:
        "Rainfall intensity scales the geometric flood intersection radius: Moderate rainfall activates 40% of radius (low-depression collection); Heavy rainfall activates 70% (underpass sump breach); Extreme rainfall activates 100% (severe cloudburst spillover onto feeder radials). This is an operational heuristic, not IMD Doppler radar telemetry.",
    },
    {
      id: "golden-hour",
      title: "6. Golden Hour = 30 Minutes",
      icon: <Clock className="w-5 h-5 text-rose-400" />,
      badge: "THRESHOLD: 30 MIN",
      summary: "Emergency transit window from demand centroids to tertiary trauma facilities",
      description:
        "Emergency healthcare reachability evaluates congested travel time from 12 zone origins to the nearest tertiary trauma center (LNJP, GB Pant, RML Hospital, Lady Hardinge, Northern Railway Hospital). Trips under 15 min are classified as Safe, 15–30 min as Delayed, and trips exceeding 30 min (or severed) trigger a critical Golden Hour Breach alarm.",
    },
  ];

  return (
    <div className="relative w-full h-full min-h-screen bg-[#080b10] text-slate-100 flex flex-col justify-between overflow-x-hidden overflow-y-auto font-sans select-none">
      {/* Background Matrix & Subtle Ambient Glow */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div
          className="absolute inset-0 opacity-[0.05]"
          style={{
            backgroundImage: `radial-gradient(circle at 1px 1px, #38bdf8 1px, transparent 0)`,
            backgroundSize: "32px 32px",
          }}
        />
        <div className="absolute -top-32 left-1/3 w-[600px] h-[600px] bg-sky-500/[0.07] rounded-full blur-[140px]" />
        <div className="absolute top-1/2 -right-32 w-[600px] h-[600px] bg-cyan-600/[0.05] rounded-full blur-[150px]" />
      </div>

      {/* Top Header Navigation */}
      <header className="relative z-10 w-full px-4 sm:px-6 lg:px-10 py-3.5 border-b border-[#182333]/80 bg-[#090c10]/85 backdrop-blur-md flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded bg-[#131c2a] border border-[#24354d] flex items-center justify-center text-[#38bdf8] shadow-[0_0_15px_rgba(56,189,248,0.25)]">
            <Info className="w-4 h-4" />
          </div>
          <div>
            <div className="font-mono font-black text-sm tracking-tight text-white flex items-center gap-1.5">
              <span>ROADRISK DELHI</span>
              <span className="text-[10px] text-[#38bdf8] px-1.5 py-0.2 rounded bg-sky-950/80 border border-sky-800/60 font-semibold tracking-wider">
                MODEL ASSUMPTIONS
              </span>
            </div>
            <div className="text-[10px] font-mono text-slate-500 uppercase tracking-widest hidden sm:block">
              Theoretical framework, engineering formulas &amp; operational disclaimers
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <Link
            to="/"
            className="px-2.5 py-1.5 rounded bg-[#131c2a] hover:bg-[#1c2738] border border-[#23354d] text-slate-300 hover:text-white font-mono text-xs flex items-center gap-1.5 transition-colors cursor-pointer shadow-sm"
            title="Return to Home / Cover Page"
          >
            <Home className="w-3.5 h-3.5 text-cyan-400" />
            <span className="font-bold">HOME</span>
          </Link>

          <Link
            to="/dashboard"
            className="px-3 py-1.5 rounded bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs flex items-center gap-1.5 transition-colors shadow-sm cursor-pointer"
            title="Open Interactive Simulation Dashboard"
          >
            <Map className="w-3.5 h-3.5" />
            <span>DASHBOARD</span>
          </Link>

          <Link
            to="/live-feed"
            className="hidden md:flex px-2.5 py-1.5 rounded bg-[#131c2a] hover:bg-[#1c2738] border border-[#23354d] text-slate-300 hover:text-white font-mono text-xs items-center gap-1.5 transition-colors cursor-pointer"
            title="Open TinyFish Live Feed"
          >
            <Radio className="w-3.5 h-3.5 text-cyan-400" />
            <span>LIVE FEED</span>
          </Link>

          <Link
            to="/best-fixes"
            className="hidden md:flex px-2.5 py-1.5 rounded bg-[#131c2a] hover:bg-[#1c2738] border border-[#23354d] text-slate-300 hover:text-white font-mono text-xs items-center gap-1.5 transition-colors cursor-pointer"
            title="Open Best Fixes Optimizer"
          >
            <Award className="w-3.5 h-3.5 text-emerald-400" />
            <span>BEST FIXES</span>
          </Link>

          <Link
            to="/reports"
            className="hidden lg:flex px-2.5 py-1.5 rounded bg-[#131c2a] hover:bg-[#1c2738] border border-[#23354d] text-slate-300 hover:text-white font-mono text-xs items-center gap-1.5 transition-colors cursor-pointer"
            title="Open Resident Reporting"
          >
            <Users className="w-3.5 h-3.5 text-amber-400" />
            <span>REPORTS</span>
          </Link>
        </div>
      </header>

      {/* Main Content */}
      <main className="relative z-10 flex-1 w-full max-w-4xl mx-auto px-4 sm:px-6 py-8 space-y-6 font-mono text-xs">
        {/* Planning Disclosure Banner */}
        <div className="p-4 rounded-xl bg-cyan-950/40 border border-cyan-800/60 text-xs text-cyan-200 font-sans leading-relaxed shadow-lg flex items-start gap-3">
          <Info className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />
          <div>
            <strong className="text-white font-mono uppercase tracking-wider block mb-1">
              PLANNING DISCLOSURE &amp; ENGINEERING SCOPE:
            </strong>
            RoadRisk is a pre-monsoon risk screening and infrastructure prioritization tool designed for MCD and PWD road asset managers. Rather than dynamic 2D hydrodynamic runoff modeling, it evaluates topological traffic rerouting, secondary congestion cascades, and emergency hospital access severance when known arterial underpasses flood.
          </div>
        </div>

        {/* Assumptions Cards Grid */}
        <div className="space-y-3.5">
          {assumptions.map((item) => (
            <div
              key={item.id}
              className="p-4 sm:p-5 rounded-xl bg-[#0e1420] border border-[#1b273b] hover:border-[#283d5a] transition-colors space-y-2.5 shadow-md"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#182334] pb-2">
                <div className="flex items-center gap-2.5">
                  <div className="p-1.5 rounded bg-[#131c2a] border border-[#223348]">
                    {item.icon}
                  </div>
                  <h3 className="text-sm font-bold text-white tracking-wide">{item.title}</h3>
                </div>
                <span className="text-[9.5px] font-bold px-2 py-0.5 rounded bg-[#162335] text-cyan-300 border border-cyan-800/60 uppercase self-start sm:self-auto">
                  {item.badge}
                </span>
              </div>

              <div className="text-xs text-amber-300 font-medium">
                {item.summary}
              </div>

              <p className="text-xs text-slate-300 font-sans leading-relaxed">
                {item.description}
              </p>
            </div>
          ))}
        </div>

        {/* Resilience Protocol Badge */}
        <div className="p-3.5 rounded-lg bg-[#091512] border border-[#16382e] text-xs text-emerald-200 font-sans leading-relaxed flex items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>MCD / PWD Urban Resilience Protocol &bull; Central Delhi Zone Calibrated</span>
          </div>
          <Link
            to="/dashboard"
            className="px-3 py-1.5 rounded bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold font-mono text-[11px] transition-colors shrink-0"
          >
            TEST IN SIMULATION &rarr;
          </Link>
        </div>
      </main>

      {/* Footer */}
      <footer className="relative z-10 w-full px-5 lg:px-10 py-4 border-t border-[#182333]/80 bg-[#06080d]/90 backdrop-blur-md flex flex-col sm:flex-row items-center justify-between text-[11px] font-mono text-slate-500 gap-2">
        <div className="flex items-center gap-2 text-center sm:text-left">
          <span>Illustrative simulation model. Data is synthetic or indicative. Team Pixel Pioneers</span>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-slate-400 font-bold">Team Pixel Pioneers</span>
          <span className="text-slate-600">&bull;</span>
          <span>Central Delhi Urban Resilience Lab</span>
        </div>
      </footer>
    </div>
  );
}
