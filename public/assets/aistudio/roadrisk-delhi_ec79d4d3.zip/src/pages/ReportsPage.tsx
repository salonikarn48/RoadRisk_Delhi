import React, { useState } from "react";
import { Link } from "react-router-dom";
import {
  Users,
  Home,
  Map,
  Camera,
  MapPin,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  ShieldAlert,
  FileCheck2,
  RefreshCw,
  Image as ImageIcon,
  Upload,
  Droplets,
  Clock,
  Sparkles,
  Radio,
  Award,
  Info,
} from "lucide-react";
import { FLOOD_HOTSPOTS } from "../data/floodHotspots";

export interface SubmittedReport {
  id: string;
  location: string;
  depth: string;
  roadClosed: boolean;
  description: string;
  timestamp: string;
  status: "Pending Field Validation" | "Verified by MCD Engineer";
  photoSample: string;
}

export default function ReportsPage() {
  const [location, setLocation] = useState<string>("Minto Bridge Railway Underpass");
  const [customStreet, setCustomStreet] = useState<string>("");
  const [waterDepth, setWaterDepth] = useState<string>("2 to 3 feet (Car axle submerged)");
  const [isPassable, setIsPassable] = useState<boolean>(false);
  const [description, setDescription] = useState<string>(
    "Underpass drain choked with silt. Water level rising fast; 2 cars stalled under bridge. Traffic backing up towards Connaught Place."
  );
  const [selectedPhoto, setSelectedPhoto] = useState<string>("minto_waterlogged.jpg");
  const [submittedReports, setSubmittedReports] = useState<SubmittedReport[]>([
    {
      id: "DEL-2026-8941",
      location: "Minto Bridge Railway Underpass",
      depth: "3+ feet (Fully impassable)",
      roadClosed: true,
      description: "Severe waterlogging near Shivaji Bridge rail cut. Water depth past knee level.",
      timestamp: "12 mins ago",
      status: "Verified by MCD Engineer",
      photoSample: "minto_waterlogged.jpg",
    },
    {
      id: "DEL-2026-8924",
      location: "ITO Junction / Vikas Marg",
      depth: "1.5 feet (Slow crawl)",
      roadClosed: false,
      description: "Water stagnation in left two lanes towards Laxmi Nagar.",
      timestamp: "45 mins ago",
      status: "Pending Field Validation",
      photoSample: "ito_crossing.jpg",
    },
    {
      id: "DEL-2026-8890",
      location: "Tilak Bridge Underpass",
      depth: "2 feet (Moderate stagnation)",
      roadClosed: false,
      description: "Debris accumulating in stormwater drain grating along railway retaining wall.",
      timestamp: "2 hours ago",
      status: "Verified by MCD Engineer",
      photoSample: "tilak_inundation.jpg",
    },
  ]);
  const [hasJustSubmitted, setHasJustSubmitted] = useState<boolean>(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const resolvedLoc = customStreet.trim() ? customStreet.trim() : location;
    const newReport: SubmittedReport = {
      id: `DEL-2026-${Math.floor(1000 + Math.random() * 9000)}`,
      location: resolvedLoc,
      depth: waterDepth,
      roadClosed: !isPassable,
      description: description.trim() || "Water accumulation observed by resident.",
      timestamp: "Just now",
      status: "Pending Field Validation",
      photoSample: selectedPhoto,
    };

    setSubmittedReports([newReport, ...submittedReports]);
    setHasJustSubmitted(true);
    setTimeout(() => setHasJustSubmitted(false), 3500);
  };

  return (
    <div className="relative w-full h-full min-h-screen bg-[#080b10] text-slate-100 flex flex-col justify-between overflow-x-hidden overflow-y-auto font-sans select-none">
      {/* Background Matrix & Subtle Ambient Glow */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div
          className="absolute inset-0 opacity-[0.05]"
          style={{
            backgroundImage: `radial-gradient(circle at 1px 1px, #06b6d4 1px, transparent 0)`,
            backgroundSize: "32px 32px",
          }}
        />
        <div className="absolute -top-32 left-1/4 w-[600px] h-[600px] bg-cyan-600/[0.06] rounded-full blur-[140px]" />
        <div className="absolute top-1/2 -right-32 w-[600px] h-[600px] bg-amber-500/[0.04] rounded-full blur-[150px]" />
      </div>

      {/* Top Header Navigation */}
      <header className="relative z-10 w-full px-4 sm:px-6 lg:px-10 py-3.5 border-b border-[#182333]/80 bg-[#090c10]/85 backdrop-blur-md flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded bg-[#131c2a] border border-[#24354d] flex items-center justify-center text-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.25)]">
            <Users className="w-4 h-4" />
          </div>
          <div>
            <div className="font-mono font-black text-sm tracking-tight text-white flex items-center gap-1.5">
              <span>ROADRISK DELHI</span>
              <span className="text-[10px] text-amber-300 px-1.5 py-0.2 rounded bg-amber-950/80 border border-amber-800/60 font-semibold tracking-wider">
                RESIDENT REPORTING (MOCKUP)
              </span>
            </div>
            <div className="text-[10px] font-mono text-slate-500 uppercase tracking-widest hidden sm:block">
              Crowdsourced citizen reporting channel for MCD / PWD monsoon response
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <Link
            to="/"
            className="px-2.5 py-1.5 rounded bg-[#131c2a] hover:bg-[#1c2738] border border-[#23354d] text-slate-300 hover:text-white font-mono text-xs flex items-center gap-1.5 transition-colors cursor-pointer shadow-sm"
            title="Return to Home / Cover Page"
          >
            <Home className="w-3.5 h-3.5 text-cyan-400" />
            <span className="font-bold">HOME</span>
          </Link>

          <Link
            to="/dashboard"
            className="px-3 py-1.5 rounded bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs flex items-center gap-1.5 transition-colors shadow-sm cursor-pointer"
            title="Open Interactive Simulation Dashboard"
          >
            <Map className="w-3.5 h-3.5" />
            <span>DASHBOARD</span>
          </Link>

          <Link
            to="/live-feed"
            className="hidden md:flex px-2.5 py-1.5 rounded bg-[#131c2a] hover:bg-[#1c2738] border border-[#23354d] text-slate-300 hover:text-white font-mono text-xs items-center gap-1.5 transition-colors cursor-pointer"
            title="Open TinyFish Live Feed"
          >
            <Radio className="w-3.5 h-3.5 text-cyan-400" />
            <span>LIVE FEED</span>
          </Link>

          <Link
            to="/best-fixes"
            className="hidden md:flex px-2.5 py-1.5 rounded bg-[#131c2a] hover:bg-[#1c2738] border border-[#23354d] text-slate-300 hover:text-white font-mono text-xs items-center gap-1.5 transition-colors cursor-pointer"
            title="Open Best Fixes Optimizer"
          >
            <Award className="w-3.5 h-3.5 text-emerald-400" />
            <span>BEST FIXES</span>
          </Link>

          <Link
            to="/assumptions"
            className="hidden lg:flex px-2.5 py-1.5 rounded bg-[#131c2a] hover:bg-[#1c2738] border border-[#23354d] text-slate-300 hover:text-white font-mono text-xs items-center gap-1.5 transition-colors cursor-pointer"
            title="Open Model Assumptions"
          >
            <Info className="w-3.5 h-3.5 text-sky-400" />
            <span>ASSUMPTIONS</span>
          </Link>
        </div>
      </header>

      {/* Main Content Body */}
      <main className="relative z-10 flex-1 w-full max-w-4xl mx-auto px-4 sm:px-6 py-8 space-y-6 font-mono text-xs">
        {/* NOTICE: NOT CONNECTED TO SIMULATION */}
        <div className="p-3.5 rounded-xl bg-[#191209] border border-amber-600/70 text-amber-200 text-xs font-sans space-y-1.5 shadow-lg">
          <div className="flex items-center gap-2 font-bold font-mono text-amber-300 text-xs uppercase">
            <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0" />
            <span>CONCEPT MOCKUP &bull; NOT CONNECTED TO SIMULATION</span>
          </div>
          <p className="text-xs leading-relaxed text-amber-100/90">
            This intake interface is a design prototype illustrating how crowdsourced citizen hazard reports flow into municipal operations. Submissions here do <strong>not</strong> alter live simulation physics or topological link weights.
          </p>
        </div>

        {/* PROCESS DIAGRAM: reports → validation → feed back into inputs */}
        <div className="p-4 rounded-xl bg-[#0e1420] border border-[#1d293d] space-y-3 shadow-lg">
          <span className="text-[10px] font-bold uppercase tracking-wider text-cyan-400 flex items-center gap-1.5 font-mono">
            <Sparkles className="w-3.5 h-3.5 text-cyan-300" />
            <span>OPERATIONAL DATA PIPELINE DIAGRAM</span>
          </span>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-center pt-1 font-mono">
            {/* Step 1 */}
            <div className="p-3 rounded-lg bg-[#080d15] border border-[#1b2a40] space-y-1.5 relative">
              <div className="w-8 h-8 mx-auto rounded-full bg-[#182638] border border-cyan-500/50 flex items-center justify-center text-cyan-300">
                <Camera className="w-4 h-4" />
              </div>
              <div className="text-xs font-bold text-white">1. Citizen Reports</div>
              <div className="text-[10px] text-slate-400 font-sans leading-tight">
                Location, water depth &amp; photo tagged via mobile app
              </div>
            </div>

            {/* Step 2 */}
            <div className="p-3 rounded-lg bg-[#080d15] border border-[#1b2a40] space-y-1.5 relative">
              <div className="w-8 h-8 mx-auto rounded-full bg-[#182638] border border-amber-500/50 flex items-center justify-center text-amber-300">
                <FileCheck2 className="w-4 h-4" />
              </div>
              <div className="text-xs font-bold text-white">2. Validation Gate</div>
              <div className="text-[10px] text-amber-300/90 font-sans leading-tight font-medium">
                Verified by MCD/PWD engineers &amp; CCTV footage before use
              </div>
            </div>

            {/* Step 3 */}
            <div className="p-3 rounded-lg bg-[#080d15] border border-[#1b2a40] space-y-1.5">
              <div className="w-8 h-8 mx-auto rounded-full bg-[#182638] border border-emerald-500/50 flex items-center justify-center text-emerald-300">
                <RefreshCw className="w-4 h-4" />
              </div>
              <div className="text-xs font-bold text-white">3. Feed into Inputs</div>
              <div className="text-[10px] text-slate-400 font-sans leading-tight">
                Verified severances feed into road resilience cascade model
              </div>
            </div>
          </div>

          <div className="text-center text-xs text-cyan-300/90 font-mono pt-1">
            reports &rarr; validation &rarr; feed back into inputs
          </div>
        </div>

        {/* SUBMISSION FORM */}
        <form onSubmit={handleSubmit} className="p-5 rounded-xl bg-[#0e1420] border border-[#1c293d] space-y-4 shadow-xl">
          <div className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center justify-between border-b border-[#182334] pb-2.5">
            <span className="flex items-center gap-1.5">
              <Droplets className="w-4 h-4 text-cyan-400" />
              <span>SUBMIT WATERLOGGING OBSERVATION</span>
            </span>
            <span className="text-[10px] text-slate-500">Citizen Form</span>
          </div>

          {/* Location selector */}
          <div className="space-y-1.5">
            <label className="text-xs text-slate-300 font-bold uppercase flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-cyan-400" />
              <span>Incident Location (Central Delhi):</span>
            </label>
            <select
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              className="w-full bg-[#080c14] border border-[#23354c] text-white text-xs rounded-lg px-3 py-2 font-mono focus:outline-none focus:border-cyan-400 cursor-pointer"
            >
              {FLOOD_HOTSPOTS.map((h) => (
                <option key={h.id || h.name} value={h.name}>
                  {h.name}
                </option>
              ))}
              <option value="Custom Street / Intersection">-- Other Street / Colony Road --</option>
            </select>

            {location === "Custom Street / Intersection" && (
              <input
                type="text"
                placeholder="Enter street name, colony or intersection..."
                value={customStreet}
                onChange={(e) => setCustomStreet(e.target.value)}
                className="w-full mt-1.5 bg-[#080c14] border border-[#23354c] text-white text-xs rounded-lg px-3 py-2 font-sans focus:outline-none focus:border-cyan-400"
              />
            )}
          </div>

          {/* Estimated Water Depth & Passability */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <label className="text-xs text-slate-300 font-bold uppercase block">
                Observed Water Stagnation Depth:
              </label>
              <select
                value={waterDepth}
                onChange={(e) => setWaterDepth(e.target.value)}
                className="w-full bg-[#080c14] border border-[#23354c] text-white text-xs rounded-lg px-3 py-2 font-mono focus:outline-none focus:border-cyan-400 cursor-pointer"
              >
                <option value="6 to 12 inches (Curb overtopping)">6 to 12 inches (Curb overtopping)</option>
                <option value="1 to 2 feet (Knee level, small cars stuck)">1 to 2 feet (Knee level, small cars stuck)</option>
                <option value="2 to 3 feet (Car axle submerged)">2 to 3 feet (Car axle submerged)</option>
                <option value="3+ feet (Fully submerged / underpass blocked)">3+ feet (Fully submerged / underpass blocked)</option>
              </select>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs text-slate-300 font-bold uppercase block">
                Vehicular Passability:
              </label>
              <div className="grid grid-cols-2 gap-2 pt-0.5">
                <button
                  type="button"
                  onClick={() => setIsPassable(false)}
                  className={`py-2 px-3 rounded-lg text-xs font-bold border transition-colors cursor-pointer ${
                    !isPassable
                      ? "bg-rose-950 text-rose-200 border-rose-600 shadow-sm"
                      : "bg-[#080c14] border-[#1f2b3c] text-slate-400 hover:text-white"
                  }`}
                >
                  Impassable (Blocked)
                </button>
                <button
                  type="button"
                  onClick={() => setIsPassable(true)}
                  className={`py-2 px-3 rounded-lg text-xs font-bold border transition-colors cursor-pointer ${
                    isPassable
                      ? "bg-amber-950 text-amber-200 border-amber-600 shadow-sm"
                      : "bg-[#080c14] border-[#1f2b3c] text-slate-400 hover:text-white"
                  }`}
                >
                  Crawling / 1 Lane
                </button>
              </div>
            </div>
          </div>

          {/* Photo Placeholder Area */}
          <div className="space-y-1.5">
            <label className="text-xs text-slate-300 font-bold uppercase flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <ImageIcon className="w-3.5 h-3.5 text-cyan-400" />
                <span>Geotagged Photo Evidence (Placeholder):</span>
              </span>
              <span className="text-[10px] text-slate-500">EXIF Geolocation</span>
            </label>

            <div className="p-4 border-2 border-dashed border-[#23354d] hover:border-cyan-500/60 rounded-xl bg-[#080c14] text-center space-y-2 transition-colors cursor-pointer">
              <div className="w-10 h-10 mx-auto rounded-full bg-[#131d2b] flex items-center justify-center text-cyan-400">
                <Upload className="w-5 h-5" />
              </div>
              <div className="text-xs text-slate-300 font-sans">
                Drag &amp; drop waterlogging photo or <span className="text-cyan-400 underline">browse device</span>
              </div>
              <div className="text-[10px] text-slate-500">
                Simulated upload: attaches GPS timestamp and visual flood gauge stamp
              </div>

              {/* Simulated photo options */}
              <div className="flex flex-wrap justify-center gap-2 pt-1.5">
                {[
                  { id: "minto_waterlogged.jpg", label: "Minto Bridge RUB (3.2 ft)" },
                  { id: "ito_crossing.jpg", label: "ITO Radial Slipway" },
                  { id: "tilak_inundation.jpg", label: "Tilak Underpass" },
                ].map((p) => (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => setSelectedPhoto(p.id)}
                    className={`text-[10px] px-2.5 py-1 rounded-md border transition-colors cursor-pointer ${
                      selectedPhoto === p.id
                        ? "bg-cyan-950 text-cyan-200 border-cyan-500"
                        : "bg-[#101824] text-slate-400 border-[#1f2a3c] hover:text-slate-200"
                    }`}
                  >
                    {p.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Description */}
          <div className="space-y-1.5">
            <label className="text-xs text-slate-300 font-bold uppercase block">
              Field Description &amp; Public Safety Impact:
            </label>
            <textarea
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe water accumulation, stuck emergency vehicles, or choked stormwater drains..."
              className="w-full bg-[#080c14] border border-[#23354c] text-slate-200 text-xs rounded-lg p-3 font-sans focus:outline-none focus:border-cyan-400 resize-none leading-relaxed"
            />
          </div>

          {/* MANDATORY VALIDATED BEFORE USE NOTE */}
          <div className="p-3.5 rounded-lg bg-[#091512] border border-[#16382e] text-xs text-emerald-200 font-sans leading-relaxed flex items-start gap-2.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <strong>Validated before use:</strong> All resident reports are quarantined in a pending review queue and rigorously verified by municipal engineers via field inspection or traffic CCTV cameras before being fed back into inputs.
            </div>
          </div>

          {/* Submit Action Button */}
          <div className="pt-1">
            <button
              type="submit"
              className="w-full py-3 px-4 rounded-lg bg-gradient-to-r from-cyan-600 to-sky-600 hover:from-cyan-500 hover:to-sky-500 text-slate-950 font-mono font-bold text-xs flex items-center justify-center gap-2 cursor-pointer shadow-[0_0_20px_rgba(6,182,212,0.35)] transition-all"
            >
              <Upload className="w-4 h-4 text-slate-950" />
              <span className="uppercase tracking-wider">SUBMIT REPORT TO MCD QUEUE (MOCKUP)</span>
            </button>
          </div>

          {hasJustSubmitted && (
            <div className="p-2.5 rounded-lg bg-emerald-950 border border-emerald-500 text-emerald-200 text-xs text-center font-bold animate-pulse">
              ✓ Report logged into Mockup Intake Ledger (Status: Pending Field Validation)
            </div>
          )}
        </form>

        {/* RECENT SUBMISSIONS QUEUE */}
        <div className="space-y-2.5">
          <div className="flex items-center justify-between text-xs text-slate-400 uppercase font-bold">
            <span>RECENT COMMUNITY LOGS ({submittedReports.length})</span>
            <span className="text-cyan-400">Intake Ledger</span>
          </div>

          <div className="space-y-2">
            {submittedReports.map((item) => (
              <div
                key={item.id}
                className="p-3 rounded-lg bg-[#0a0f18] border border-[#182333] space-y-1.5 text-xs shadow-md"
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="font-bold text-white text-xs flex items-center gap-2">
                      <span className="text-cyan-400">{item.id}</span>
                      <span>&bull;</span>
                      <span className="truncate">{item.location}</span>
                    </div>
                    <div className="text-[10px] text-slate-400 mt-0.5 font-mono">
                      Depth: <strong className="text-amber-300">{item.depth}</strong> &bull; {item.timestamp}
                    </div>
                  </div>
                  <span
                    className={`text-[9px] px-2 py-0.5 rounded font-bold uppercase shrink-0 border ${
                      item.status === "Verified by MCD Engineer"
                        ? "bg-emerald-950 text-emerald-300 border-emerald-700"
                        : "bg-amber-950 text-amber-300 border-amber-700"
                    }`}
                  >
                    {item.status}
                  </span>
                </div>
                <p className="text-xs text-slate-300 font-sans leading-relaxed">
                  {item.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="relative z-10 w-full px-5 lg:px-10 py-4 border-t border-[#182333]/80 bg-[#06080d]/90 backdrop-blur-md flex flex-col sm:flex-row items-center justify-between text-[11px] font-mono text-slate-500 gap-2">
        <div className="flex items-center gap-2 text-center sm:text-left">
          <span>Illustrative simulation model. Data is synthetic or indicative. Team Pixel Pioneers</span>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-slate-400 font-bold">Team Pixel Pioneers</span>
          <span className="text-slate-600">&bull;</span>
          <span>Central Delhi Civic Resilience &bull; MCD Zone SP-City</span>
        </div>
      </footer>
    </div>
  );
}
