import React from "react";
import { Link, useNavigate } from "react-router-dom";
import {
  Activity,
  Home,
  MapPin,
  Radio,
  RotateCcw,
  Sparkles,
  CheckCircle2,
  Droplets,
  Navigation,
  ExternalLink,
  Info,
  ArrowRight,
  Map,
  Award,
  Users,
  Scan,
} from "lucide-react";
import { useAppState } from "../context/AppStateContext";

export default function LiveFeedPage() {
  const navigate = useNavigate();
  const {
    currentZone,
    liveFeed,
    isLiveFeedLoading,
    fetchLiveFeed,
    useLiveTinyFish,
    setUseLiveTinyFish,
  } = useAppState();

  return (
    <div className="relative w-full h-full min-h-screen bg-[#080b10] text-slate-100 flex flex-col justify-between overflow-x-hidden overflow-y-auto font-sans select-none">
      {/* Background Matrix & Atmospheric Glows */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div
          className="absolute inset-0 opacity-[0.05]"
          style={{
            backgroundImage: `radial-gradient(circle at 1px 1px, #38bdf8 1px, transparent 0)`,
            backgroundSize: "32px 32px",
          }}
        />
        <div className="absolute -top-32 left-1/4 w-[600px] h-[600px] bg-cyan-500/[0.08] rounded-full blur-[140px]" />
        <div className="absolute top-1/2 -right-32 w-[600px] h-[600px] bg-sky-600/[0.06] rounded-full blur-[150px]" />
      </div>

      {/* Top Header Navigation */}
      <header className="relative z-10 w-full px-5 lg:px-10 py-4 border-b border-[#182333]/80 bg-[#090c10]/80 backdrop-blur-md flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded bg-[#131c2a] border border-[#24354d] flex items-center justify-center text-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.25)]">
            <Radio className="w-4 h-4 animate-pulse" />
          </div>
          <div>
            <div className="font-mono font-black text-sm tracking-tight text-white flex items-center gap-1.5">
              <span>ROADRISK DELHI</span>
              <span className="text-[10px] text-cyan-400 px-1.5 py-0.2 rounded bg-cyan-950/80 border border-cyan-800/60 font-semibold tracking-wider">
                {currentZone.isDefault ? "CENTRAL ZONE" : currentZone.name.toUpperCase()}
              </span>
            </div>
            <div className="text-[10px] font-mono text-slate-500 uppercase tracking-widest hidden sm:block">
              TinyFish Live Monsoon Flood Intelligence &amp; Traffic Advisory Ingestion
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <Link
            to="/"
            className="px-2.5 py-1.5 rounded bg-[#131c2a] hover:bg-[#1c2738] border border-[#23354d] text-slate-300 hover:text-white font-mono text-xs flex items-center gap-1.5 transition-colors cursor-pointer shadow-sm"
            title="Return to Home / Cover Page"
          >
            <Home className="w-3.5 h-3.5 text-cyan-400" />
            <span className="font-bold">HOME</span>
          </Link>

          <Link
            to="/dashboard"
            className="px-3 py-1.5 rounded bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs flex items-center gap-1.5 transition-colors shadow-sm cursor-pointer"
            title="Open Interactive Simulation Dashboard"
          >
            <Map className="w-3.5 h-3.5" />
            <span>DASHBOARD</span>
          </Link>

          <Link
            to="/select-area"
            className="hidden sm:flex px-2.5 py-1.5 rounded bg-[#131c2a] hover:bg-[#1c2738] border border-[#23354d] text-slate-300 hover:text-white font-mono text-xs items-center gap-1.5 transition-colors cursor-pointer"
            title="Select or draw custom analysis zone"
          >
            <Scan className="w-3.5 h-3.5 text-amber-400" />
            <span>AREA</span>
          </Link>

          <Link
            to="/best-fixes"
            className="hidden md:flex px-2.5 py-1.5 rounded bg-[#131c2a] hover:bg-[#1c2738] border border-[#23354d] text-slate-300 hover:text-white font-mono text-xs items-center gap-1.5 transition-colors cursor-pointer"
            title="Open Best Fixes Optimizer"
          >
            <Award className="w-3.5 h-3.5 text-emerald-400" />
            <span>BEST FIXES</span>
          </Link>

          <Link
            to="/reports"
            className="hidden lg:flex px-2.5 py-1.5 rounded bg-[#131c2a] hover:bg-[#1c2738] border border-[#23354d] text-slate-300 hover:text-white font-mono text-xs items-center gap-1.5 transition-colors cursor-pointer"
            title="Open Resident Reporting"
          >
            <Users className="w-3.5 h-3.5 text-amber-400" />
            <span>REPORTS</span>
          </Link>

          <Link
            to="/assumptions"
            className="hidden lg:flex px-2.5 py-1.5 rounded bg-[#131c2a] hover:bg-[#1c2738] border border-[#23354d] text-slate-300 hover:text-white font-mono text-xs items-center gap-1.5 transition-colors cursor-pointer"
            title="Open Model Assumptions"
          >
            <Info className="w-3.5 h-3.5 text-sky-400" />
            <span>ASSUMPTIONS</span>
          </Link>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="relative z-10 flex-1 w-full max-w-4xl mx-auto px-4 sm:px-6 py-8 space-y-5 font-mono text-xs">
        {/* Header Title Card */}
        <div className="p-4 sm:p-5 rounded-xl bg-[#0e1420] border border-[#1e2a3f] shadow-xl space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 border-b border-[#1b2536] pb-3">
            <div className="space-y-0.5">
              <div className="flex items-center gap-2">
                <Radio className="w-4 h-4 text-cyan-400 animate-pulse" />
                <h1 className="text-base sm:text-lg font-bold text-white uppercase tracking-wider">
                  TINYFISH LIVE MONSOON FEED
                </h1>
              </div>
              <p className="text-xs text-slate-400 font-sans">
                Automated live web scraping and advisory parsing for {currentZone.name}
              </p>
            </div>

            <div className="flex items-center gap-2 self-start sm:self-auto">
              {/* Mode Badge (LIVE / CACHED) */}
              <span
                className={`text-[10px] px-2.5 py-1 rounded font-bold uppercase tracking-wider border flex items-center gap-1.5 ${
                  liveFeed?.mode === "live"
                    ? "bg-emerald-950 text-emerald-300 border-emerald-600 shadow-[0_0_12px_rgba(16,185,129,0.3)]"
                    : "bg-amber-950 text-amber-300 border-amber-600"
                }`}
              >
                <span
                  className={`w-2 h-2 rounded-full ${
                    liveFeed?.mode === "live" ? "bg-emerald-400 animate-ping" : "bg-amber-400"
                  }`}
                />
                <span>{liveFeed?.mode === "live" ? "LIVE DATA" : "CACHED SNAPSHOT"}</span>
              </span>

              <button
                type="button"
                onClick={() => fetchLiveFeed(true)}
                disabled={isLiveFeedLoading}
                title="Refresh TinyFish live intelligence"
                className="px-2.5 py-1 rounded bg-[#151f2e] hover:bg-[#1d2c42] border border-[#23354d] text-cyan-300 cursor-pointer disabled:opacity-50 transition-colors flex items-center gap-1.5 font-bold"
              >
                <RotateCcw className={`w-3.5 h-3.5 ${isLiveFeedLoading ? "animate-spin" : ""}`} />
                <span className="hidden sm:inline">REFRESH</span>
              </button>
            </div>
          </div>

          {/* Required Pipeline Summary Line */}
          <div className="p-3 rounded-lg bg-[#090d15] border border-[#1a2538] text-xs font-mono text-cyan-300 leading-relaxed flex items-center gap-2">
            <span className="text-cyan-400 font-bold shrink-0">Pipeline:</span>
            <span>
              Search finds news &rarr; Fetch reads pages &rarr; matches become flooded roads &rarr; cascade and hospital impact update
            </span>
          </div>

          <div className="flex flex-col sm:flex-row sm:items-center justify-between text-[10.5px] text-slate-400 pt-1 gap-1">
            <span>
              Fetch Timestamp:{" "}
              <strong className="text-slate-200 font-mono">
                {liveFeed?.fetchedAt ? new Date(liveFeed.fetchedAt).toLocaleString() : "Recent"}
              </strong>
            </span>
            <span className="text-slate-500 font-mono">10-min cache per area</span>
          </div>
        </div>

        {/* TOGGLE CARD: USE LIVE TINYFISH CONDITIONS */}
        <div
          className={`p-4 sm:p-5 rounded-xl border transition-all ${
            useLiveTinyFish
              ? "bg-cyan-950/60 border-cyan-400 shadow-[0_0_25px_rgba(6,182,212,0.25)]"
              : "bg-[#0f1420] border-[#1d2a3f]"
          }`}
        >
          <div className="flex items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="text-sm font-bold text-white flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-cyan-400" />
                <span>Use live TinyFish conditions</span>
              </div>
              <p className="text-xs text-slate-300 font-sans leading-relaxed max-w-xl">
                When enabled, matched hotspots and closed road corridors from live news reports are written to the shared scenario, automatically updating the cascade simulation and hospital accessibility calculations.
              </p>
            </div>

            <button
              type="button"
              onClick={() => setUseLiveTinyFish(!useLiveTinyFish)}
              className={`w-14 h-7 rounded-full transition-colors relative cursor-pointer shrink-0 border ${
                useLiveTinyFish
                  ? "bg-cyan-500 border-cyan-300 shadow-[0_0_15px_rgba(6,182,212,0.7)]"
                  : "bg-[#182333] border-[#293c56]"
              }`}
              aria-pressed={useLiveTinyFish}
            >
              <span
                className={`block w-5 h-5 rounded-full bg-white transition-transform ${
                  useLiveTinyFish ? "translate-x-7" : "translate-x-1"
                }`}
              />
            </button>
          </div>

          {/* Active status and "View impact on map" button */}
          {useLiveTinyFish && (
            <div className="mt-4 pt-3.5 border-t border-cyan-800/60 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <span className="text-emerald-300 font-bold flex items-center gap-2 text-xs">
                <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                <span>
                  Live conditions active: {liveFeed?.matches?.length || 0} hotspots flooded &amp;{" "}
                  {liveFeed?.matchedRoads?.length || 0} roads closed
                </span>
              </span>

              {/* View impact on map button */}
              <button
                type="button"
                onClick={() => navigate("/dashboard")}
                className="px-4 py-2 rounded-lg bg-gradient-to-r from-cyan-600 to-sky-600 hover:from-cyan-500 hover:to-sky-500 text-slate-950 font-mono font-black text-xs flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(6,182,212,0.4)] transition-all cursor-pointer self-start sm:self-auto"
              >
                <span>View impact on map</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
        </div>

        {/* MATCHED HOTSPOTS FROM LIVE NEWS */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
              <Droplets className="w-4 h-4 text-cyan-400" />
              <span>MATCHED HOTSPOTS FROM LIVE NEWS ({liveFeed?.matches.length || 0})</span>
            </span>
            <span className="text-[10px] text-cyan-400 font-mono">
              {liveFeed?.areaName || currentZone.name}
            </span>
          </div>

          {liveFeed?.matches && liveFeed.matches.length > 0 ? (
            <div className="space-y-3">
              {liveFeed.matches.map((match, idx) => (
                <div
                  key={match.hotspotName || idx}
                  className={`p-4 rounded-lg border space-y-2.5 transition-all ${
                    useLiveTinyFish
                      ? "bg-[#13111d] border-rose-600/80 shadow-[0_0_15px_rgba(244,63,94,0.15)]"
                      : "bg-[#0d121c] border-[#1b263a]"
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span
                        className={`w-2.5 h-2.5 rounded-full ${
                          useLiveTinyFish ? "bg-rose-500 animate-ping" : "bg-cyan-400"
                        }`}
                      />
                      <span className="font-bold text-white text-sm">{match.hotspotName}</span>
                    </div>
                    <span
                      className={`text-[9.5px] px-2 py-0.5 rounded font-bold uppercase shrink-0 border ${
                        useLiveTinyFish
                          ? "bg-rose-950 text-rose-300 border-rose-700"
                          : "bg-cyan-950 text-cyan-300 border-cyan-800"
                      }`}
                    >
                      {useLiveTinyFish ? "FLOODED UNDER LIVE FEED" : "NEWS MATCH"}
                    </span>
                  </div>

                  {/* Snippet */}
                  {match.snippet && (
                    <div className="p-2.5 rounded bg-[#070910] border border-[#172030] text-xs text-slate-300 italic font-serif leading-relaxed">
                      &ldquo;{match.snippet}&rdquo;
                    </div>
                  )}

                  {/* Sources */}
                  {match.sources && match.sources.length > 0 && (
                    <div className="space-y-1 pt-1.5 border-t border-[#182335]">
                      <span className="text-[9.5px] font-bold text-slate-500 uppercase block">
                        Source News Reports:
                      </span>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                        {match.sources.map((src, sIdx) => (
                          <a
                            key={src.url || sIdx}
                            href={src.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center justify-between p-2 rounded bg-[#0a0f18] hover:bg-[#121c2e] border border-[#1a2638] text-[11px] text-cyan-300 hover:text-white transition-colors group cursor-pointer"
                          >
                            <span className="truncate pr-2 font-sans font-medium">
                              {src.title || "Read Article"}
                            </span>
                            <ExternalLink className="w-3.5 h-3.5 text-slate-500 group-hover:text-cyan-300 shrink-0" />
                          </a>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <div className="p-5 rounded-lg bg-[#0d121c] border border-[#1b2538] text-center text-xs text-slate-400 space-y-1.5">
              <Info className="w-5 h-5 text-slate-500 mx-auto" />
              <div className="font-semibold text-slate-300">No flood hotspots currently matched in live news.</div>
              <div className="text-[11px] text-slate-500">
                Hotspots are scanned against verified municipal waterlogging registries.
              </div>
            </div>
          )}
        </div>

        {/* MATCHED ROADS FROM LIVE ADVISORIES */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
              <Navigation className="w-4 h-4 text-amber-400" />
              <span>MATCHED ROAD CLOSURES FROM TRAFFIC ADVISORIES ({liveFeed?.matchedRoads?.length || 0})</span>
            </span>
            <span className="text-[10px] text-amber-400 font-mono">OpenStreetMap Corridors</span>
          </div>

          {liveFeed?.matchedRoads && liveFeed.matchedRoads.length > 0 ? (
            <div className="space-y-3">
              {liveFeed.matchedRoads.map((roadMatch, idx) => (
                <div
                  key={roadMatch.roadName || idx}
                  className={`p-4 rounded-lg border space-y-2.5 transition-all ${
                    useLiveTinyFish
                      ? "bg-[#181116] border-amber-600/80 shadow-[0_0_15px_rgba(245,158,11,0.15)]"
                      : "bg-[#0d121c] border-[#1b263a]"
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span
                        className={`w-2.5 h-2.5 rounded-full ${
                          useLiveTinyFish ? "bg-amber-400 animate-ping" : "bg-cyan-400"
                        }`}
                      />
                      <span className="font-bold text-white text-sm">{roadMatch.roadName}</span>
                    </div>
                    <span
                      className={`text-[9.5px] px-2 py-0.5 rounded font-bold uppercase shrink-0 border ${
                        useLiveTinyFish
                          ? "bg-amber-950 text-amber-300 border-amber-700"
                          : "bg-cyan-950 text-cyan-300 border-cyan-800"
                      }`}
                    >
                      {useLiveTinyFish ? "CLOSED UNDER LIVE FEED" : "ADVISORY MATCH"}
                    </span>
                  </div>

                  {/* Snippet */}
                  {roadMatch.snippet && (
                    <div className="p-2.5 rounded bg-[#070910] border border-[#172030] text-xs text-slate-300 italic font-serif leading-relaxed">
                      &ldquo;{roadMatch.snippet}&rdquo;
                    </div>
                  )}

                  {/* Sources */}
                  {roadMatch.sources && roadMatch.sources.length > 0 && (
                    <div className="space-y-1 pt-1.5 border-t border-[#182335]">
                      <span className="text-[9.5px] font-bold text-slate-500 uppercase block">
                        Source Police / News Advisories:
                      </span>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                        {roadMatch.sources.map((src, sIdx) => (
                          <a
                            key={src.url || sIdx}
                            href={src.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center justify-between p-2 rounded bg-[#0a0f18] hover:bg-[#121c2e] border border-[#1a2638] text-[11px] text-cyan-300 hover:text-white transition-colors group cursor-pointer"
                          >
                            <span className="truncate pr-2 font-sans font-medium">
                              {src.title || "Read Advisory"}
                            </span>
                            <ExternalLink className="w-3.5 h-3.5 text-slate-500 group-hover:text-cyan-300 shrink-0" />
                          </a>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <div className="p-5 rounded-lg bg-[#0d121c] border border-[#1b2538] text-center text-xs text-slate-400 space-y-1.5">
              <Info className="w-5 h-5 text-slate-500 mx-auto" />
              <div className="font-semibold text-slate-300">No road closures identified in news advisories for this area.</div>
              <div className="text-[11px] text-slate-500">
                Corridors are matched case-insensitively against the loaded OpenStreetMap network.
              </div>
            </div>
          )}
        </div>

        {/* API KEY CONFIGURATION NOTICE */}
        <div className="p-4 rounded-xl bg-[#0b0e16] border border-[#192436] space-y-2 text-xs">
          <div className="flex items-center gap-2 text-amber-300 font-bold uppercase tracking-wider text-[11px]">
            <Info className="w-4 h-4 text-amber-400" />
            <span>API KEY CONFIGURATION</span>
          </div>
          <p className="text-slate-300 font-sans leading-relaxed">
            Add <code className="text-cyan-300 font-mono bg-[#111824] px-1.5 py-0.5 rounded border border-[#1f2b3e]">TINYFISH_API_KEY</code> in the <strong>Secrets panel</strong> (in AI Studio UI) or in <code className="text-cyan-300 font-mono bg-[#111824] px-1.5 py-0.5 rounded border border-[#1f2b3e]">.env.local</code> for local development.
          </p>
          <div className="text-[11px] text-slate-500">
            When unset or during API rate limits, the app seamlessly serves the realistic bundled snapshot.
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="relative z-10 w-full px-5 lg:px-10 py-4 border-t border-[#182333]/80 bg-[#06080d]/90 backdrop-blur-md flex flex-col sm:flex-row items-center justify-between text-[11px] font-mono text-slate-500 gap-2">
        <div className="flex items-center gap-2 text-center sm:text-left">
          <span>Illustrative simulation model. Data is synthetic or indicative. Team Pixel Pioneers</span>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-slate-400 font-bold">Team Pixel Pioneers</span>
          <span className="text-slate-600">&bull;</span>
          <span>Central Delhi Urban Resilience Lab</span>
        </div>
      </footer>
    </div>
  );
}
