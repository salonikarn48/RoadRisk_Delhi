import React, { useState, useMemo, useRef, useCallback, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import {
  MapContainer,
  TileLayer,
  Rectangle,
  Tooltip,
  useMap,
} from "react-leaflet";
import L from "leaflet";
import {
  Activity,
  Home,
  Map as MapIcon,
  Search,
  Scan,
  Square,
  Maximize2,
  Check,
  AlertTriangle,
  Play,
  RotateCcw,
  RefreshCw,
  AlertOctagon,
  Sparkles,
} from "lucide-react";
import LocationSearch from "../components/LocationSearch";
import { calculateAreaKm2 } from "../utils/geo";
import { useAppState, DEFAULT_CENTRAL_DELHI_ZONE } from "../context/AppStateContext";

function MapViewController({ center, zoom }: { center: [number, number]; zoom: number }) {
  const map = useMap();
  useEffect(() => {
    map.setView(center, zoom);
  }, [center, zoom, map]);
  return null;
}

function MapInvalidator() {
  const map = useMap();

  useEffect(() => {
    if (!map) return;

    // Call after map mounts with 200ms delay
    const timer = setTimeout(() => {
      map.invalidateSize();
    }, 200);

    // Call on window resize
    const handleResize = () => {
      map.invalidateSize();
    };
    window.addEventListener("resize", handleResize);

    return () => {
      clearTimeout(timer);
      window.removeEventListener("resize", handleResize);
    };
  }, [map]);

  return null;
}

function MapFlyHandler({
  target,
  onTargetConsumed,
}: {
  target: { center?: [number, number]; zoom?: number; bounds?: [[number, number], [number, number]] } | null;
  onTargetConsumed: () => void;
}) {
  const map = useMap();
  useEffect(() => {
    if (!target || !map) return;
    if (target.bounds) {
      map.fitBounds(target.bounds, { padding: [50, 50], maxZoom: 15, animate: true });
    } else if (target.center) {
      map.flyTo(target.center, target.zoom || 14, { duration: 1.2 });
    }
    onTargetConsumed();
  }, [target, map, onTargetConsumed]);
  return null;
}

function MapBoundsExtractor({ onRegisterExtract }: { onRegisterExtract: (fn: () => [[number, number], [number, number]]) => void }) {
  const map = useMap();
  useEffect(() => {
    onRegisterExtract(() => {
      const b = map.getBounds();
      return [
        [b.getSouth(), b.getWest()],
        [b.getNorth(), b.getEast()],
      ];
    });
  }, [map, onRegisterExtract]);
  return null;
}

function MapAreaDrawInteraction({
  isDrawingMode,
  onBoundsChange,
  onDrawingComplete,
}: {
  isDrawingMode: boolean;
  onBoundsChange: (bounds: [[number, number], [number, number]]) => void;
  onDrawingComplete: () => void;
}) {
  const map = useMap();
  const [dragStart, setDragStart] = useState<L.LatLng | null>(null);
  const [currentDrag, setCurrentDrag] = useState<L.LatLng | null>(null);

  useEffect(() => {
    if (!map) return;
    if (isDrawingMode) {
      map.dragging.disable();
      map.touchZoom.disable();
      map.doubleClickZoom.disable();
      map.scrollWheelZoom.disable();
      map.boxZoom.disable();
      map.getContainer().style.cursor = "crosshair";
    } else {
      map.dragging.enable();
      map.touchZoom.enable();
      map.doubleClickZoom.enable();
      map.scrollWheelZoom.enable();
      map.boxZoom.enable();
      map.getContainer().style.cursor = "";
      setDragStart(null);
      setCurrentDrag(null);
    }
  }, [isDrawingMode, map]);

  useEffect(() => {
    if (!map || !isDrawingMode) return;

    const onMouseDown = (e: L.LeafletMouseEvent) => {
      setDragStart(e.latlng);
      setCurrentDrag(e.latlng);
    };

    const onMouseMove = (e: L.LeafletMouseEvent) => {
      if (dragStart) {
        setCurrentDrag(e.latlng);
      }
    };

    const onMouseUp = (e: L.LeafletMouseEvent) => {
      if (dragStart) {
        const p1 = dragStart;
        const p2 = e.latlng;
        const south = Math.min(p1.lat, p2.lat);
        const north = Math.max(p1.lat, p2.lat);
        const west = Math.min(p1.lng, p2.lng);
        const east = Math.max(p1.lng, p2.lng);

        if (Math.abs(north - south) > 0.001 && Math.abs(east - west) > 0.001) {
          onBoundsChange([[south, west], [north, east]]);
          onDrawingComplete();
        }
        setDragStart(null);
        setCurrentDrag(null);
      }
    };

    map.on("mousedown", onMouseDown);
    map.on("mousemove", onMouseMove);
    map.on("mouseup", onMouseUp);

    return () => {
      map.off("mousedown", onMouseDown);
      map.off("mousemove", onMouseMove);
      map.off("mouseup", onMouseUp);
    };
  }, [map, isDrawingMode, dragStart, onBoundsChange, onDrawingComplete]);

  if (isDrawingMode && dragStart && currentDrag) {
    const s = Math.min(dragStart.lat, currentDrag.lat);
    const n = Math.max(dragStart.lat, currentDrag.lat);
    const w = Math.min(dragStart.lng, currentDrag.lng);
    const e = Math.max(dragStart.lng, currentDrag.lng);

    return (
      <Rectangle
        bounds={[[s, w], [n, e]]}
        pathOptions={{
          color: "#f59e0b",
          weight: 2,
          dashArray: "6 4",
          fillColor: "#f59e0b",
          fillOpacity: 0.25,
        }}
      />
    );
  }

  return null;
}

export default function SelectAreaPage() {
  const navigate = useNavigate();
  const {
    currentZone,
    loading,
    loadingMessage,
    fetchError,
    handleRunAnalysisArea,
    loadZoneData,
  } = useAppState();

  const [selectedAreaBounds, setSelectedAreaBounds] = useState<[[number, number], [number, number]] | null>([
    [currentZone.south, currentZone.west],
    [currentZone.north, currentZone.east],
  ]);
  const [isDrawingRectangle, setIsDrawingRectangle] = useState<boolean>(false);
  const [mapKey] = useState<string>(() => `select-area-map-${Date.now()}`);
  const [flyTarget, setFlyTarget] = useState<{
    center?: [number, number];
    zoom?: number;
    bounds?: [[number, number], [number, number]];
  } | null>(null);

  const extractBoundsRef = useRef<(() => [[number, number], [number, number]]) | null>(null);

  const selectedAreaKm2 = useMemo(() => {
    if (!selectedAreaBounds) return 0;
    return calculateAreaKm2(selectedAreaBounds);
  }, [selectedAreaBounds]);

  const isAreaTooLarge = selectedAreaKm2 > 25.0;
  const isAreaTooSmall = selectedAreaKm2 > 0 && selectedAreaKm2 < 0.3;
  const isAreaValid = Boolean(selectedAreaBounds && !isAreaTooLarge && !isAreaTooSmall);

  // Handle Location Search selection
  const handleLocationSelect = useCallback(
    (lat: number, lon: number, name: string, bbox?: [number, number, number, number]) => {
      if (bbox) {
        const bounds: [[number, number], [number, number]] = [[bbox[0], bbox[1]], [bbox[2], bbox[3]]];
        setFlyTarget({ bounds });
        setSelectedAreaBounds(bounds);
      } else {
        setFlyTarget({ center: [lat, lon], zoom: 14 });
      }
    },
    []
  );

  // Handle "Use current view"
  const handleUseCurrentView = useCallback(() => {
    if (extractBoundsRef.current) {
      const b = extractBoundsRef.current();
      setSelectedAreaBounds(b);
      setIsDrawingRectangle(false);
    }
  }, []);

  // Handle "Use default Central Delhi zone"
  const handleUseDefaultZone = useCallback(async () => {
    setSelectedAreaBounds([
      [DEFAULT_CENTRAL_DELHI_ZONE.south, DEFAULT_CENTRAL_DELHI_ZONE.west],
      [DEFAULT_CENTRAL_DELHI_ZONE.north, DEFAULT_CENTRAL_DELHI_ZONE.east],
    ]);
    await loadZoneData(DEFAULT_CENTRAL_DELHI_ZONE, false);
    navigate("/dashboard");
  }, [loadZoneData, navigate]);

  // Handle "Run analysis on this area"
  const handleRunAnalysis = useCallback(async () => {
    if (!selectedAreaBounds || !isAreaValid) return;
    try {
      const ok = await handleRunAnalysisArea(selectedAreaBounds);
      if (ok) {
        navigate("/dashboard");
      }
    } catch (err: any) {
      console.info("Area analysis error:", err?.message || err);
    }
  }, [selectedAreaBounds, isAreaValid, handleRunAnalysisArea, navigate]);

  return (
    <div className="relative w-full min-h-screen bg-[#080b10] text-slate-100 flex flex-col font-sans select-none">
      {/* Top Header Navigation */}
      <header className="h-[72px] bg-[#0a0d14] border-b border-[#182333] px-3 lg:px-5 flex items-center justify-between shrink-0 z-30 select-none">
        <div className="flex items-center gap-3 min-w-0">
          <Link
            to="/"
            className="px-2.5 py-1.5 rounded bg-[#131c2a] hover:bg-[#1c2738] border border-[#23354d] text-slate-300 hover:text-white font-mono text-xs flex items-center gap-1.5 transition-colors cursor-pointer shadow-sm"
            title="Return to Cover Page"
          >
            <Home className="w-3.5 h-3.5 text-cyan-400" />
            <span className="font-bold">HOME</span>
          </Link>

          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded bg-[#131c2a] border border-[#24354d] flex items-center justify-center text-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.25)]">
              <Scan className="w-4 h-4" />
            </div>
            <div>
              <span className="font-mono font-black text-sm tracking-tight text-white flex items-center gap-1.5">
                <span>ROADRISK DELHI</span>
                <span className="text-[10px] text-cyan-400 px-1.5 py-0.2 rounded bg-cyan-950/80 border border-cyan-800/60 font-semibold tracking-wider">
                  SELECT AREA
                </span>
              </span>
              <span className="text-[10px] font-mono text-slate-400 uppercase tracking-widest hidden xl:block">
                Choose or draw a custom bounding box (0.3 km² – 25 km²) to run risk screening
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <button
            type="button"
            onClick={handleUseDefaultZone}
            disabled={loading}
            className="px-3 py-1.5 rounded bg-[#132030] hover:bg-[#1b2b40] border border-cyan-500/50 text-cyan-300 font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer shadow-sm"
            title="Quickly switch to default Central Delhi zone and open Dashboard"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">USE DEFAULT CENTRAL DELHI</span>
            <span className="sm:hidden">CENTRAL DELHI</span>
          </button>

          <Link
            to="/dashboard"
            className="px-3 py-1.5 rounded bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs flex items-center gap-1.5 transition-colors shadow-sm cursor-pointer"
            title="Open Interactive Simulation Dashboard"
          >
            <MapIcon className="w-3.5 h-3.5" />
            <span>DASHBOARD</span>
          </Link>
        </div>
      </header>

      {/* Full-Screen Map Container with Explicit Real Dimensions */}
      <div
        className="relative w-full overflow-hidden bg-slate-950"
        style={{ position: "relative", width: "100%", height: "calc(100vh - 72px)" }}
      >
        <MapContainer
          key={mapKey}
          center={currentZone.center}
          zoom={14}
          style={{ position: "relative", width: "100%", height: "100%", background: "#090c10" }}
          zoomControl={true}
        >
          <MapInvalidator />
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />
          <MapViewController center={currentZone.center} zoom={14} />
          <MapFlyHandler target={flyTarget} onTargetConsumed={() => setFlyTarget(null)} />
          <MapBoundsExtractor onRegisterExtract={(fn) => { extractBoundsRef.current = fn; }} />
          <MapAreaDrawInteraction
            isDrawingMode={isDrawingRectangle}
            onBoundsChange={(b) => setSelectedAreaBounds(b)}
            onDrawingComplete={() => setIsDrawingRectangle(false)}
          />

          {/* Current Active Zone (Dashed Cyan) */}
          <Rectangle
            bounds={[
              [currentZone.south, currentZone.west],
              [currentZone.north, currentZone.east],
            ]}
            pathOptions={{
              color: "#06b6d4",
              weight: 2,
              dashArray: "4 4",
              fillColor: "#06b6d4",
              fillOpacity: 0.04,
            }}
            interactive={false}
          />

          {/* Selected Area Highlighted Rectangle */}
          {selectedAreaBounds && (
            <Rectangle
              bounds={selectedAreaBounds}
              pathOptions={{
                color: isAreaTooLarge || isAreaTooSmall ? "#f43f5e" : "#f59e0b",
                weight: 2.5,
                dashArray: "6 4",
                fillColor: isAreaTooLarge || isAreaTooSmall ? "#f43f5e" : "#f59e0b",
                fillOpacity: 0.22,
              }}
            >
              <Tooltip permanent direction="center">
                <div className="font-mono text-xs font-bold text-slate-900 px-2.5 py-1 rounded bg-white shadow-xl border border-slate-300">
                  {selectedAreaKm2} km²
                </div>
              </Tooltip>
            </Rectangle>
          )}
        </MapContainer>

        {/* FLOATING TOP-LEFT TOOLBAR: SEARCH & DEFINE BOUNDING BOX CARD */}
        <div
          className="absolute top-4 left-4 z-[1000] flex flex-col gap-2.5 max-w-lg w-[calc(100%-2rem)] sm:w-[480px] pointer-events-auto"
          style={{ position: "absolute", top: "1rem", left: "1rem", zIndex: 1000 }}
        >
          {/* Search Box */}
          <LocationSearch onSelectLocation={handleLocationSelect} />

          {/* Area Control Card */}
          <div className="p-3.5 rounded-xl bg-[#0b1018]/98 border border-amber-500/70 shadow-2xl backdrop-blur-md space-y-3 font-mono text-xs animate-in fade-in duration-200">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 border-b border-[#1f2d40] pb-2.5">
              <div className="space-y-0.5">
                <div className="font-bold text-white text-xs flex items-center gap-1.5">
                  <Scan className="w-4 h-4 text-amber-400" />
                  <span>Define Bounding Box Area (0.3 km² – 25 km²)</span>
                </div>
                <div className="text-[11px] text-slate-400 font-sans">
                  Draw on map or snap to current view, then run network risk analysis:
                </div>
              </div>

              {/* Action Buttons: Draw vs Current View */}
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setIsDrawingRectangle((prev) => !prev)}
                  className={`px-3 py-1.5 rounded text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                    isDrawingRectangle
                      ? "bg-amber-500 text-slate-950 shadow-[0_0_12px_rgba(245,158,11,0.5)] animate-pulse"
                      : "bg-[#141e2b] hover:bg-[#1a293b] text-slate-200 border border-[#283d56]"
                  }`}
                  title="Click and drag on the map to draw a custom rectangle"
                >
                  <Square className="w-3.5 h-3.5" />
                  <span>{isDrawingRectangle ? "DRAGGING ON MAP..." : "Draw rectangle"}</span>
                </button>

                <button
                  type="button"
                  onClick={handleUseCurrentView}
                  className="px-3 py-1.5 rounded bg-[#141e2b] hover:bg-[#1a293b] text-slate-200 border border-[#283d56] text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                  title="Take the currently visible map viewport bounds"
                >
                  <Maximize2 className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Use current view</span>
                </button>
              </div>
            </div>

            {/* Instruction if drawing */}
            {isDrawingRectangle && (
              <div className="p-2.5 rounded bg-amber-950/50 border border-amber-600/70 text-xs text-amber-200 flex items-center gap-2 font-sans">
                <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping shrink-0" />
                <span>
                  <strong>Draw Mode Active:</strong> Click and drag diagonally on the map to define your bounding box. Release to set.
                </span>
              </div>
            )}

            {/* Metrics & Validation Strip */}
            {selectedAreaBounds && (
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 p-3 rounded-lg bg-[#070b12] border border-[#1a2638]">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] text-slate-400 font-mono">SELECTED BOUNDS SIZE:</span>
                    <span className="text-sm font-bold text-white font-mono tabular-nums">
                      {selectedAreaKm2} km²
                    </span>
                  </div>

                  {isAreaTooLarge && (
                    <div className="text-[11px] text-rose-400 font-sans font-medium flex items-center gap-1.5">
                      <AlertTriangle className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                      <span>
                        Area exceeds the 25 km² limit ({selectedAreaKm2} km²). Please select a smaller box.
                      </span>
                    </div>
                  )}

                  {isAreaTooSmall && (
                    <div className="text-[11px] text-amber-400 font-sans font-medium flex items-center gap-1.5">
                      <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                      <span>
                        Area is below the 0.3 km² minimum ({selectedAreaKm2} km²). Please select a larger box.
                      </span>
                    </div>
                  )}

                  {isAreaValid && (
                    <div className="text-[11px] text-emerald-400 font-sans font-medium flex items-center gap-1.5">
                      <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                      <span>Area size valid ({selectedAreaKm2} km²). Ready to query OpenStreetMap.</span>
                    </div>
                  )}
                </div>

                {/* Run Analysis Button */}
                <button
                  type="button"
                  onClick={handleRunAnalysis}
                  disabled={!isAreaValid || loading}
                  className={`px-4 py-2.5 rounded-lg font-bold text-xs flex items-center gap-2 transition-all shadow-lg shrink-0 cursor-pointer ${
                    isAreaValid && !loading
                      ? "bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 font-black shadow-[0_0_20px_rgba(16,185,129,0.4)]"
                      : "bg-[#182333] text-slate-500 border border-[#23354d] cursor-not-allowed opacity-60"
                  }`}
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>RUN ANALYSIS ON THIS AREA</span>
                </button>
              </div>
            )}
          </div>

          {/* OVERPASS ERROR CARD WITH RETRY BUTTON */}
          {fetchError && (
            <div className="p-3.5 rounded-lg bg-rose-950/95 border-2 border-rose-500 text-white shadow-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs animate-in fade-in duration-200 font-mono">
              <div className="space-y-0.5">
                <div className="flex items-center gap-2 font-bold text-rose-300 uppercase">
                  <AlertOctagon className="w-4 h-4 text-rose-400 shrink-0 animate-pulse" />
                  <span>OpenStreetMap Query Issue</span>
                </div>
                <p className="text-rose-100 font-sans text-[11px]">
                  {fetchError}
                </p>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={handleRunAnalysis}
                  disabled={loading}
                  className="px-3 py-1.5 rounded bg-rose-700 hover:bg-rose-600 text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow-md"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${loading ? "animate-spin" : ""}`} />
                  <span>RETRY</span>
                </button>

                <button
                  type="button"
                  onClick={handleUseDefaultZone}
                  className="px-3 py-1.5 rounded bg-[#162030] hover:bg-[#202e45] text-slate-200 border border-[#2b3e58] font-bold text-xs cursor-pointer"
                >
                  USE CENTRAL DELHI
                </button>
              </div>
            </div>
          )}
        </div>

        {/* LOADING OVERLAY WHILE ROADS LOAD */}
        {loading && (
          <div className="absolute inset-0 z-[2000] bg-[#0c0e12]/80 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="p-6 rounded-xl bg-[#101520] border border-[#223348] shadow-2xl text-center space-y-3 max-w-sm w-full font-mono">
              <div className="w-10 h-10 mx-auto rounded-full bg-[#162335] border border-cyan-400/40 flex items-center justify-center text-cyan-400">
                <RefreshCw className="w-5 h-5 animate-spin" />
              </div>
              <div className="text-xs font-bold text-white uppercase tracking-wider">
                Loading Road Infrastructure
              </div>
              <div className="text-[11px] text-slate-300 bg-[#090c10] border border-[#1b2536] px-3 py-2 rounded">
                {loadingMessage || "Querying OpenStreetMap for drivable roads in target area..."}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
