import React, { useState } from "react";
import { Link } from "react-router-dom";
import {
  Activity,
  Home,
  RefreshCw,
  Info,
  Play,
  Users,
  RotateCcw,
  Radio,
  Award,
  Scan,
} from "lucide-react";
import RoadMap from "./components/RoadMap";
import RightTabsPanel from "./components/RightTabsPanel";
import ModelAssumptionsModal from "./components/ModelAssumptionsModal";
import ResidentReportingModal from "./components/ResidentReportingModal";
import { useAppState } from "./context/AppStateContext";

export default function App() {
  const {
    currentZone,
    roads,
    hospitals,
    dataSource,
    loading,
    loadingMessage,
    fetchError,
    selectedRoad,
    setSelectedRoad,
    selectedHotspotId,
    setSelectedHotspotId,
    rainfallLevel,
    setRainfallLevel,
    activeTab,
    setActiveTab,
    cascadeStepIndex,
    setCascadeStepIndex,
    selectedHospitalAreaId,
    setSelectedHospitalAreaId,
    showHospitalNodes,
    setShowHospitalNodes,
    liveFeed,
    isLiveFeedLoading,
    useLiveTinyFish,
    setUseLiveTinyFish,
    effectiveClosedRoadIds,
    graph,
    odPairs,
    baselineTraffic,
    whatIfScenario,
    hospitalAccess,
    activeZoneHotspots,
    loadZoneData,
    handleRunAnalysisArea,
    handleResetToCentralDelhi,
    fetchLiveFeed,
    toggleRoadClosed,
    resetClosures,
    handleRunDemoScenario,
  } = useAppState();

  // Modal Dialog States (kept local to dashboard UI modals)
  const [showAssumptionsModal, setShowAssumptionsModal] = useState<boolean>(false);
  const [showReportingModal, setShowReportingModal] = useState<boolean>(false);

  return (
    <div className="w-full min-h-screen flex flex-col bg-[#080b10] text-slate-100 font-sans select-none">
      {/* Top Landing & Planner Header */}
      <header className="h-[56px] bg-[#0a0d14] border-b border-[#182333] px-3 lg:px-5 flex items-center justify-between shrink-0 z-30 select-none">
        <div className="flex items-center gap-3 min-w-0">
          {/* Home link to return to Cover / Landing Page */}
          <Link
            to="/"
            className="px-2.5 py-1.5 rounded bg-[#131c2a] hover:bg-[#1c2738] border border-[#23354d] text-slate-300 hover:text-white font-mono text-xs flex items-center gap-1.5 transition-colors cursor-pointer shadow-sm"
            title="Return to Cover / Landing page"
          >
            <Home className="w-3.5 h-3.5 text-cyan-400" />
            <span className="font-bold">HOME</span>
          </Link>

          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded bg-[#131c2a] border border-[#24354d] flex items-center justify-center text-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.25)]">
              <Activity className="w-4 h-4" />
            </div>
            <div>
              <span className="font-mono font-black text-sm tracking-tight text-white flex items-center gap-1.5">
                <span>ROADRISK DELHI</span>
                <span className="text-[10px] text-cyan-400 px-1.5 py-0.2 rounded bg-cyan-950/80 border border-cyan-800/60 font-semibold tracking-wider truncate max-w-[200px]">
                  {currentZone.isDefault ? "CENTRAL ZONE" : currentZone.name.toUpperCase()}
                </span>
              </span>
              <span className="text-[10px] font-mono text-slate-400 uppercase tracking-widest hidden xl:block">
                Pre-Monsoon Flood What-If &amp; Cascade Engine for Resilient Roads and Hospital Access
              </span>
            </div>
          </div>

          {/* Current scenario status badge */}
          {useLiveTinyFish && (
            <span className="hidden md:inline-flex items-center gap-1.5 px-2 py-0.5 rounded bg-cyan-950/90 border border-cyan-400 text-cyan-300 font-mono text-[10.5px] font-bold shadow-[0_0_12px_rgba(6,182,212,0.25)] animate-in fade-in duration-200">
              <Radio className="w-3 h-3 text-cyan-400 animate-pulse" />
              <span>Live conditions active: {liveFeed?.matches?.length || 0} hotspots flooded</span>
            </span>
          )}
        </div>

        {/* Header Right: Actions, Change Area, Demo Scenario, Live Feed, Best Fixes, Resident Reporting, Assumptions */}
        <div className="flex items-center gap-2 font-mono text-xs">
          {/* Change Area Button to /select-area */}
          <Link
            to="/select-area"
            className="px-2.5 py-1.5 rounded bg-[#131c2a] hover:bg-[#1a283b] border border-amber-600/60 text-amber-300 hover:text-white font-bold text-[11px] flex items-center gap-1.5 transition-colors cursor-pointer"
            title="Choose or draw a custom analysis zone"
          >
            <Scan className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden sm:inline">CHANGE AREA</span>
            <span className="sm:hidden">AREA</span>
          </Link>

          {/* Reset to Central Delhi Button if custom area active */}
          {!currentZone.isDefault && (
            <button
              type="button"
              onClick={handleResetToCentralDelhi}
              className="px-2.5 py-1.5 rounded bg-[#131c2a] hover:bg-[#1a283b] border border-cyan-700/60 text-cyan-300 font-bold text-[11px] flex items-center gap-1.5 transition-colors cursor-pointer"
              title="Reset simulation back to default Central Delhi zone"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">RESET TO CENTRAL DELHI</span>
              <span className="sm:hidden">RESET</span>
            </button>
          )}

          {/* Run Demo Scenario Button */}
          <button
            type="button"
            onClick={handleRunDemoScenario}
            className="px-3 py-1.5 rounded bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs flex items-center gap-1.5 transition-all shadow-[0_0_15px_rgba(245,158,11,0.35)] cursor-pointer"
            title="Load Minto Bridge flooded, Extreme rainfall, and open the Cascade tab"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span className="whitespace-nowrap font-black">RUN DEMO SCENARIO</span>
          </button>

          {/* Live Feed Navigation Link */}
          <Link
            to="/live-feed"
            className={`px-2.5 py-1.5 rounded border text-[11px] font-bold flex items-center gap-1.5 transition-colors cursor-pointer ${
              useLiveTinyFish
                ? "bg-cyan-950/80 border-cyan-400 text-cyan-300 shadow-[0_0_10px_rgba(6,182,212,0.3)]"
                : "bg-[#141b26] hover:bg-[#1b2536] border-[#25374d] text-slate-200 hover:text-cyan-300"
            }`}
            title="Open TinyFish live flood intelligence feed"
          >
            <Radio className={`w-3.5 h-3.5 ${useLiveTinyFish ? "text-cyan-400 animate-pulse" : "text-slate-400"}`} />
            <span className="hidden sm:inline">LIVE FEED</span>
            <span className="sm:hidden">FEED</span>
          </Link>

          {/* Best Fixes Navigation Link */}
          <Link
            to="/best-fixes"
            className="px-2.5 py-1.5 rounded bg-[#141b26] hover:bg-[#1b2536] border border-[#25374d] text-slate-200 hover:text-emerald-300 text-[11px] font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
            title="Open Best Fixes Pareto capital & quick drainage optimizer"
          >
            <Award className="w-3.5 h-3.5 text-emerald-400" />
            <span className="hidden sm:inline">BEST FIXES</span>
            <span className="sm:hidden">FIXES</span>
          </Link>

          {/* Resident Reporting Link */}
          <Link
            to="/reports"
            className="px-2.5 py-1.5 rounded bg-[#141b26] hover:bg-[#1b2536] border border-[#25374d] text-slate-200 hover:text-cyan-300 text-[11px] font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
            title="Open resident reporting concept mockup page"
          >
            <Users className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden sm:inline">RESIDENT REPORTING (MOCKUP)</span>
            <span className="sm:hidden">REPORT</span>
          </Link>

          {/* Model Assumptions Link */}
          <Link
            to="/assumptions"
            className="px-2.5 py-1.5 rounded bg-[#131d2b] hover:bg-[#1a293d] border border-[#253952] text-[#38bdf8] font-bold text-[11px] flex items-center gap-1.5 transition-colors cursor-pointer"
            title="View theoretical model assumptions & methodology"
          >
            <Info className="w-3.5 h-3.5 text-[#38bdf8]" />
            <span className="hidden md:inline">ASSUMPTIONS</span>
          </Link>

          {/* Quick Refresh */}
          <button
            type="button"
            onClick={() => loadZoneData(currentZone, true)}
            disabled={loading}
            className="px-2 py-1.5 rounded bg-[#141d2b] hover:bg-[#1a273b] border border-[#24364e] text-slate-300 hover:text-cyan-300 text-[11px] font-bold flex items-center gap-1 transition-colors cursor-pointer"
            title="Bypass server cache and re-query OpenStreetMap"
          >
            <RefreshCw className={`w-3 h-3 ${loading ? "animate-spin text-cyan-400" : ""}`} />
            <span className="hidden lg:inline">REFRESH OSM</span>
          </button>
        </div>
      </header>

      {/* Main Workstation: Map on Left, Planner Tabs on Right */}
      <div className="flex-1 flex flex-col lg:flex-row relative min-h-0">
        {/* Left Map Viewport */}
        <main
          className="flex-1 relative bg-slate-950"
          style={{
            width: "100%",
            height: "calc(100vh - 56px)",
            minHeight: "calc(100vh - 56px)",
            position: "relative",
          }}
        >
          <RoadMap
            roads={roads}
            hospitals={hospitals}
            graph={graph}
            dataSource={dataSource}
            loading={loading}
            loadingMessage={loadingMessage}
            onRefresh={() => loadZoneData(currentZone, true)}
            selectedRoadId={selectedRoad?.id}
            onSelectRoad={(road) => setSelectedRoad(road)}
            baselineTraffic={baselineTraffic}
            odPairs={odPairs}
            whatIfScenario={whatIfScenario}
            closedRoadIds={effectiveClosedRoadIds}
            onToggleRoadClosed={toggleRoadClosed}
            selectedHotspotId={selectedHotspotId}
            onSelectHotspot={(id) => setSelectedHotspotId(id)}
            rainfallLevel={rainfallLevel}
            activeTab={activeTab}
            cascadeStepIndex={cascadeStepIndex}
            onResetClosures={resetClosures}
            hospitalAccess={hospitalAccess}
            selectedHospitalAreaId={selectedHospitalAreaId}
            onSelectHospitalArea={setSelectedHospitalAreaId}
            showHospitalNodes={showHospitalNodes}
            onToggleHospitalNodes={() => setShowHospitalNodes((v: boolean) => !v)}
            currentZone={currentZone}
            onRunAnalysisArea={handleRunAnalysisArea}
            onResetToCentralDelhi={handleResetToCentralDelhi}
            fetchError={fetchError}
            onRetryAnalysis={() => loadZoneData(currentZone, true)}
          />
        </main>

        {/* Right Planner Tabs Panel */}
        <RightTabsPanel
          roads={roads}
          hospitals={hospitals}
          graph={graph}
          dataSource={dataSource}
          loading={loading}
          selectedRoad={selectedRoad}
          onClearSelectedRoad={() => setSelectedRoad(null)}
          baselineTraffic={baselineTraffic}
          odPairs={odPairs}
          whatIfScenario={whatIfScenario}
          closedRoadIds={effectiveClosedRoadIds}
          onToggleRoadClosed={toggleRoadClosed}
          selectedHotspotId={selectedHotspotId}
          onSelectHotspot={(id) => setSelectedHotspotId(id)}
          rainfallLevel={rainfallLevel}
          onSetRainfallLevel={setRainfallLevel}
          onResetClosures={resetClosures}
          activeTab={activeTab}
          onTabChange={setActiveTab}
          cascadeStepIndex={cascadeStepIndex}
          onSetCascadeStepIndex={setCascadeStepIndex}
          hospitalAccess={hospitalAccess}
          selectedHospitalAreaId={selectedHospitalAreaId}
          onSelectHospitalArea={setSelectedHospitalAreaId}
          liveFeed={liveFeed}
          isLiveFeedLoading={isLiveFeedLoading}
          onRefreshLiveFeed={() => fetchLiveFeed(true)}
          useLiveTinyFish={useLiveTinyFish}
          onToggleUseLiveTinyFish={setUseLiveTinyFish}
          activeZoneHotspots={activeZoneHotspots}
          currentZone={currentZone}
          onSimulateHotspotFix={(id) => {
            setSelectedHotspotId(id);
            setActiveTab("what_if");
          }}
        />
      </div>

      {/* Model Assumptions Modal */}
      <ModelAssumptionsModal
        isOpen={showAssumptionsModal}
        onClose={() => setShowAssumptionsModal(false)}
      />

      {/* Resident Reporting Concept Mockup Modal */}
      <ResidentReportingModal
        isOpen={showReportingModal}
        onClose={() => setShowReportingModal(false)}
      />
    </div>
  );
}
