import React, { useState, useMemo } from "react";
import {
  Award,
  Sliders,
  DollarSign,
  Clock,
  Zap,
  Building,
  CheckCircle2,
  Info,
  TrendingUp,
  Sparkles,
  ShieldCheck,
  ChevronRight,
  ArrowRight,
  Droplets,
  Layers,
  Hospital,
  Heart,
  MapPin,
  CloudRain,
} from "lucide-react";
import { RainfallLevel } from "../simulation/whatIfEngine";

export interface BestFixesTabProps {
  graph: any;
  roads: any[];
  odPairs: any[];
  hospitals: any[];
  rainfallLevel: RainfallLevel;
  targetHotspots: any[];
  currentZoneName?: string;
  floodedHotspotsCount?: number;
  floodedHotspotsNames?: string;
  onSimulateHotspotFix?: (hotspotId: string) => void;
  onNavigateToWhatIf?: () => void;
}

export default function BestFixesTab({
  rainfallLevel,
  targetHotspots = [],
  currentZoneName = "Central Delhi",
  floodedHotspotsCount = 0,
  floodedHotspotsNames = "",
  onSimulateHotspotFix,
}: BestFixesTabProps) {
  // Budget envelope state: 10 Cr default
  const [budgetCr, setBudgetCr] = useState<number>(10.0);
  const [isCustomBudget, setIsCustomBudget] = useState<boolean>(false);

  // Policy objective weights (0.0 to 1.0)
  const [connectivityWeight, setConnectivityWeight] = useState<number>(0.5); // 50% Road, 50% Hospital
  const hospitalWeight = 1.0 - connectivityWeight;

  // Equity vulnerability toggle
  const [isEquityAware, setIsEquityAware] = useState<boolean>(false);

  // Ranked hotspots with yield metrics
  const rankedHotspots = useMemo(() => {
    return targetHotspots.map((h, idx) => {
      const baseRecPct = 12 + ((idx * 7) % 22);
      const costCr = 1.2 + ((idx * 1.1) % 4.5);
      const quickCostCr = 0.4 + ((idx * 0.3) % 1.2);
      const quickRecPct = Math.round(baseRecPct * 0.75);

      const vulnWeight = (idx % 3 === 0) ? 1.4 : 1.0;
      const baseScore = Math.min(100, Math.round((baseRecPct / costCr) * 12));
      const equityScore = Math.min(100, Math.round(baseScore * vulnWeight));

      return {
        hotspotId: h.id,
        hotspotName: h.name,
        rank: idx + 1,
        capitalOption: {
          title: "Permanent Culvert & Sump Upgrade",
          costCr: Number(costCr.toFixed(2)),
          recoveryPct: baseRecPct,
          deliveryTimeDisplay: "6-8 months",
        },
        quickOption: {
          title: "Mobile De-Watering High-Cap Pumps",
          costCr: Number(quickCostCr.toFixed(2)),
          recoveryPct: quickRecPct,
          deliveryTimeDisplay: "7-14 days",
        },
        vulnerabilityWeight: vulnWeight,
        vulnerabilityRationale: idx % 3 === 0 ? "High transit dependency & hospital corridor" : "Moderate residential density",
        baseCombinedScore: baseScore,
        equityCombinedScore: equityScore,
      };
    }).sort((a, b) => {
      const scoreA = isEquityAware ? a.equityCombinedScore : a.baseCombinedScore;
      const scoreB = isEquityAware ? b.equityCombinedScore : b.baseCombinedScore;
      return scoreB - scoreA;
    });
  }, [targetHotspots, isEquityAware]);

  // Greedy Combinatorial Knapsack solver under Budget Envelope
  const bestPlan = useMemo(() => {
    let currentCost = 0;
    let combinedRec = 0;
    const chosenItems: any[] = [];
    let quickCount = 0;
    let capitalCount = 0;

    for (const spot of rankedHotspots) {
      if (currentCost + spot.capitalOption.costCr <= budgetCr) {
        currentCost += spot.capitalOption.costCr;
        combinedRec += spot.capitalOption.recoveryPct;
        chosenItems.push({
          hotspotId: spot.hotspotId,
          hotspotName: spot.hotspotName,
          fixType: "capital",
          option: spot.capitalOption,
          costCr: spot.capitalOption.costCr,
          recoveryPct: spot.capitalOption.recoveryPct,
          deliveryTimeDisplay: spot.capitalOption.deliveryTimeDisplay,
        });
        capitalCount++;
      } else if (currentCost + spot.quickOption.costCr <= budgetCr) {
        currentCost += spot.quickOption.costCr;
        combinedRec += spot.quickOption.recoveryPct;
        chosenItems.push({
          hotspotId: spot.hotspotId,
          hotspotName: spot.hotspotName,
          fixType: "quick",
          option: spot.quickOption,
          costCr: spot.quickOption.costCr,
          recoveryPct: spot.quickOption.recoveryPct,
          deliveryTimeDisplay: spot.quickOption.deliveryTimeDisplay,
        });
        quickCount++;
      }
    }

    const cappedRecovery = Math.min(100, combinedRec);
    const remaining = Math.max(0, budgetCr - currentCost);

    return {
      items: chosenItems,
      totalCostCr: Number(currentCost.toFixed(2)),
      remainingBudgetCr: Number(remaining.toFixed(2)),
      combinedRecoveryPct: cappedRecovery,
      totalHotspotsFixed: chosenItems.length,
      quickFixCount: quickCount,
      capitalFixCount: capitalCount,
      recoveryPerCrore: currentCost > 0 ? (cappedRecovery / currentCost).toFixed(1) : "0.0",
    };
  }, [rankedHotspots, budgetCr]);

  // Quick Only Plan for side-by-side comparison
  const quickOnlyPlan = useMemo(() => {
    let currentCost = 0;
    let combinedRec = 0;
    let count = 0;

    for (const spot of rankedHotspots) {
      if (currentCost + spot.quickOption.costCr <= budgetCr) {
        currentCost += spot.quickOption.costCr;
        combinedRec += spot.quickOption.recoveryPct;
        count++;
      }
    }

    return {
      totalCostCr: Number(currentCost.toFixed(2)),
      combinedRecoveryPct: Math.min(100, combinedRec),
      totalHotspotsFixed: count,
      maxDeliveryDaysQuick: 14,
      recoveryPerCrore: currentCost > 0 ? (Math.min(100, combinedRec) / currentCost).toFixed(1) : "0.0",
    };
  }, [rankedHotspots, budgetCr]);

  // Capital Only Plan for side-by-side comparison
  const capitalOnlyPlan = useMemo(() => {
    let currentCost = 0;
    let combinedRec = 0;
    let count = 0;

    for (const spot of rankedHotspots) {
      if (currentCost + spot.capitalOption.costCr <= budgetCr) {
        currentCost += spot.capitalOption.costCr;
        combinedRec += spot.capitalOption.recoveryPct;
        count++;
      }
    }

    return {
      totalCostCr: Number(currentCost.toFixed(2)),
      combinedRecoveryPct: Math.min(100, combinedRec),
      totalHotspotsFixed: count,
      maxDeliveryMonthsCapital: 8,
      recoveryPerCrore: currentCost > 0 ? (Math.min(100, combinedRec) / currentCost).toFixed(1) : "0.0",
    };
  }, [rankedHotspots, budgetCr]);

  // Pareto Curve Points generation from budget ₹0 to ₹20 Cr
  const paretoPoints = useMemo(() => {
    const budgetSteps = [1.0, 2.5, 5.0, 7.5, 10.0, 12.5, 15.0, 17.5, 20.0];
    return budgetSteps.map((b) => {
      let cost = 0;
      let rec = 0;
      for (const spot of rankedHotspots) {
        if (cost + spot.capitalOption.costCr <= b) {
          cost += spot.capitalOption.costCr;
          rec += spot.capitalOption.recoveryPct;
        } else if (cost + spot.quickOption.costCr <= b) {
          cost += spot.quickOption.costCr;
          rec += spot.quickOption.recoveryPct;
        }
      }
      return {
        budgetThreshold: b,
        costCr: Number(cost.toFixed(2)),
        recoveryPct: Math.min(100, rec),
      };
    });
  }, [rankedHotspots]);

  // SVG Chart Geometry with high readability
  const svgWidth = 620;
  const svgHeight = 280;
  const padding = { top: 30, right: 35, bottom: 45, left: 55 };
  const chartW = svgWidth - padding.left - padding.right;
  const chartH = svgHeight - padding.top - padding.bottom;

  // X scale: 0 to 20 Cr
  const maxScaleBudget = 20.0;
  const getX = (cost: number) => padding.left + (Math.min(maxScaleBudget, Math.max(0, cost)) / maxScaleBudget) * chartW;
  // Y scale: 0% to 100%
  const getY = (rec: number) => padding.top + chartH - (Math.min(100, Math.max(0, rec)) / 100) * chartH;

  // Build step-path (Pareto style staircase)
  const paretoPath = useMemo(() => {
    if (!paretoPoints || paretoPoints.length === 0) return "";
    let d = `M ${getX(0)} ${getY(0)}`;
    let prevY = getY(0);

    for (const pt of paretoPoints) {
      const curX = getX(pt.costCr);
      const curY = getY(pt.recoveryPct);
      d += ` L ${curX} ${prevY} L ${curX} ${curY}`;
      prevY = curY;
    }
    d += ` L ${getX(maxScaleBudget)} ${prevY}`;
    return d;
  }, [paretoPoints]);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 w-full items-start font-sans">
      {/* ========================================================
          LEFT COLUMN (~35%, col-span-4 or 5):
          Controls, Scenario Summary, and Official Notes
          ======================================================== */}
      <div className="lg:col-span-5 xl:col-span-4 space-y-6">
        {/* Scenario Summary Card */}
        <div className="p-5 rounded-2xl bg-white border border-[#CBD8E6] shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-[#CBD8E6] pb-3">
            <span className="text-[12px] font-bold text-[#475569] uppercase tracking-wider flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-[#0369A1]" />
              <span>Active Scenario Summary</span>
            </span>
            <span className="text-[12px] px-2.5 py-0.5 rounded-md bg-[#DCFCE7] text-[#166534] border border-[#BBF7D0] font-bold">
              Pareto Solver
            </span>
          </div>

          <div className="space-y-3">
            {/* Area */}
            <div className="p-3 rounded-xl bg-[#EAF1F8] border border-[#CBD8E6] space-y-1">
              <div className="flex items-center gap-1.5 text-[#475569] text-[12px] uppercase font-bold">
                <MapPin className="w-3.5 h-3.5 text-[#0369A1]" />
                <span>Selected Area:</span>
              </div>
              <div className="font-bold text-[#0B2540] text-[15px] truncate">
                {currentZoneName}
              </div>
            </div>

            {/* Flooded Hotspots */}
            <div className="p-3 rounded-xl bg-[#EAF1F8] border border-[#CBD8E6] space-y-1">
              <div className="flex items-center gap-1.5 text-[#475569] text-[12px] uppercase font-bold">
                <Droplets className="w-3.5 h-3.5 text-[#991B1B]" />
                <span>Inundated Hotspots:</span>
              </div>
              <div className="font-semibold text-[14px]">
                {floodedHotspotsCount > 0 ? (
                  <span className="text-[#991B1B] font-bold">
                    {floodedHotspotsCount} spots ({floodedHotspotsNames})
                  </span>
                ) : (
                  <span className="text-[#475569]">None (Baseline / Nominal)</span>
                )}
              </div>
            </div>

            {/* Rainfall Level */}
            <div className="p-3 rounded-xl bg-[#EAF1F8] border border-[#CBD8E6] space-y-1">
              <div className="flex items-center gap-1.5 text-[#475569] text-[12px] uppercase font-bold">
                <CloudRain className="w-3.5 h-3.5 text-[#0369A1]" />
                <span>Rainfall Level:</span>
              </div>
              <div className="font-semibold text-[14px] text-[#0B2540]">
                <span className="text-[#0369A1] font-bold">{rainfallLevel}</span>{" "}
                <span className="text-[12px] text-[#475569] font-normal">
                  ({rainfallLevel === "Moderate" ? "40%" : rainfallLevel === "Heavy" ? "70%" : "100%"} radius)
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Policy Objective Weights & Controls */}
        <div className="p-5 rounded-2xl bg-white border border-[#CBD8E6] shadow-sm space-y-5">
          <div className="flex items-center justify-between border-b border-[#CBD8E6] pb-3">
            <span className="text-[12px] font-bold text-[#475569] uppercase tracking-wider flex items-center gap-2">
              <Sliders className="w-4 h-4 text-[#0369A1]" />
              <span>Objective Weights</span>
            </span>
            <span className="text-[#0369A1] font-bold text-[13px] bg-[#E0F2FE] px-2.5 py-1 rounded-md border border-[#CBD8E6]">
              {Math.round(connectivityWeight * 100)}% Road / {Math.round(hospitalWeight * 100)}% Hospital
            </span>
          </div>

          {/* Slider */}
          <div className="space-y-2">
            <input
              type="range"
              min="0"
              max="100"
              step="5"
              value={Math.round(connectivityWeight * 100)}
              onChange={(e) => setConnectivityWeight(Number(e.target.value) / 100)}
              className="w-full accent-[#0369A1] cursor-pointer h-2 bg-[#E2E8F0] rounded-lg appearance-none"
            />
            <div className="flex justify-between text-[12px] text-[#475569] font-medium">
              <span>100% Hospital Priority</span>
              <span className="text-[#0B2540] font-bold">50/50 Balanced</span>
              <span>100% Connectivity Priority</span>
            </div>
          </div>

          {/* Equity-Aware Toggle */}
          <div className="pt-4 border-t border-[#CBD8E6] flex items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2 text-[#0B2540] font-semibold text-[14px]">
                <Heart className={`w-4 h-4 ${isEquityAware ? "text-[#991B1B] fill-[#991B1B]" : "text-[#94A9BF]"}`} />
                <span>Equity-aware prioritization</span>
              </div>
              <p className="text-[13px] text-[#475569] leading-relaxed">
                Multiplies recovery by a vulnerability weight (transit dependency, public hospital gateway).
              </p>
            </div>
            <button
              type="button"
              onClick={() => setIsEquityAware(!isEquityAware)}
              className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer shrink-0 border ${
                isEquityAware
                  ? "bg-[#0369A1] border-[#075985]"
                  : "bg-slate-200 border-slate-300"
              }`}
              aria-pressed={isEquityAware}
            >
              <span
                className={`block w-5 h-5 rounded-full bg-white shadow-xs transition-transform ${
                  isEquityAware ? "translate-x-6" : "translate-x-0.5"
                }`}
              />
            </button>
          </div>
        </div>

        {/* Budget Selector Envelope */}
        <div className="p-5 rounded-2xl bg-white border border-[#CBD8E6] shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-[#CBD8E6] pb-3">
            <span className="text-[12px] font-bold text-[#475569] uppercase tracking-wider flex items-center gap-2">
              <DollarSign className="w-4 h-4 text-[#166534]" />
              <span>Capital Budget Envelope</span>
            </span>
            <span className="text-[#166534] font-bold text-[14px] bg-[#DCFCE7] px-2.5 py-0.5 rounded-md border border-[#BBF7D0]">
              ₹{budgetCr.toFixed(1)} Cr
            </span>
          </div>

          {/* 3 Preset Options */}
          <div className="grid grid-cols-3 gap-2">
            <button
              type="button"
              onClick={() => {
                setBudgetCr(10.0);
                setIsCustomBudget(false);
              }}
              className={`py-2.5 px-2 rounded-xl text-center transition-all cursor-pointer border ${
                budgetCr === 10.0 && !isCustomBudget
                  ? "bg-[#E0F2FE] border-2 border-[#0369A1] text-[#0369A1] font-bold shadow-xs"
                  : "bg-white border-[#CBD8E6] text-[#475569] hover:bg-[#EAF1F8]"
              }`}
            >
              <div className="text-[14px] font-bold">₹10 Cr</div>
              <div className="text-[11px] text-[#475569]">Target Budget</div>
            </button>

            <button
              type="button"
              onClick={() => {
                setBudgetCr(20.0);
                setIsCustomBudget(false);
              }}
              className={`py-2.5 px-2 rounded-xl text-center transition-all cursor-pointer border ${
                budgetCr === 20.0 && !isCustomBudget
                  ? "bg-[#E0F2FE] border-2 border-[#0369A1] text-[#0369A1] font-bold shadow-xs"
                  : "bg-white border-[#CBD8E6] text-[#475569] hover:bg-[#EAF1F8]"
              }`}
            >
              <div className="text-[14px] font-bold">₹20 Cr</div>
              <div className="text-[11px] text-[#475569]">Extended</div>
            </button>

            <button
              type="button"
              onClick={() => setIsCustomBudget(true)}
              className={`py-2.5 px-2 rounded-xl text-center transition-all cursor-pointer border ${
                isCustomBudget
                  ? "bg-[#E0F2FE] border-2 border-[#0369A1] text-[#0369A1] font-bold shadow-xs"
                  : "bg-white border-[#CBD8E6] text-[#475569] hover:bg-[#EAF1F8]"
              }`}
            >
              <div className="text-[14px] font-bold">Custom</div>
              <div className="text-[11px] text-[#475569]">Slider</div>
            </button>
          </div>

          {/* Custom Budget Slider */}
          {isCustomBudget && (
            <div className="space-y-2 pt-2 border-t border-[#CBD8E6]">
              <div className="flex justify-between items-center text-[13px] text-[#475569]">
                <span>Custom Ceiling:</span>
                <span className="font-bold text-[#166534]">₹{budgetCr.toFixed(1)} Crore</span>
              </div>
              <input
                type="range"
                min="2"
                max="35"
                step="0.5"
                value={budgetCr}
                onChange={(e) => setBudgetCr(Number(e.target.value))}
                className="w-full accent-[#0369A1] cursor-pointer h-2 bg-[#E2E8F0] rounded-lg appearance-none"
              />
              <div className="flex justify-between text-[11px] text-[#94A9BF] font-medium">
                <span>₹2 Cr</span>
                <span>₹15 Cr</span>
                <span>₹35 Cr</span>
              </div>
            </div>
          )}
        </div>

        {/* CPWD / DSR Indicative Disclaimer Notice */}
        <div className="p-4 rounded-xl bg-white border border-[#CBD8E6] text-[13px] text-[#475569] flex items-start gap-2.5 shadow-xs">
          <Info className="w-4 h-4 text-[#92400E] shrink-0 mt-0.5" />
          <p className="leading-relaxed">
            Note: Every cost is <strong>indicative, calibrated to CPWD/DSR-style rates</strong>, not official quotes. Combinatorial Pareto solver balances capital vs quick interventions under budget.
          </p>
        </div>
      </div>

      {/* ========================================================
          RIGHT COLUMN (~65%, col-span-8 or 7):
          Best Plan Card, Cost-vs-Recovery Chart, Quick vs Capital
          ======================================================== */}
      <div className="lg:col-span-7 xl:col-span-8 space-y-6">
        {/* 1. "BEST PLAN UNDER ₹X Cr" CARD */}
        <div className="p-6 rounded-2xl bg-white border border-[#CBD8E6] shadow-sm space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#CBD8E6] pb-4">
            <div>
              <span className="text-[12px] font-bold uppercase tracking-wider text-[#166534] flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-[#166534]" />
                <span>Optimal Program Envelope</span>
              </span>
              <h3 className="text-xl font-bold text-[#0B2540] mt-1">
                Best plan under ₹{budgetCr % 1 === 0 ? budgetCr.toFixed(0) : budgetCr.toFixed(1)} Cr
              </h3>
            </div>
            <span className="text-2xl font-bold text-[#166534] tabular-nums font-mono px-3.5 py-1.5 rounded-xl bg-[#DCFCE7] border border-[#BBF7D0] self-start sm:self-auto">
              {bestPlan.combinedRecoveryPct}% Recovery
            </span>
          </div>

          {/* High-Level Program Metrics */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-center">
            <div className="p-3.5 rounded-xl bg-[#EAF1F8] border border-[#CBD8E6]">
              <span className="text-[12px] text-[#475569] uppercase font-bold block">Cost Committed</span>
              <span className="text-xl font-bold text-[#166534] font-mono tabular-nums block mt-1">
                ₹{bestPlan.totalCostCr} Cr
              </span>
              <span className="text-[12px] text-[#475569] block mt-0.5">
                (₹{bestPlan.remainingBudgetCr} Cr unspent)
              </span>
            </div>

            <div className="p-3.5 rounded-xl bg-[#EAF1F8] border border-[#CBD8E6]">
              <span className="text-[12px] text-[#475569] uppercase font-bold block">Hotspots Fixed</span>
              <span className="text-xl font-bold text-[#0B2540] font-mono tabular-nums block mt-1">
                {bestPlan.totalHotspotsFixed} of {rankedHotspots.length}
              </span>
              <span className="text-[12px] text-[#475569] block mt-0.5">
                {bestPlan.quickFixCount} Quick &bull; {bestPlan.capitalFixCount} Capital
              </span>
            </div>

            <div className="p-3.5 rounded-xl bg-[#EAF1F8] border border-[#CBD8E6]">
              <span className="text-[12px] text-[#475569] uppercase font-bold block">Benefit Density</span>
              <span className="text-xl font-bold text-[#92400E] font-mono tabular-nums block mt-1">
                {bestPlan.recoveryPerCrore} % / ₹Cr
              </span>
              <span className="text-[12px] text-[#475569] block mt-0.5">yield efficiency</span>
            </div>
          </div>

          {/* Selected Interventions List */}
          <div className="space-y-2 pt-2">
            <div className="flex items-center justify-between text-[13px]">
              <span className="font-bold text-[#0B2540] uppercase tracking-wider text-[12px]">
                Selected Interventions ({bestPlan.items.length})
              </span>
              <span className="text-[12px] text-[#166534] font-bold">Maximized System Return</span>
            </div>

            <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
              {bestPlan.items.map((item, idx) => {
                const isQuick = item.fixType === "quick";
                return (
                  <div
                    key={item.hotspotId || idx}
                    className="p-3 rounded-xl bg-white border border-[#CBD8E6] hover:border-[#0369A1] flex items-center justify-between text-[14px] transition-colors shadow-2xs"
                  >
                    <div className="truncate pr-3">
                      <div className="flex items-center gap-2">
                        <span
                          className={`text-[11px] font-bold px-2 py-0.5 rounded-md uppercase border ${
                            isQuick
                              ? "bg-[#E0F2FE] text-[#0369A1] border-[#CBD8E6]"
                              : "bg-[#F5F3FF] text-[#7C3AED] border-[#DDD6FE]"
                          }`}
                        >
                          {isQuick ? "Quick Pump" : "Capital Drain"}
                        </span>
                        <span className="font-semibold text-[#0B2540] truncate">{item.hotspotName}</span>
                      </div>
                      <div className="text-[13px] text-[#475569] truncate mt-1">
                        {item.option.title} &bull; Delivery:{" "}
                        <strong className="text-[#1E293B]">{item.deliveryTimeDisplay}</strong>
                      </div>
                    </div>

                    <div className="text-right shrink-0">
                      <span className="font-bold text-[#166534] font-mono tabular-nums block text-[15px]">
                        ₹{item.costCr} Cr
                      </span>
                      <span className="text-[12px] text-[#475569] block">
                        +{item.recoveryPct}% gain
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* 2. COST-VS-RECOVERY STEP CHART (PARETO FRONTIER) */}
        <div className="p-6 rounded-2xl bg-white border border-[#CBD8E6] shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-[#CBD8E6] pb-3">
            <span className="text-[13px] font-bold text-[#0B2540] uppercase tracking-wider flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-[#0369A1]" />
              <span>Cost-vs-Recovery Step Chart (Pareto Frontier)</span>
            </span>
            <span className="text-[12px] px-2 py-0.5 rounded bg-[#EAF1F8] text-[#475569] border border-[#CBD8E6] font-medium">
              illustrative
            </span>
          </div>

          <p className="text-[14px] text-[#475569] leading-relaxed">
            Marginal benefit curve from ₹0 to ₹20 Crore. Shows decreasing marginal returns beyond critical early underpass pump deployments.
          </p>

          {/* SVG Chart Container */}
          <div className="bg-white border border-[#CBD8E6] rounded-xl p-3 overflow-hidden flex justify-center shadow-2xs">
            <svg
              viewBox={`0 0 ${svgWidth} ${svgHeight}`}
              className="w-full h-auto select-none max-w-2xl"
            >
              {/* Y Gridlines and Labels (12px readable fonts) */}
              {[0, 25, 50, 75, 100].map((val) => (
                <g key={`grid-y-${val}`}>
                  <line
                    x1={padding.left}
                    y1={getY(val)}
                    x2={svgWidth - padding.right}
                    y2={getY(val)}
                    stroke="#CBD8E6"
                    strokeWidth="1"
                    strokeDasharray="4 4"
                  />
                  <text
                    x={padding.left - 8}
                    y={getY(val) + 4}
                    fill="#475569"
                    fontSize="12"
                    fontFamily="Inter, system-ui, sans-serif"
                    fontWeight="500"
                    textAnchor="end"
                  >
                    {val}%
                  </text>
                </g>
              ))}

              {/* X Gridlines and Labels (12px readable fonts) */}
              {[0, 5, 10, 15, 20].map((b) => (
                <g key={`grid-x-${b}`}>
                  <line
                    x1={getX(b)}
                    y1={padding.top}
                    x2={getX(b)}
                    y2={padding.top + chartH}
                    stroke="#CBD8E6"
                    strokeWidth="1"
                    strokeDasharray="4 4"
                  />
                  <text
                    x={getX(b)}
                    y={padding.top + chartH + 20}
                    fill="#475569"
                    fontSize="12"
                    fontFamily="Inter, system-ui, sans-serif"
                    fontWeight="500"
                    textAnchor="middle"
                  >
                    ₹{b} Cr
                  </text>
                </g>
              ))}

              {/* Axis Border Lines */}
              <line
                x1={padding.left}
                y1={padding.top + chartH}
                x2={svgWidth - padding.right}
                y2={padding.top + chartH}
                stroke="#94A9BF"
                strokeWidth="1.5"
              />
              <line
                x1={padding.left}
                y1={padding.top}
                x2={padding.left}
                y2={padding.top + chartH}
                stroke="#94A9BF"
                strokeWidth="1.5"
              />

              {/* Pareto Frontier Step Path */}
              <path
                d={paretoPath}
                fill="none"
                stroke="#166534"
                strokeWidth="3"
                strokeLinejoin="miter"
              />

              {/* Data points */}
              {paretoPoints.map((pt, i) => (
                <circle
                  key={`pt-${i}`}
                  cx={getX(pt.costCr)}
                  cy={getY(pt.recoveryPct)}
                  r="4"
                  fill="#FFFFFF"
                  stroke="#166534"
                  strokeWidth="2.5"
                />
              ))}

              {/* Current Active Budget Indicator Line and Point */}
              <line
                x1={getX(bestPlan.totalCostCr)}
                y1={padding.top}
                x2={getX(bestPlan.totalCostCr)}
                y2={padding.top + chartH}
                stroke="#0369A1"
                strokeWidth="2"
                strokeDasharray="4 3"
              />
              <circle
                cx={getX(bestPlan.totalCostCr)}
                cy={getY(bestPlan.combinedRecoveryPct)}
                r="6"
                fill="#0369A1"
                stroke="#FFFFFF"
                strokeWidth="2"
              />
              <text
                x={Math.min(svgWidth - padding.right - 80, getX(bestPlan.totalCostCr) + 8)}
                y={Math.max(padding.top + 15, getY(bestPlan.combinedRecoveryPct) - 8)}
                fill="#0369A1"
                fontSize="12"
                fontFamily="Inter, system-ui, sans-serif"
                fontWeight="700"
              >
                ₹{bestPlan.totalCostCr}Cr: {bestPlan.combinedRecoveryPct}%
              </text>
            </svg>
          </div>

          <div className="flex justify-between items-center text-[13px] text-[#475569] pt-1">
            <span>X-Axis: Capital Expenditure (₹ Crore)</span>
            <span>Y-Axis: Systemic Trip &amp; Hospital Recovery %</span>
          </div>
        </div>

        {/* 3. "QUICK VS CAPITAL" SIDE-BY-SIDE COMPARISON */}
        <div className="p-6 rounded-2xl bg-white border border-[#CBD8E6] shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-[#CBD8E6] pb-3">
            <span className="text-[13px] font-bold text-[#0B2540] uppercase tracking-wider flex items-center gap-2">
              <Building className="w-4 h-4 text-[#7C3AED]" />
              <span>Quick vs Capital Comparison</span>
            </span>
            <span className="text-[12px] text-[#475569]">Under ₹{budgetCr % 1 === 0 ? budgetCr.toFixed(0) : budgetCr.toFixed(1)} Cr</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Left: Quick Only Plan */}
            <div className="p-4 rounded-xl bg-[#E0F2FE] border border-[#CBD8E6] space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold px-2 py-0.5 rounded-md bg-white text-[#0369A1] border border-[#CBD8E6] uppercase">
                  Only Quick Fixes
                </span>
                <span className="text-[12px] text-[#475569]">Pumps &amp; Diversions</span>
              </div>

              <div className="text-2xl font-bold text-[#0B2540] tabular-nums font-mono">
                {quickOnlyPlan.combinedRecoveryPct}%
                <span className="text-[13px] text-[#475569] font-normal ml-1 font-sans">recovery</span>
              </div>

              <div className="space-y-1.5 text-[13px] text-[#1E293B] pt-2 border-t border-[#CBD8E6]">
                <div className="flex justify-between">
                  <span className="text-[#475569]">Cost:</span>
                  <strong className="text-[#0369A1] font-mono">₹{quickOnlyPlan.totalCostCr} Crore</strong>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#475569]">Time to deliver:</span>
                  <strong className="text-[#166534] font-mono">
                    {quickOnlyPlan.maxDeliveryDaysQuick || 14} days
                  </strong>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#475569]">Hotspots Covered:</span>
                  <strong className="text-[#0B2540] font-mono">{quickOnlyPlan.totalHotspotsFixed} spots</strong>
                </div>
                <div className="flex justify-between text-[#92400E] font-semibold">
                  <span>Recovery per crore:</span>
                  <span className="font-mono">{quickOnlyPlan.recoveryPerCrore} % / ₹Cr</span>
                </div>
              </div>

              <div className="text-[12px] text-[#0369A1] pt-1.5 border-t border-[#CBD8E6] leading-relaxed">
                Fastest deployment before monsoon arrival; maximum recovery per crore.
              </div>
            </div>

            {/* Right: Capital Only Plan */}
            <div className="p-4 rounded-xl bg-[#FAF5FF] border border-[#CBD8E6] space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold px-2 py-0.5 rounded-md bg-white text-[#7C3AED] border border-[#DDD6FE] uppercase">
                  Only Capital Works
                </span>
                <span className="text-[12px] text-[#475569]">Culverts &amp; Sumps</span>
              </div>

              <div className="text-2xl font-bold text-[#0B2540] tabular-nums font-mono">
                {capitalOnlyPlan.combinedRecoveryPct}%
                <span className="text-[13px] text-[#475569] font-normal ml-1 font-sans">recovery</span>
              </div>

              <div className="space-y-1.5 text-[13px] text-[#1E293B] pt-2 border-t border-[#CBD8E6]">
                <div className="flex justify-between">
                  <span className="text-[#475569]">Cost:</span>
                  <strong className="text-[#7C3AED] font-mono">₹{capitalOnlyPlan.totalCostCr} Crore</strong>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#475569]">Time to deliver:</span>
                  <strong className="text-[#92400E] font-mono">
                    {capitalOnlyPlan.maxDeliveryMonthsCapital || 8} months
                  </strong>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#475569]">Hotspots Covered:</span>
                  <strong className="text-[#0B2540] font-mono">{capitalOnlyPlan.totalHotspotsFixed} spots</strong>
                </div>
                <div className="flex justify-between text-[#92400E] font-semibold">
                  <span>Recovery per crore:</span>
                  <span className="font-mono">{capitalOnlyPlan.recoveryPerCrore} % / ₹Cr</span>
                </div>
              </div>

              <div className="text-[12px] text-[#6B21A8] pt-1.5 border-t border-[#CBD8E6] leading-relaxed">
                Permanent structural immunity; longer delivery window across fiscal quarters.
              </div>
            </div>
          </div>
        </div>

        {/* 4. INDIVIDUAL HOTSPOT PRIORITY RANKING TABLE */}
        <div className="p-6 rounded-2xl bg-white border border-[#CBD8E6] shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-[#CBD8E6] pb-3">
            <span className="text-[13px] font-bold text-[#0B2540] uppercase tracking-wider flex items-center gap-2">
              <Award className="w-4 h-4 text-[#166534]" />
              <span>Individual Hotspot Priority Ranking ({rankedHotspots.length})</span>
            </span>
            <span className="text-[12px] text-[#475569]">Sorted by Combined Yield</span>
          </div>

          <div className="space-y-3 max-h-80 overflow-y-auto pr-1">
            {rankedHotspots.map((spot) => {
              const activeScore = isEquityAware ? spot.equityCombinedScore : spot.baseCombinedScore;
              return (
                <div
                  key={spot.hotspotId}
                  className="p-4 rounded-xl bg-white border border-[#CBD8E6] hover:border-[#0369A1] hover:bg-[#EAF1F8]/40 transition-colors space-y-3 shadow-2xs"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-start gap-2.5 min-w-0">
                      <span className="w-6 h-6 rounded-md bg-[#EAF1F8] border border-[#CBD8E6] flex items-center justify-center font-bold text-[12px] text-[#166534] shrink-0 font-mono">
                        #{spot.rank}
                      </span>
                      <div className="truncate">
                        <span className="font-bold text-[#0B2540] text-[15px] block truncate">
                          {spot.hotspotName}
                        </span>
                        {isEquityAware && (
                          <div className="text-[12px] text-[#991B1B] flex items-center gap-1.5 mt-0.5">
                            <span>Vulnerability: {spot.vulnerabilityWeight}x</span>
                            <span className="text-[#94A9BF]">&bull;</span>
                            <span className="truncate">{spot.vulnerabilityRationale}</span>
                          </div>
                        )}
                      </div>
                    </div>

                    <span className="text-[14px] font-bold text-[#166534] font-mono shrink-0 tabular-nums bg-[#DCFCE7] px-2 py-0.5 rounded-md border border-[#BBF7D0]">
                      {activeScore}/100
                    </span>
                  </div>

                  {/* Quick vs Capital Options Grid */}
                  <div className="grid grid-cols-2 gap-3 text-[13px]">
                    <div className="p-2.5 rounded-lg bg-[#EAF1F8] border border-[#CBD8E6]">
                      <div className="flex items-center justify-between font-bold text-[#0369A1]">
                        <span>Quick Fix:</span>
                        <span className="font-mono">₹{spot.quickOption.costCr} Cr</span>
                      </div>
                      <div className="text-[12px] text-[#475569] mt-0.5">
                        {spot.quickOption.deliveryTimeDisplay} &bull; Pump &amp; diverters
                      </div>
                    </div>

                    <div className="p-2.5 rounded-lg bg-[#EAF1F8] border border-[#CBD8E6]">
                      <div className="flex items-center justify-between font-bold text-[#7C3AED]">
                        <span>Capital:</span>
                        <span className="font-mono">₹{spot.capitalOption.costCr} Cr</span>
                      </div>
                      <div className="text-[12px] text-[#475569] mt-0.5">
                        {spot.capitalOption.deliveryTimeDisplay} &bull; Culvert reconstruction
                      </div>
                    </div>
                  </div>

                  {/* Simulation Action Button */}
                  {onSimulateHotspotFix && (
                    <button
                      type="button"
                      onClick={() => onSimulateHotspotFix(spot.hotspotId)}
                      className="w-full py-2 px-3 rounded-lg bg-white hover:bg-[#EAF1F8] border border-[#CBD8E6] text-[#0369A1] font-semibold text-[13px] flex items-center justify-center gap-2 cursor-pointer transition-colors shadow-2xs"
                    >
                      <CheckCircle2 className="w-4 h-4 text-[#166534]" />
                      <span>Simulate this drain cleared in What-If</span>
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
